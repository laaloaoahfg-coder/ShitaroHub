-- UI-only reconstruction. No remote code or gameplay features.
-- Install as a LocalScript in StarterPlayer > StarterPlayerScripts.
-- Runtime and pixel-level parity must be checked in Roblox Studio.
--
-- v2 changes:
--   * every feature row of the aim section was removed (empty state only);
--   * settings tab holds a language switch (en/ru) and a live keybind
--     field (right click -> field blanks out -> next keyboard press binds).
--
-- v8 changes:
--   * third person / free camera: the first person arms and gun (the model the
--     game parents to the camera) are hidden while the camera is away from the
--     head, so they stay with the real body instead of floating with the view.
--
-- v7 changes:
--   * aimbot: keeps its own aim between frames (the pull accumulates even when
--     the game rebuilds the camera from the mouse every frame), so the
--     crosshair converges on the chosen part instead of stopping short;
--     shitaro_aim() also prints how far the aim point is from the screen centre.
--   * aim tab: part names are centred in their segments.
--
-- v6 changes:
--   * esp: the root part is the anchor of every box (limbs that freeze while
--     a player is off screen / behind a wall no longer outvote it); the box
--     proportions are measured while all parts agree and reused afterwards.
--   * camera: the field of view slider is absolute (1-120 degrees), applies
--     at once and has a reset button; it is written late in the frame (before
--     the aimbot and ESP) and re-asserted if the game overwrites it.
--
-- v5 changes:
--   * "ignore teammates" (ESP and aimbot) shares one side resolver: Roblox
--     Team, side attributes, side value objects, character folders; the
--     filter only applies while a second side exists in the match;
--     getgenv().shitaro_dump() prints the resolved side of every player.
--
-- v4 changes:
--   * aim tab: aimbot (on/off, visibility check, only while shooting, target
--     part head/neck/body/legs, ignore bots/teammates, smoothing 1-10, FOV
--     circle 1-150, range 1-800 m) with its own circle overlay; the empty
--     state of that tab is gone.
--
-- v3 changes:
--   * visuals tab: ESP (box, line, nickname, distance, skeleton, health,
--     ignore teammates / friends, range 0-800), two colour squares per
--     function (exposed / behind cover) edited in the docked colour panel.

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local GuiService = game:GetService("GuiService")
local Stats = game:GetService("Stats")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- Replace only an earlier instance of this UI.
local previous = playerGui:FindFirstChild("ShitaroMenuOnly")
if previous then
    previous:Destroy()
end

local colors = {
    bg = Color3.fromRGB(7, 7, 9),
    text = Color3.fromRGB(230, 230, 236),
    sub = Color3.fromRGB(170, 170, 178),
    dim = Color3.fromRGB(112, 112, 122),
    faint = Color3.fromRGB(68, 68, 76),
    accent = Color3.fromRGB(200, 148, 232),
}

-- The docked colour panel edits the menu surface.
local picker = {
    target = { kind = "menu" },
    listeners = {},
}

-- width reserved on the right for the docked picker (panel + margins)
local PANEL_RESERVE = 370

local fonts = {
    normal = Font.new(
        "rbxasset://fonts/families/BuilderSans.json",
        Enum.FontWeight.SemiBold
    ),
    bold = Font.new(
        "rbxasset://fonts/families/BuilderSans.json",
        Enum.FontWeight.Bold
    ),
    watermark = Font.new(
        "rbxasset://fonts/families/SourceSansPro.json"
    ),
}

local icons = {
    code = 106124864132557,
    crosshair = 83752373575368,
    trigger = 81854854241463,
    eye = 127234874352422,
    gear = 109485777305919,
    skins = 127369887384101,
    sliders = 125396339381135,
    save = 122894934359450,
    chevron = 71457658246709,
    grip = 128492050787735,
    layers = 114499998778667,
    wifi = 104941258142372,
    ram = 82464660673318,
    clock = 136533241128438,
}

local function make(class, properties, parent)
    local object = Instance.new(class)

    if object:IsA("GuiObject") then
        object.BorderSizePixel = 0
        object.BackgroundTransparency = 1
    end

    if object:IsA("TextLabel") or object:IsA("TextButton") then
        object.Text = ""
        object.FontFace = fonts.normal
        object.TextSize = 14
        object.TextColor3 = colors.text
        object.TextXAlignment = Enum.TextXAlignment.Left
        object.AutoLocalize = false
    end

    if object:IsA("GuiButton") then
        object.AutoButtonColor = false
    end

    for key, value in pairs(properties or {}) do
        object[key] = value
    end

    object.Parent = parent
    return object
end

local function corner(parent, radius)
    return make("UICorner", {
        CornerRadius = radius,
    }, parent)
end

local function stroke(parent, transparency)
    make("UIStroke", {
        Color = Color3.new(1, 1, 1),
        Transparency = transparency,
        Thickness = 1,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
    }, parent)
end

local function padding(parent, left, right, top, bottom)
    make("UIPadding", {
        PaddingLeft = UDim.new(0, left),
        PaddingRight = UDim.new(0, right),
        PaddingTop = UDim.new(0, top),
        PaddingBottom = UDim.new(0, bottom),
    }, parent)
end

local function row(parent, gap, alignment)
    return make("UIListLayout", {
        FillDirection = Enum.FillDirection.Horizontal,
        SortOrder = Enum.SortOrder.LayoutOrder,
        Padding = UDim.new(0, gap),
        VerticalAlignment = Enum.VerticalAlignment.Center,
        HorizontalAlignment = alignment
            or Enum.HorizontalAlignment.Left,
    }, parent)
end

local function image(parent, key, size, order, transparency)
    return make("ImageLabel", {
        Size = UDim2.fromOffset(size, size),
        Image = "rbxassetid://" .. icons[key],
        ScaleType = Enum.ScaleType.Fit,
        LayoutOrder = order or 0,
        ImageTransparency = transparency or 0,
    }, parent)
end

local function animate(object, properties, duration)
    TweenService:Create(
        object,
        TweenInfo.new(
            duration or 0.14,
            Enum.EasingStyle.Quad,
            Enum.EasingDirection.Out
        ),
        properties
    ):Play()
end

-- Localisation --------------------------------------------------------------

local locale = {
    en = {
        ["tab.aim"] = "aim",
        ["tab.trigger"] = "trigger",
        ["tab.visuals"] = "visuals",
        ["tab.misc"] = "misc",
        ["tab.skins"] = "skins",
        ["tab.settings"] = "settings",
        ["header.config"] = "No config",
        ["header.profile"] = "global",
        ["close.title"] = "disable cheat",
        ["close.body"] = "the cheat will be turned off: the menu closes and "
            .. "the menu key stops working. you can only bring it back by "
            .. "running the script again.",
        ["close.cancel"] = "cancel",
        ["close.confirm"] = "okay",
        ["settings.panel"] = "interface",
        ["settings.language"] = "language",
        ["settings.keybind"] = "menu key",
        ["settings.hint"] = "left click the key to rebind",
        ["settings.color"] = "menu color",
        ["settings.opacity"] = "transparency",
        ["palette.title"] = "menu color",
        ["palette.subtitle"] = "pick the interface color",
        ["palette.apply"] = "apply",
        ["palette.reset"] = "reset",
        ["settings.watermark"] = "watermark",
        ["settings.wmScale"] = "size",
        ["settings.wmX"] = "position X",
        ["settings.wmY"] = "position Y",
        ["settings.wmReset"] = "reset position",
        ["esp.panel"] = "esp",
        ["esp.filters"] = "filters",
        ["esp.box"] = "box",
        ["esp.line"] = "line",
        ["esp.name"] = "nickname",
        ["esp.distance"] = "distance",
        ["esp.skeleton"] = "skeleton",
        ["esp.health"] = "health",
        ["esp.bots"] = "bot esp",
        ["esp.ignoreTeam"] = "ignore teammates",
        ["esp.ignoreFriends"] = "ignore friends",
        ["esp.range"] = "max distance",
        ["esp.picker.title"] = "esp color",
        ["esp.state.visible"] = "exposed",
        ["esp.state.hidden"] = "behind cover",
    },
    ru = {
        ["tab.aim"] = "прицел",
        ["tab.trigger"] = "триггер",
        ["tab.visuals"] = "визуалы",
        ["tab.misc"] = "прочее",
        ["tab.skins"] = "скины",
        ["tab.settings"] = "настройки",
        ["header.config"] = "нет конфига",
        ["header.profile"] = "глобальный",
        ["close.title"] = "отключение чита",
        ["close.body"] = "чит будет отключён: меню закроется, а клавиша "
            .. "перестанет работать. вернуть можно только повторным "
            .. "запуском скрипта.",
        ["close.cancel"] = "отмена",
        ["close.confirm"] = "хорошо",
        ["settings.panel"] = "интерфейс",
        ["settings.language"] = "язык",
        ["settings.keybind"] = "клавиша меню",
        ["settings.hint"] = "ЛКМ по клавише — смена",
        ["settings.color"] = "цвет меню",
        ["settings.opacity"] = "прозрачность",
        ["palette.title"] = "изменение цвета меню",
        ["palette.subtitle"] = "выберите цвет интерфейса",
        ["palette.apply"] = "применить",
        ["palette.reset"] = "сброс",
        ["settings.watermark"] = "вотермарка",
        ["settings.wmScale"] = "размер",
        ["settings.wmX"] = "позиция X",
        ["settings.wmY"] = "позиция Y",
        ["settings.wmReset"] = "сброс положения",
        ["esp.panel"] = "есп",
        ["esp.filters"] = "фильтры",
        ["esp.box"] = "коробка",
        ["esp.line"] = "линия",
        ["esp.name"] = "никнейм",
        ["esp.distance"] = "расстояние",
        ["esp.skeleton"] = "скелет",
        ["esp.health"] = "здоровье",
        ["esp.bots"] = "есп на ботов",
        ["esp.ignoreTeam"] = "игнорировать тиммейтов",
        ["esp.ignoreFriends"] = "игнорировать друзей",
        ["esp.range"] = "дистанция",
        ["esp.picker.title"] = "изменение цвета есп",
        ["esp.state.visible"] = "на виду",
        ["esp.state.hidden"] = "за укрытием",
    },
}

local languageNames = {
    en = "english",
    ru = "русский",
}

local currentLanguage = "en"
local localized = {}
local languageChanged = {}

local function L(key)
    local pack = locale[currentLanguage]

    if pack and pack[key] then
        return pack[key]
    end

    return locale.en[key] or key
end

-- Registers a TextLabel/TextButton so it is retranslated on every switch.
local function localize(object, key)
    table.insert(localized, {
        object = object,
        key = key,
    })

    object.Text = L(key)
    return object
end

local function onLanguageChanged(callback)
    table.insert(languageChanged, callback)
end

local function setLanguage(id)
    if not locale[id] or id == currentLanguage then
        return
    end

    currentLanguage = id

    for _, entry in ipairs(localized) do
        entry.object.Text = L(entry.key)
    end

    for _, callback in ipairs(languageChanged) do
        callback(id)
    end
end

local function currentLanguageName()
    return languageNames[currentLanguage] or currentLanguage
end

local gui = make("ScreenGui", {
    Name = "ShitaroMenuOnly",
    IgnoreGuiInset = true,
    ResetOnSpawn = false,
    ScreenInsets = Enum.ScreenInsets.None,
    ClipToDeviceSafeArea = false,
    ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
    DisplayOrder = 10000,
}, playerGui)

local connections = {}

local function connect(signal, callback)
    local connection = signal:Connect(callback)
    table.insert(connections, connection)
    return connection
end

connect(gui.Destroying, function()
    for _, connection in ipairs(connections) do
        connection:Disconnect()
    end
end)

-- Window

local window = make("Frame", {
    Name = "Menu",
    Position = UDim2.fromOffset(0, 0),
    Visible = false,
    Size = UDim2.fromOffset(780, 470),
    BackgroundTransparency = 0.16,
    BackgroundColor3 = colors.bg,
    Active = true,
}, gui)

local menuScale = make("UIScale", {
    Scale = 1,
}, window)

corner(window, UDim.new(0, 10))
stroke(window, 0.935)

local header = make("Frame", {
    Size = UDim2.new(1, 0, 0, 40),
}, window)

local tintClip = make("Frame", {
    Size = UDim2.fromScale(1, 1),
    ClipsDescendants = true,
}, header)

local tint = make("Frame", {
    Size = UDim2.new(1, 0, 1, 12),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.976,
}, tintClip)

corner(tint, UDim.new(0, 10))

make("Frame", {
    Position = UDim2.fromOffset(0, 40),
    Size = UDim2.new(1, 0, 0, 1),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.94,
}, window)

local dragHandle = make("TextButton", {
    Size = UDim2.fromScale(1, 1),
    ZIndex = 1,
}, header)

local titleRow = make("Frame", {
    Position = UDim2.fromOffset(14, 0),
    Size = UDim2.fromOffset(0, 40),
    AutomaticSize = Enum.AutomaticSize.X,
    ZIndex = 2,
}, header)

row(titleRow, 8)

make("TextLabel", {
    Text = "shitaro",
    FontFace = fonts.bold,
    TextSize = 15,
    Size = UDim2.fromOffset(0, 40),
    AutomaticSize = Enum.AutomaticSize.X,
    LayoutOrder = 1,
}, titleRow)

make("Frame", {
    Size = UDim2.fromOffset(4, 1),
    LayoutOrder = 2,
}, titleRow)

-- Configuration controls are decorative only.
local save = make("Frame", {
    Size = UDim2.fromOffset(24, 24),
    LayoutOrder = 3,
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.952,
}, titleRow)

corner(save, UDim.new(0, 6))
stroke(save, 0.925)

local saveIcon = image(save, "save", 13)
saveIcon.AnchorPoint = Vector2.new(0.5, 0.5)
saveIcon.Position = UDim2.fromScale(0.5, 0.5)
saveIcon.ImageColor3 = colors.dim

local config = make("Frame", {
    Size = UDim2.fromOffset(0, 24),
    AutomaticSize = Enum.AutomaticSize.X,
    LayoutOrder = 4,
}, titleRow)

row(config, 6)

localize(make("TextLabel", {
    Text = "No config",
    TextSize = 13,
    TextColor3 = colors.dim,
    Size = UDim2.fromOffset(0, 24),
    AutomaticSize = Enum.AutomaticSize.X,
    LayoutOrder = 1,
}, config), "header.config")

local configIcon = image(config, "chevron", 10, 2)
configIcon.ImageColor3 = colors.dim

-- Auto width: Cyrillic labels ("глобальный") are wider than "global", so the
-- chip has to hug its text instead of using a fixed 70 px box.
local profile = make("Frame", {
    Size = UDim2.fromOffset(0, 24),
    AutomaticSize = Enum.AutomaticSize.X,
    LayoutOrder = 5,
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.952,
}, titleRow)

corner(profile, UDim.new(0, 6))
stroke(profile, 0.925)
padding(profile, 10, 24, 0, 0)

localize(make("TextLabel", {
    Text = "global",
    TextSize = 13,
    Size = UDim2.fromOffset(0, 24),
    AutomaticSize = Enum.AutomaticSize.X,
}, profile), "header.profile")

local profileIcon = image(profile, "chevron", 10)
profileIcon.AnchorPoint = Vector2.new(1, 0.5)
profileIcon.Position = UDim2.new(1, -8, 0.5, 0)
profileIcon.ImageColor3 = colors.dim

-- Close button in the top-right corner. The confirmation sheet itself is
-- built further down (it needs the finished window), so only the handler is
-- declared here and assigned there.
local openShutdownConfirm

local closeButton = make("TextButton", {
    Name = "CloseButton",
    AnchorPoint = Vector2.new(1, 0.5),
    Position = UDim2.new(1, -12, 0.5, 0),
    Size = UDim2.fromOffset(24, 24),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.952,
    AutoButtonColor = false,
    Text = "",
    -- the header drag handle is raised to ZIndex 30 further down, so the
    -- cross has to stay above it or it only starts a window drag
    ZIndex = 31,
}, header)

corner(closeButton, UDim.new(0, 6))
stroke(closeButton, 0.925)

-- The cross is two rotated bars, so the button needs no extra asset.
local crossBars = {}

for _, rotation in ipairs({ 45, -45 }) do
    local bar = make("Frame", {
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.fromOffset(11, 2),
        Rotation = rotation,
        BackgroundColor3 = colors.dim,
        BackgroundTransparency = 0.15,
        ZIndex = 32,
    }, closeButton)

    table.insert(crossBars, bar)
end

connect(closeButton.MouseEnter, function()
    animate(closeButton, { BackgroundTransparency = 0.88 })

    for _, bar in ipairs(crossBars) do
        animate(bar, { BackgroundColor3 = Color3.fromRGB(226, 96, 96) })
    end
end)

connect(closeButton.MouseLeave, function()
    animate(closeButton, { BackgroundTransparency = 0.952 })

    for _, bar in ipairs(crossBars) do
        animate(bar, { BackgroundColor3 = colors.dim })
    end
end)

local body = make("Frame", {
    Name = "EmptyPages",
    Position = UDim2.fromOffset(0, 41),
    Size = UDim2.new(1, 0, 1, -89),
}, window)

-- Navigation

local nav = make("Frame", {
    AnchorPoint = Vector2.new(0.5, 1),
    Position = UDim2.new(0.5, 0, 1, -9),
    Size = UDim2.fromOffset(0, 32),
    AutomaticSize = Enum.AutomaticSize.X,
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.958,
    ZIndex = 3,
}, window)

local navCorner = corner(nav, UDim.new(1, 0))
stroke(nav, 0.935)
padding(nav, 3, 3, 3, 3)

local highlight = make("Frame", {
    Size = UDim2.fromOffset(0, 26),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.925,
    ZIndex = 3,
}, nav)

corner(highlight, UDim.new(1, 0))

local tabRow = make("Frame", {
    Size = UDim2.fromOffset(0, 26),
    AutomaticSize = Enum.AutomaticSize.X,
    ZIndex = 4,
}, nav)

local navigationLayout = row(tabRow, 2)
local tabs = {}
local selected

local function updateHighlight()
    if not selected or not gui.Parent then
        return
    end

    local scale = menuScale.Scale
    local delta = (
        selected.button.AbsolutePosition
        - tabRow.AbsolutePosition
    ) / scale

    animate(highlight, {
        Position = UDim2.fromOffset(delta.X, delta.Y),
        Size = UDim2.fromOffset(
            selected.button.AbsoluteSize.X / scale,
            selected.button.AbsoluteSize.Y / scale
        ),
    }, 0.24)
end

local function drawTab(tab)
    local active = tab == selected

    tab.label.FontFace = active and fonts.bold or fonts.normal

    animate(tab.label, {
        TextColor3 = active and colors.text
            or (tab.hover and colors.sub or colors.dim),
    })

    animate(tab.icon, {
        ImageColor3 = active and colors.accent
            or (tab.hover and colors.sub or colors.dim),
    })

    tab.page.Visible = active
end

for index, entry in ipairs({
    { "aim", "crosshair" },
    { "trigger", "trigger" },
    { "visuals", "eye" },
    { "misc", "gear" },
    { "skins", "skins" },
    { "settings", "sliders" },
}) do
    local button = make("TextButton", {
        Name = entry[1],
        Size = UDim2.fromOffset(0, 26),
        AutomaticSize = Enum.AutomaticSize.X,
        LayoutOrder = index,
        ZIndex = 4,
    }, tabRow)

    padding(button, 10, 12, 0, 0)
    row(button, 6)

    local tab = {
        button = button,
        icon = image(button, entry[2], 13, 1),

        label = make("TextLabel", {
            Text = entry[1],
            TextSize = 13,
            Size = UDim2.fromOffset(0, 26),
            AutomaticSize = Enum.AutomaticSize.X,
            LayoutOrder = 2,
            ZIndex = 4,
        }, button),

        page = make("Frame", {
            Name = entry[1],
            Size = UDim2.fromScale(1, 1),
            Visible = false,
        }, body),
    }

    tab.icon.ZIndex = 4
    localize(tab.label, "tab." .. entry[1])
    table.insert(tabs, tab)
    selected = selected or tab

    connect(button.MouseEnter, function()
        tab.hover = true
        drawTab(tab)
    end)

    connect(button.MouseLeave, function()
        tab.hover = false
        drawTab(tab)
    end)

    connect(button.Activated, function()
        selected = tab

        for _, item in ipairs(tabs) do
            drawTab(item)
        end

        if picker.sync then
            picker.sync(tab)
        end

        task.defer(updateHighlight)
    end)

    connect(
        button:GetPropertyChangedSignal("AbsoluteSize"),
        updateHighlight
    )

    drawTab(tab)
end

connect(
    tabRow:GetPropertyChangedSignal("AbsolutePosition"),
    updateHighlight
)

task.defer(updateHighlight)

local grip = make("ImageButton", {
    AnchorPoint = Vector2.new(1, 1),
    Position = UDim2.new(1, -6, 1, -6),
    Size = UDim2.fromOffset(11, 11),
    Image = "rbxassetid://" .. icons.grip,
    ImageColor3 = colors.faint,
    ZIndex = 10,
}, window)

-- Watermark: no top or right offset.

local inset = GuiService:GetGuiInset()

local watermark = make("TextButton", {
    Name = "Watermark",
    AnchorPoint = Vector2.new(1, 0),
    Position = UDim2.new(1, 0, 0, 0),
    ZIndex = 20,
    Size = UDim2.fromOffset(0, 34),
    AutomaticSize = Enum.AutomaticSize.X,
}, gui)

row(watermark, 10, Enum.HorizontalAlignment.Left)

-- The whole watermark is one scalable unit; pills are retinted with the menu
-- theme through `watermarkPills` (style hook lives in the settings section).
local watermarkScale = make("UIScale", {
    Name = "WatermarkScale",
    Scale = 1,
}, watermark)

local watermarkPills = {}

local function pill(order)
    local frame = make("Frame", {
        Size = UDim2.fromOffset(0, 34),
        AutomaticSize = Enum.AutomaticSize.X,
        BackgroundColor3 = Color3.fromRGB(12, 20, 25),
        BackgroundTransparency = 0.686274528503418,
        LayoutOrder = order,
    }, watermark)

    table.insert(watermarkPills, frame)

    corner(frame, UDim.new(1, 0))
    padding(frame, 12, 12, 8, 8)
    row(frame, 0)

    return frame
end

local function spacer(parent, width, order)
    make("Frame", {
        Size = UDim2.fromOffset(width, 1),
        LayoutOrder = order,
    }, parent)
end

local function watermarkText(parent, text, order)
    local container = make("Frame", {
        Size = UDim2.fromOffset(0, 18),
        AutomaticSize = Enum.AutomaticSize.X,
        LayoutOrder = order,
    }, parent)

    local shadow = make("TextLabel", {
        Text = text,
        FontFace = fonts.watermark,
        TextSize = 16,
        TextColor3 = Color3.new(),
        TextTransparency = 0.15,
        Position = UDim2.fromOffset(1, 1),
        Size = UDim2.fromOffset(0, 18),
        AutomaticSize = Enum.AutomaticSize.X,
    }, container)

    local label = make("TextLabel", {
        Text = text,
        FontFace = fonts.watermark,
        TextSize = 16,
        TextColor3 = Color3.new(1, 1, 1),
        Size = UDim2.fromOffset(0, 18),
        AutomaticSize = Enum.AutomaticSize.X,
        ZIndex = 2,
    }, container)

    connect(label:GetPropertyChangedSignal("Text"), function()
        shadow.Text = label.Text
    end)

    return label
end

local brand = pill(1)
image(brand, "code", 18, 1, 0.392)
spacer(brand, 8, 2)
watermarkText(brand, "shitaro.lol", 3)

local metrics = pill(2)
local values = {}

for index, name in ipairs({
    "User",
    "FPS",
    "Ping",
    "RAM",
    "Time",
}) do
    if index > 1 then
        local separator = make("Frame", {
            Size = UDim2.fromOffset(25, 14),
            LayoutOrder = index * 2 - 1,
        }, metrics)

        make("Frame", {
            AnchorPoint = Vector2.new(0.5, 0.5),
            Position = UDim2.fromScale(0.5, 0.5),
            Size = UDim2.fromOffset(1, 14),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BackgroundTransparency = 0.392,
        }, separator)
    end

    local group = make("Frame", {
        Size = UDim2.fromOffset(0, 18),
        AutomaticSize = Enum.AutomaticSize.X,
        LayoutOrder = index * 2,
    }, metrics)

    row(group, 0)

    if name == "User" then
        local avatar = make("ImageLabel", {
            Size = UDim2.fromOffset(18, 18),
            LayoutOrder = 1,
            Image = "rbxthumb://type=AvatarHeadShot&id="
                .. player.UserId .. "&w=48&h=48",
            ScaleType = Enum.ScaleType.Crop,
            BackgroundColor3 = Color3.fromRGB(20, 20, 20),
            BackgroundTransparency = 0,
        }, group)

        corner(avatar, UDim.new(1, 0))
    else
        local keys = {
            FPS = "layers",
            Ping = "wifi",
            RAM = "ram",
            Time = "clock",
        }

        image(group, keys[name], 14, 1, 0.392)
    end

    spacer(group, 8, 2)

    values[name] = watermarkText(
        group,
        name == "User" and player.Name or "-",
        3
    )
end

-- Controls store UI state only, without gameplay callbacks.

local gesture
local safeOrigin = Vector2.zero
local safeSize = Vector2.new(780, 470)
local activeSlider
local uiState = {}

local function pageScroll(page, name)
    return make("ScrollingFrame", {
        Name = name,
        Size = UDim2.fromScale(1, 1),
        CanvasSize = UDim2.fromOffset(0, 0),
        AutomaticCanvasSize = Enum.AutomaticSize.Y,
        ScrollBarThickness = 2,
        ScrollBarImageColor3 = colors.dim,
        ScrollingDirection = Enum.ScrollingDirection.Y,
    }, page)
end

local previewScroll = pageScroll(tabs[1].page, "AimScroll")
local settingsScroll = pageScroll(tabs[6].page, "SettingsScroll")

-- panels are tracked per scroll frame so each page lays out its own columns
local panelGroups = {}
local panelWidths = {}

-- Extra space a panel asks for above itself (default gap is 12 px).
local panelGapBefore = {}

local function previewPanel(parent, key, order, count)
    local holder = make("Frame", {
        Name = key,
        Size = UDim2.fromOffset(240, 22 + count * 30),
        LayoutOrder = order,
    }, parent)

    localize(make("TextLabel", {
        Text = "",
        TextSize = 12,
        TextColor3 = colors.dim,
        Position = UDim2.fromOffset(10, 0),
        Size = UDim2.new(1, -20, 0, 22),
    }, holder), key)

    local card = make("Frame", {
        Position = UDim2.fromOffset(0, 22),
        Size = UDim2.new(1, 0, 0, count * 30),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = 0.958,
        ClipsDescendants = true,
    }, holder)

    corner(card, UDim.new(0, 10))
    stroke(card, 0.935)

    local group = panelGroups[parent]

    if not group then
        group = {}
        panelGroups[parent] = group
    end

    table.insert(group, holder)
    return card, holder
end

local function previewRow(card, index, name, enabled)
    local frame = make("Frame", {
        Position = UDim2.fromOffset(0, (index - 1) * 30),
        Size = UDim2.new(1, 0, 0, 30),
    }, card)

    if index > 1 then
        make("Frame", {
            Size = UDim2.new(1, 0, 0, 1),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BackgroundTransparency = 0.955,
        }, frame)
    end

    local label = make("TextLabel", {
        Text = name,
        TextSize = 13,
        TextColor3 = enabled and colors.text or colors.faint,
        Position = UDim2.fromOffset(12, 0),
        Size = UDim2.new(0.48, -12, 1, 0),
    }, frame)

    return frame, label
end

local function previewToggle(frame, on, enabled)
    local track = make("Frame", {
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -12, 0.5, 0),
        Size = UDim2.fromOffset(26, 14),
        BackgroundColor3 = on
            and colors.accent
            or Color3.new(1, 1, 1),
        BackgroundTransparency = on
            and 0.5
            or (enabled and 0.86 or 0.95),
    }, frame)

    corner(track, UDim.new(1, 0))

    local knob = make("Frame", {
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.new(0, on and 14 or 2, 0.5, 0),
        Size = UDim2.fromOffset(10, 10),
        BackgroundColor3 = on and colors.accent or colors.sub,
        BackgroundTransparency = enabled and 0.15 or 0.6,
    }, track)

    corner(knob, UDim.new(1, 0))

    local hit = make("TextButton", {
        Size = UDim2.fromScale(1, 1),
        ZIndex = 5,
    }, frame)

    local key = frame.Parent.Parent.Name
        .. "/" .. frame.Position.Y.Offset

    uiState[key] = on

    connect(hit.Activated, function()
        on = not on
        uiState[key] = on

        animate(track, {
            BackgroundColor3 = on
                and colors.accent
                or Color3.new(1, 1, 1),
            BackgroundTransparency = on and 0.35 or 0.86,
        })

        animate(knob, {
            Position = UDim2.new(0, on and 14 or 2, 0.5, 0),
            BackgroundColor3 = on and colors.accent or colors.sub,
            BackgroundTransparency = 0.15,
        })
    end)
end

-- Dropdowns remain decorative.
local function previewDropdown(frame, text)
    local field = make("Frame", {
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -10, 0.5, 0),
        Size = UDim2.new(0.47, 0, 0, 24),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = 0.97,
    }, frame)

    corner(field, UDim.new(0, 6))
    stroke(field, 0.96)

    make("TextLabel", {
        Text = text,
        TextSize = 12,
        TextColor3 = colors.faint,
        Position = UDim2.fromOffset(10, 0),
        Size = UDim2.new(1, -28, 1, 0),
    }, field)

    local arrow = image(field, "chevron", 9)
    arrow.AnchorPoint = Vector2.new(1, 0.5)
    arrow.Position = UDim2.new(1, -8, 0.5, 0)
    arrow.ImageColor3 = colors.faint
end

local function previewSlider(frame, text)
    local area = make("Frame", {
        AnchorPoint = Vector2.new(1, 0),
        Position = UDim2.new(1, -10, 0, 0),
        Size = UDim2.new(0.47, 0, 1, 0),
    }, frame)

    local number = make("Frame", {
        Position = UDim2.new(0, 0, 0.5, -10),
        Size = UDim2.new(0.45, 0, 0, 20),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = 0.97,
    }, area)

    corner(number, UDim.new(0, 5))
    stroke(number, 0.96)

    local valueLabel = make("TextLabel", {
        Text = text,
        TextSize = 12,
        TextColor3 = colors.faint,
        TextXAlignment = Enum.TextXAlignment.Center,
        Size = UDim2.fromScale(1, 1),
    }, number)

    local track = make("Frame", {
        Position = UDim2.new(0.51, 0, 0.5, -1.5),
        Size = UDim2.new(0.49, 0, 0, 3),
        BackgroundColor3 = colors.faint,
        BackgroundTransparency = 0.3,
    }, area)

    corner(track, UDim.new(1, 0))

    local dot = make("Frame", {
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.fromScale(0, 0.5),
        Size = UDim2.fromOffset(10, 10),
        BackgroundColor3 = colors.sub,
        BackgroundTransparency = 0.35,
    }, track)

    corner(dot, UDim.new(1, 0))

    local maximum = text == "8°" and 180 or 100
    local suffix = text == "8°" and "°" or ""
    local key = frame.Parent.Parent.Name
        .. "/" .. frame.Position.Y.Offset

    local function setValue(value)
        value = math.clamp(
            math.floor(value + 0.5),
            0,
            maximum
        )

        uiState[key] = value
        valueLabel.Text = tostring(value) .. suffix
        dot.Position = UDim2.fromScale(value / maximum, 0.5)
        dot.AnchorPoint = Vector2.new(0.5, 0.5)
    end

    local function update(x)
        setValue(
            (x - track.AbsolutePosition.X)
                / math.max(1, track.AbsoluteSize.X)
                * maximum
        )
    end

    local hit = make("TextButton", {
        Position = UDim2.new(0.51, -8, 0, 0),
        Size = UDim2.new(0.49, 16, 1, 0),
        ZIndex = 5,
    }, area)

    connect(hit.InputBegan, function(input)
        if input.UserInputType ~= Enum.UserInputType.MouseButton1
            and input.UserInputType ~= Enum.UserInputType.Touch then
            return
        end

        gesture = nil
        activeSlider = {
            input = input,
            update = update,
        }

        previewScroll.ScrollingEnabled = false
        update(input.Position.X)
    end)

    setValue(tonumber(string.match(text, "%d+")) or 0)
end

-- Settings section -----------------------------------------------------------
--
-- Two columns on the settings page:
--   * left  - feature rows (language, menu key, hint);
--   * right - the colour panel, docked and visible immediately, no modal.
--
-- The aim section builds its own cards further down (the aimbot closure).

local menuColor = colors.bg
local menuTransparency = window.BackgroundTransparency
local styleHooks = {}

local function onMenuStyleChanged(callback)
    table.insert(styleHooks, callback)
end

local function notifyMenuStyle()
    for _, callback in ipairs(styleHooks) do
        callback(menuColor, menuTransparency)
    end
end

local function applyMenuStyle(color, transparency)
    menuColor = color
    menuTransparency = transparency
    window.BackgroundColor3 = color
    window.BackgroundTransparency = transparency
    notifyMenuStyle()
end

-- The curtain is a cut-out of the menu surface: exactly the menu colour and
-- exactly the menu transparency, no lift and no extra alpha. Anything else
-- reads as a foreign plate stuck on top of the window.
local function languageSurface()
    return menuColor, menuTransparency
end


-- One pointer gesture at a time: sliders and on-screen dragging both run
-- through this channel, so nothing fights over InputChanged.
local function isPressInput(input)
    return input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch
end

local activeDrag

local function beginUIDrag(input, move, release)
    move(input.Position.X, input.Position.Y)
    activeDrag = {
        move = move,
        release = release,
    }
end

connect(UserInputService.InputChanged, function(input)
    if not activeDrag then
        return
    end

    if input.UserInputType ~= Enum.UserInputType.MouseMovement
        and input.UserInputType ~= Enum.UserInputType.Touch then
        return
    end

    activeDrag.move(input.Position.X, input.Position.Y)
end)

connect(UserInputService.InputEnded, function(input)
    if not isPressInput(input) or not activeDrag then
        return
    end

    local drag = activeDrag
    activeDrag = nil

    if drag.release then
        drag.release()
    end
end)

-- watermark surface follows the menu theme (it lives over the world, so it
-- keeps a bit more transparency than the window itself to stay unobtrusive)
local function applyWatermarkTheme()
    local transparency = math.clamp(menuTransparency + 0.5, 0, 0.92)

    for _, surface in ipairs(watermarkPills) do
        surface.BackgroundColor3 = menuColor
        surface.BackgroundTransparency = transparency
    end
end

onMenuStyleChanged(applyWatermarkTheme)

local settings = previewPanel(settingsScroll, "settings.panel", 1, 3)

local function settingField(parent)
    local field = make("TextButton", {
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -10, 0.5, 0),
        Size = UDim2.new(0.47, 0, 0, 24),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = 0.97,
        Text = "",
        Active = true,
        ZIndex = 2,
    }, parent)

    corner(field, UDim.new(0, 6))
    stroke(field, 0.96)

    local label = make("TextLabel", {
        Text = "",
        TextSize = 12,
        TextColor3 = colors.sub,
        TextXAlignment = Enum.TextXAlignment.Center,
        Position = UDim2.fromOffset(6, 0),
        Size = UDim2.new(1, -24, 1, 0),
        ZIndex = 2,
    }, field)

    local arrow = image(field, "chevron", 9)
    arrow.AnchorPoint = Vector2.new(1, 0.5)
    arrow.Position = UDim2.new(1, -8, 0.5, 0)
    arrow.ImageColor3 = colors.faint
    arrow.ZIndex = 2

    return field, label
end

-- language ----------------------------------------------------------------

local languageOrder = { "en", "ru" }

local languageRow, languageLabel = previewRow(settings, 1, "", true)
localize(languageLabel, "settings.language")

local languageField, languageValue = settingField(languageRow)

local function refreshLanguageValue()
    languageValue.Text = currentLanguageName()
end

refreshLanguageValue()

-- Language dropdown (the "curtain"). It lists every language except the
-- active one: with EN selected it offers "русский", after the switch it
-- offers "english". Parented to the window so the scrolling frame / card
-- clipping cannot cut it off, and it inherits the menu surface colour.

local curtainColor, curtainTransparency = languageSurface()

local languageMenu = make("Frame", {
    Name = "LanguageMenu",
    Visible = false,
    Size = UDim2.fromOffset(0, 0),
    BackgroundColor3 = curtainColor,
    BackgroundTransparency = curtainTransparency,
    ClipsDescendants = true,
    ZIndex = 10,
    AnchorPoint = Vector2.new(0, 0),
}, gui)

local languageCorner = corner(languageMenu, UDim.new(0, 10))

-- Flip to true to print the measured geometry (useful if a specific client
-- disagrees about AbsolutePosition).
local DEBUG_LAYOUT = false

-- Places a ScreenGui-level frame exactly at a screen position. Two probe
-- writes measure the local -> screen mapping of the parent (UI scale, insets,
-- rounding), so the result is the same on every client instead of relying on
-- AbsolutePosition and Position sharing one coordinate space.
local function pinToScreen(frame, targetX, targetY)
    frame.Position = UDim2.fromOffset(0, 0)

    local origin = frame.AbsolutePosition

    frame.Position = UDim2.fromOffset(1000, 1000)

    local probe = frame.AbsolutePosition
    local scaleX = (probe.X - origin.X) / 1000
    local scaleY = (probe.Y - origin.Y) / 1000

    if math.abs(scaleX) < 0.001 then
        scaleX = 1
    end

    if math.abs(scaleY) < 0.001 then
        scaleY = 1
    end

    frame.Position = UDim2.fromOffset(
        (targetX - origin.X) / scaleX,
        (targetY - origin.Y) / scaleY
    )

    -- residual correction: whatever is left is a pure offset now
    for _ = 1, 2 do
        local actual = frame.AbsolutePosition
        local errorX = (targetX - actual.X) / scaleX
        local errorY = (targetY - actual.Y) / scaleY

        if math.abs(errorX) < 0.5 and math.abs(errorY) < 0.5 then
            return
        end

        frame.Position = UDim2.fromOffset(
            frame.Position.X.Offset + errorX,
            frame.Position.Y.Offset + errorY
        )
    end
end
stroke(languageMenu, 0.935)

local function refreshLanguageSurface()
    local color, transparency = languageSurface()

    languageMenu.BackgroundColor3 = color
    languageMenu.BackgroundTransparency = transparency
end

onMenuStyleChanged(refreshLanguageSurface)

local languageItems = {}
local closeLanguageMenu

local function clearLanguageItems()
    for _, item in ipairs(languageItems) do
        item:Destroy()
    end

    languageItems = {}
end

closeLanguageMenu = function()
    if not languageMenu.Visible then
        return
    end

    languageMenu.Visible = false
    languageMenu.Size = UDim2.fromOffset(languageMenu.Size.X.Offset, 0)
end

local function openLanguageMenu()
    local scale = menuScale.Scale
    local fieldPosition = languageField.AbsolutePosition
    local fieldSize = languageField.AbsoluteSize

    -- Always drop below the field: top-left anchor, so the height animation
    -- grows downwards and the top edge never moves.
    languageMenu.AnchorPoint = Vector2.new(0, 0)
    languageMenu.Size = UDim2.fromOffset(fieldSize.X, 0)
    pinToScreen(
        languageMenu,
        fieldPosition.X,
        fieldPosition.Y + fieldSize.Y + 4 * scale
    )

    if DEBUG_LAYOUT then
        print(
            "[shitaro] field", fieldPosition.X, fieldPosition.Y,
            fieldSize.X, fieldSize.Y, "scale", scale
        )
        print(
            "[shitaro] curtain",
            languageMenu.AbsolutePosition.X,
            languageMenu.AbsolutePosition.Y,
            "size", languageMenu.Size.X.Offset, languageMenu.Size.Y.Offset
        )
    end

    -- keep the surface in sync with the menu every time it opens
    refreshLanguageSurface()
    languageCorner.CornerRadius = UDim.new(0, 10 * scale)

    clearLanguageItems()

    local index = 0

    for _, id in ipairs(languageOrder) do
        if id ~= currentLanguage then
            local item = make("TextButton", {
                Name = id,
                Position = UDim2.fromOffset(4 * scale, (4 + index * 28) * scale),
                Size = UDim2.new(1, -8 * scale, 0, 26 * scale),
                BackgroundColor3 = Color3.new(1, 1, 1),
                BackgroundTransparency = 1,
                ZIndex = 51,
            }, languageMenu)

            corner(item, UDim.new(0, 6 * scale))

            local label = make("TextLabel", {
                Text = languageNames[id] or id,
                TextSize = 12 * scale,
                TextColor3 = colors.sub,
                TextXAlignment = Enum.TextXAlignment.Center,
                Position = UDim2.fromOffset(0, 0),
                Size = UDim2.fromScale(1, 1),
                ZIndex = 52,
            }, item)

            connect(item.MouseEnter, function()
                animate(item, { BackgroundTransparency = 0.9 }, 0.1)
                animate(label, { TextColor3 = colors.text }, 0.1)
            end)

            connect(item.MouseLeave, function()
                animate(item, { BackgroundTransparency = 1 }, 0.1)
                animate(label, { TextColor3 = colors.sub }, 0.1)
            end)

            connect(item.Activated, function()
                setLanguage(id)
                closeLanguageMenu()
            end)

            table.insert(languageItems, item)
            index = index + 1
        end
    end

    local height = (4 + index * 28) * scale

    languageMenu.Visible = true

    animate(languageMenu, {
        Size = UDim2.fromOffset(fieldSize.X, height),
    }, 0.16)
end

connect(languageField.Activated, function()
    if languageMenu.Visible then
        closeLanguageMenu()
    else
        openLanguageMenu()
    end
end)

-- Click anywhere outside the curtain (but not on the field itself, which
-- owns the toggle) and it slides away.
local function insideRect(origin, size, point)
    return point.X >= origin.X - 2
        and point.X <= origin.X + size.X + 2
        and point.Y >= origin.Y - 2
        and point.Y <= origin.Y + size.Y + 2
end

connect(UserInputService.InputBegan, function(input)
    if not languageMenu.Visible then
        return
    end

    if input.UserInputType ~= Enum.UserInputType.MouseButton1
        and input.UserInputType ~= Enum.UserInputType.Touch then
        return
    end

    if insideRect(
        languageField.AbsolutePosition,
        languageField.AbsoluteSize,
        input.Position
    ) then
        return
    end

    if insideRect(
        languageMenu.AbsolutePosition,
        languageMenu.AbsoluteSize,
        input.Position
    ) then
        return
    end

    closeLanguageMenu()
end)

onLanguageChanged(function()
    refreshLanguageValue()
end)

-- menu key ----------------------------------------------------------------

local bindRow, bindLabel = previewRow(settings, 2, "", true)
localize(bindLabel, "settings.keybind")

local bindField, bindValue = settingField(bindRow)

local bindKey = Enum.KeyCode.Insert
local capturingBind = false

local function refreshBindValue()
    bindValue.Text = capturingBind and "..." or bindKey.Name
end

refreshBindValue()

local function beginBindCapture()
    capturingBind = true
    refreshBindValue()
end

-- Left click / tap resets the field to "..." and starts listening. A second
-- click on the same field aborts the capture and restores the key name.
connect(bindField.Activated, function()
    closeLanguageMenu()

    if capturingBind then
        capturingBind = false
        refreshBindValue()
        return
    end

    beginBindCapture()
end)

-- Right click is kept as an alias for the same reset.
connect(bindField.InputBegan, function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton2 then
        closeLanguageMenu()
        beginBindCapture()
    end
end)

-- colour panel -------------------------------------------------------------
--
-- Docked to the right edge of the settings page: it is simply part of the
-- page, so it is on screen the moment the settings tab opens.
--
-- NOTE: `make()` gives every GuiObject BackgroundTransparency = 1 by default,
-- so any frame that must actually paint has to reset it to 0 explicitly.

-- Wrapped in a block: the chunk already sits near Lua's 200-local limit.
do
local function colorToHex(color)
    local r = math.floor(color.R * 255 + 0.5)
    local g = math.floor(color.G * 255 + 0.5)
    local b = math.floor(color.B * 255 + 0.5)

    return string.format("#%02X%02X%02X", r, g, b)
end

local panelW, panelH = 330, 356
local pad = 16
local content = panelW - pad * 2
local hueW = 26
local svH = 140
local svW = content - hueW - 10

-- The panel lives on the window (not inside the settings page) so it stays on
-- screen the whole time the settings tab is open.
local colorPanel = make("Frame", {
    Name = "ColorPanel",
    Visible = false,
    AnchorPoint = Vector2.new(1, 0),
    Position = UDim2.new(1, -10, 0, 51),
    Size = UDim2.fromOffset(panelW, panelH),
    BackgroundTransparency = 1,
    ClipsDescendants = true,
    ZIndex = 5,
}, window)

-- Same radius / stroke as the window, and no fill of its own: a second
-- layered background would render darker than the menu surface.
corner(colorPanel, UDim.new(0, 10))
stroke(colorPanel, 0.935)

-- the row card fills the space left of the docked panel (10 + gap 20 + panel)
panelWidths[settingsScroll] = window.Size.X.Offset - PANEL_RESERVE
picker.panel = colorPanel

local panelIcon = image(colorPanel, "sliders", 20)
panelIcon.Position = UDim2.fromOffset(pad, 14)
panelIcon.ImageColor3 = colors.accent
panelIcon.ZIndex = 6

picker.title = localize(make("TextLabel", {
    Text = "",
    TextSize = 15,
    FontFace = fonts.bold,
    Position = UDim2.fromOffset(pad + 28, 10),
    Size = UDim2.new(1, -60, 0, 18),
    ZIndex = 6,
}, colorPanel), "palette.title")

picker.subtitle = localize(make("TextLabel", {
    Text = "",
    TextSize = 12,
    TextColor3 = colors.dim,
    Position = UDim2.fromOffset(pad + 28, 28),
    Size = UDim2.new(1, -60, 0, 14),
    ZIndex = 6,
}, colorPanel), "palette.subtitle")


-- live preview bar
local previewBar = make("Frame", {
    Name = "PreviewBar",
    Position = UDim2.fromOffset(pad, 58),
    Size = UDim2.fromOffset(content, 26),
    BackgroundColor3 = menuColor,
    BackgroundTransparency = menuTransparency,
    ZIndex = 6,
}, colorPanel)

corner(previewBar, UDim.new(0, 8))
stroke(previewBar, 0.94)

-- saturation / value square -------------------------------------------------

local svY = 96

local sv = make("Frame", {
    Name = "SVArea",
    Position = UDim2.fromOffset(pad, svY),
    Size = UDim2.fromOffset(svW, svH),
    BackgroundColor3 = Color3.fromHSV(1, 1, 1),
    BackgroundTransparency = 0,
    ZIndex = 6,
}, colorPanel)

corner(sv, UDim.new(0, 8))

local svWhite = make("Frame", {
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0,
    ZIndex = 6,
}, sv)

corner(svWhite, UDim.new(0, 8))

make("UIGradient", {
    Color = ColorSequence.new(Color3.new(1, 1, 1)),
    Transparency = NumberSequence.new(0, 1),
}, svWhite)

local svBlack = make("Frame", {
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.new(0, 0, 0),
    BackgroundTransparency = 0,
    ZIndex = 7,
}, sv)

corner(svBlack, UDim.new(0, 8))

make("UIGradient", {
    Color = ColorSequence.new(Color3.new(0, 0, 0)),
    Transparency = NumberSequence.new(1, 0),
    Rotation = 90,
}, svBlack)

local svCursor = make("Frame", {
    AnchorPoint = Vector2.new(0.5, 0.5),
    Size = UDim2.fromOffset(14, 14),
    BackgroundTransparency = 1,
    ZIndex = 8,
}, sv)

corner(svCursor, UDim.new(1, 0))

make("UIStroke", {
    Color = Color3.new(1, 1, 1),
    Transparency = 0.1,
    Thickness = 2,
}, svCursor)

-- hue strip ----------------------------------------------------------------

local hueBar = make("Frame", {
    Name = "HueBar",
    Position = UDim2.fromOffset(pad + svW + 10, svY),
    Size = UDim2.fromOffset(hueW, svH),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0,
    ZIndex = 6,
}, colorPanel)

corner(hueBar, UDim.new(1, 0))

make("UIGradient", {
    Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 0, 0)),
        ColorSequenceKeypoint.new(0.17, Color3.fromRGB(255, 255, 0)),
        ColorSequenceKeypoint.new(0.33, Color3.fromRGB(0, 255, 0)),
        ColorSequenceKeypoint.new(0.50, Color3.fromRGB(0, 255, 255)),
        ColorSequenceKeypoint.new(0.67, Color3.fromRGB(0, 0, 255)),
        ColorSequenceKeypoint.new(0.83, Color3.fromRGB(255, 0, 255)),
        ColorSequenceKeypoint.new(1.00, Color3.fromRGB(255, 0, 0)),
    }),
    Rotation = 90,
}, hueBar)

local hueCursor = make("Frame", {
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0),
    Size = UDim2.new(1, 8, 0, 12),
    BackgroundTransparency = 1,
    ZIndex = 8,
}, hueBar)

corner(hueCursor, UDim.new(1, 0))

make("UIStroke", {
    Color = Color3.new(1, 1, 1),
    Transparency = 0.05,
    Thickness = 2,
}, hueCursor)

local svHit = make("TextButton", {
    Name = "SVHit",
    Size = UDim2.fromScale(1, 1),
    BackgroundTransparency = 1,
    Text = "",
    ZIndex = 9,
}, sv)

local hueHit = make("TextButton", {
    Name = "HueHit",
    Size = UDim2.fromScale(1, 1),
    BackgroundTransparency = 1,
    Text = "",
    ZIndex = 9,
}, hueBar)

-- hex readout --------------------------------------------------------------

local hexY = svY + svH + 12

local hexSwatch = make("Frame", {
    Name = "HexSwatch",
    Position = UDim2.fromOffset(pad, hexY),
    Size = UDim2.fromOffset(24, 24),
    BackgroundColor3 = menuColor,
    BackgroundTransparency = 0,
    ZIndex = 6,
}, colorPanel)

corner(hexSwatch, UDim.new(0, 6))
stroke(hexSwatch, 0.86)

local hexLabel = make("TextLabel", {
    Text = "",
    TextSize = 14,
    FontFace = fonts.bold,
    Position = UDim2.fromOffset(pad + 32, hexY),
    Size = UDim2.fromOffset(120, 24),
    ZIndex = 6,
}, colorPanel)

-- transparency slider ------------------------------------------------------

local opacityLabelY = hexY + 32

picker.opacityTitle = localize(make("TextLabel", {
    Text = "",
    TextSize = 12,
    TextColor3 = colors.dim,
    Position = UDim2.fromOffset(pad, opacityLabelY),
    Size = UDim2.fromOffset(92, 18),
    ZIndex = 6,
}, colorPanel), "settings.opacity")

local opValue = make("TextLabel", {
    Text = "",
    TextSize = 12,
    TextColor3 = colors.sub,
    TextXAlignment = Enum.TextXAlignment.Right,
    Position = UDim2.fromOffset(panelW - pad - 48, opacityLabelY),
    Size = UDim2.fromOffset(48, 18),
    ZIndex = 6,
}, colorPanel)

local opTrackX = pad + 96
local opTrackW = panelW - pad - 58 - opTrackX

local opTrack = make("Frame", {
    Name = "OpacityTrack",
    Position = UDim2.fromOffset(opTrackX, opacityLabelY + 8),
    Size = UDim2.fromOffset(opTrackW, 4),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.84,
    ZIndex = 6,
}, colorPanel)

corner(opTrack, UDim.new(1, 0))

local opFill = make("Frame", {
    Name = "OpacityFill",
    Size = UDim2.fromScale(0, 1),
    BackgroundColor3 = colors.accent,
    BackgroundTransparency = 0.35,
    ZIndex = 7,
}, opTrack)

corner(opFill, UDim.new(1, 0))

local opKnob = make("Frame", {
    Name = "OpacityKnob",
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0, 0.5),
    Size = UDim2.fromOffset(12, 12),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.05,
    ZIndex = 8,
}, opTrack)

corner(opKnob, UDim.new(1, 0))

local opHit = make("TextButton", {
    Name = "OpacityHit",
    Position = UDim2.new(0, 0, 0, -10),
    Size = UDim2.new(1, 0, 0, 24),
    BackgroundTransparency = 1,
    Text = "",
    ZIndex = 9,
}, opTrack)

-- buttons ------------------------------------------------------------------

local buttonY = opacityLabelY + 34

local resetButton = make("TextButton", {
    Name = "PickerReset",
    Position = UDim2.fromOffset(pad, buttonY),
    Size = UDim2.fromOffset(94, 30),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.94,
    Text = "",
    ZIndex = 6,
}, colorPanel)

corner(resetButton, UDim.new(0, 8))
stroke(resetButton, 0.9)

localize(make("TextLabel", {
    Text = "",
    TextSize = 13,
    TextColor3 = colors.sub,
    TextXAlignment = Enum.TextXAlignment.Center,
    Size = UDim2.fromScale(1, 1),
    ZIndex = 7,
}, resetButton), "palette.reset")

local applyButton = make("TextButton", {
    Name = "PickerApply",
    Position = UDim2.fromOffset(pad + 104, buttonY),
    Size = UDim2.fromOffset(panelW - pad * 2 - 104, 30),
    BackgroundColor3 = colors.accent,
    BackgroundTransparency = 0.78,
    Text = "",
    ZIndex = 6,
}, colorPanel)

corner(applyButton, UDim.new(0, 8))

make("UIStroke", {
    Color = colors.accent,
    Transparency = 0.45,
    Thickness = 1,
    ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
}, applyButton)

localize(make("TextLabel", {
    Text = "",
    TextSize = 13,
    FontFace = fonts.bold,
    TextColor3 = colors.text,
    TextXAlignment = Enum.TextXAlignment.Center,
    Size = UDim2.fromScale(1, 1),
    ZIndex = 7,
}, applyButton), "palette.apply")

-- esp targets edit a plain colour: no transparency row, panel is shorter
function picker.layoutFor(kind)
    local esp = kind == "esp"
    local shift = esp and 34 or 0

    picker.opacityTitle.Visible = not esp
    opValue.Visible = not esp
    opTrack.Visible = not esp

    resetButton.Position = UDim2.fromOffset(pad, buttonY - shift)
    applyButton.Position = UDim2.fromOffset(pad + 104, buttonY - shift)
    colorPanel.Size = UDim2.fromOffset(panelW, panelH - shift)
end

-- picker state -------------------------------------------------------------

local pickedHue, pickedSat, pickedVal = menuColor:ToHSV()
local pickedAlpha = menuTransparency

local function pickedColor()
    return Color3.fromHSV(pickedHue, pickedSat, pickedVal)
end

local function refreshPalette()
    local color = pickedColor()

    sv.BackgroundColor3 = Color3.fromHSV(pickedHue, 1, 1)
    svCursor.Position = UDim2.fromScale(pickedSat, 1 - pickedVal)
    hueCursor.Position = UDim2.fromScale(0.5, pickedHue)
    previewBar.BackgroundColor3 = color
    previewBar.BackgroundTransparency = pickedAlpha
    hexSwatch.BackgroundColor3 = color
    hexLabel.Text = colorToHex(color)
    -- 0 % = fully opaque at the far left, 100 % = fully transparent at the
    -- far right; handle and fill travel with the value, never against it.
    opValue.Text = tostring(math.floor(pickedAlpha * 100 + 0.5)) .. "%"
    opFill.Size = UDim2.fromScale(pickedAlpha, 1)
    opKnob.Position = UDim2.fromScale(pickedAlpha, 0.5)

    -- esp colours are applied live while dragging
    if picker.target and picker.target.kind == "esp"
        and picker.target.apply then
        picker.target.apply(color)
    end
end

local function updateFromSV(x, y)
    local origin = sv.AbsolutePosition
    local size = sv.AbsoluteSize

    pickedSat = math.clamp((x - origin.X) / math.max(1, size.X), 0, 1)
    pickedVal = 1 - math.clamp((y - origin.Y) / math.max(1, size.Y), 0, 1)
    refreshPalette()
end

local function updateFromHue(x, y)
    local origin = hueBar.AbsolutePosition
    local size = hueBar.AbsoluteSize

    pickedHue = math.clamp((y - origin.Y) / math.max(1, size.Y), 0, 1)
    refreshPalette()
end

local function updateFromOpacity(x, y)
    local origin = opTrack.AbsolutePosition
    local size = opTrack.AbsoluteSize

    pickedAlpha = math.clamp((x - origin.X) / math.max(1, size.X), 0, 1)
    refreshPalette()
end

-- picker target -------------------------------------------------------------
-- The panel edits the window surface: menu colour + menu transparency.

function picker.refreshText()
    local target = picker.target

    if target and target.kind == "esp" then
        picker.title.Text = L("esp.picker.title")
        picker.subtitle.Text = L("esp." .. target.feature)
            .. " - " .. L("esp.state." .. target.state)
    else
        picker.title.Text = L("palette.title")
        picker.subtitle.Text = L("palette.subtitle")
    end
end

function picker.notify()
    for _, callback in ipairs(picker.listeners) do
        callback()
    end
end

function picker.setTarget(target, color)
    picker.target = target

    local hue, sat, val = color:ToHSV()

    pickedHue, pickedSat, pickedVal = hue, sat, val
    pickedAlpha = target.kind == "menu"
        and window.BackgroundTransparency
        or 0

    picker.layoutFor(target.kind)
    refreshPalette()
    picker.refreshText()
end

function picker.sync(tab)
    -- leaving the visuals tab closes an open esp colour editor
    if picker.espOpen and tab ~= tabs[3] and picker.onLeave then
        picker.onLeave()
    end

    if tab == tabs[6] then
        picker.setTarget({ kind = "menu" }, window.BackgroundColor3)
        colorPanel.Visible = true
    elseif tab == tabs[3] and picker.espOpen then
        colorPanel.Visible = true
    else
        colorPanel.Visible = false
    end
end

-- the committed value is applied once the pointer is released
local function commitPalette()
    if picker.target and picker.target.kind == "esp" then
        if picker.target.apply then
            picker.target.apply(pickedColor())
        end

        return
    end

    applyMenuStyle(pickedColor(), pickedAlpha)
end

connect(svHit.InputBegan, function(input)
    if not isPressInput(input) then
        return
    end

    beginUIDrag(input, updateFromSV, commitPalette)
end)

connect(hueHit.InputBegan, function(input)
    if not isPressInput(input) then
        return
    end

    beginUIDrag(input, updateFromHue, commitPalette)
end)

connect(opHit.InputBegan, function(input)
    if not isPressInput(input) then
        return
    end

    beginUIDrag(input, updateFromOpacity, commitPalette)
end)

connect(resetButton.Activated, function()
    if picker.target and picker.target.kind == "esp"
        and picker.target.default then
        pickedHue, pickedSat, pickedVal = picker.target.default:ToHSV()
    else
        pickedHue, pickedSat, pickedVal = colors.bg:ToHSV()
        pickedAlpha = 0.16
    end

    refreshPalette()
end)

connect(applyButton.Activated, function()
    commitPalette()

    -- an esp colour is already live: "apply" just closes the editor
    if picker.target and picker.target.kind == "esp" and picker.onLeave then
        picker.onLeave()
    end
end)


onLanguageChanged(function()
    picker.refreshText()
end)

refreshPalette()
picker.refreshText()
end

-- watermark card -----------------------------------------------------------

local watermarkOffset = Vector2.new(0, 0)
local watermarkSizePercent = 100

local function applyWatermarkLayout()
    watermarkScale.Scale = watermarkSizePercent / 100
    watermark.Position = UDim2.new(
        1,
        watermarkOffset.X,
        0,
        watermarkOffset.Y
    )
end

-- compact slider used by the watermark rows (no instances are created while
-- dragging: only Position/Size/Text of existing objects change)
local function rowSlider(row, name, minValue, maxValue, format, onChange)
    local area = make("Frame", {
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, -10, 0.5, 0),
        Size = UDim2.new(0.47, 0, 0, 24),
        ZIndex = 2,
    }, row)

    local valueLabel = make("TextLabel", {
        Name = name,
        Text = "",
        TextSize = 12,
        TextColor3 = colors.sub,
        TextXAlignment = Enum.TextXAlignment.Right,
        AnchorPoint = Vector2.new(1, 0.5),
        Position = UDim2.new(1, 0, 0.5, 0),
        Size = UDim2.fromOffset(54, 18),
        ZIndex = 2,
    }, area)

    local track = make("Frame", {
        Name = name .. "Track",
        Position = UDim2.new(0, 0, 0.5, -2),
        Size = UDim2.new(1, -62, 0, 4),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = 0.84,
        ZIndex = 2,
    }, area)

    corner(track, UDim.new(1, 0))

    local fill = make("Frame", {
        Size = UDim2.fromScale(0, 1),
        BackgroundColor3 = colors.accent,
        BackgroundTransparency = 0.35,
        ZIndex = 3,
    }, track)

    corner(fill, UDim.new(1, 0))

    local knob = make("Frame", {
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0, 0.5),
        Size = UDim2.fromOffset(12, 12),
        BackgroundColor3 = Color3.new(1, 1, 1),
        BackgroundTransparency = 0.05,
        ZIndex = 4,
    }, track)

    corner(knob, UDim.new(1, 0))

    local hit = make("TextButton", {
        Name = name .. "Hit",
        Position = UDim2.new(0, 0, 0, -10),
        Size = UDim2.new(1, 0, 0, 24),
        BackgroundTransparency = 1,
        Text = "",
        ZIndex = 5,
    }, track)

    local value = minValue

    local function paint()
        local span = math.max(0.0001, maxValue - minValue)
        local fraction = (value - minValue) / span

        fill.Size = UDim2.fromScale(fraction, 1)
        knob.Position = UDim2.fromScale(fraction, 0.5)
        valueLabel.Text = format(value)
    end

    local function set(newValue, notify)
        value = math.clamp(newValue, minValue, maxValue)
        paint()

        if notify and onChange then
            onChange(value)
        end
    end

    local function moveTo(x)
        local origin = track.AbsolutePosition
        local size = track.AbsoluteSize
        local fraction = math.clamp((x - origin.X) / math.max(1, size.X), 0, 1)

        set(minValue + fraction * (maxValue - minValue), true)
    end

    connect(hit.InputBegan, function(input)
        if not isPressInput(input) then
            return
        end

        beginUIDrag(input, moveTo, nil)
    end)

    paint()

    return {
        set = set,
        get = function()
            return value
        end,
    }
end

local wmSliders = {}

local function setWatermarkOffset(x, y)
    watermarkOffset = Vector2.new(
        math.clamp(x, -800, 800),
        math.clamp(y, -500, 500)
    )

    applyWatermarkLayout()
    wmSliders.x.set(watermarkOffset.X, false)
    wmSliders.y.set(watermarkOffset.Y, false)
end

-- size
local watermarkCard, watermarkHolder = previewPanel(settingsScroll, "settings.watermark", 2, 4)

-- The watermark block simply sits a little under the language / menu-key
-- card: same column, just a bit more air than the default 12 px gap.
panelGapBefore[watermarkHolder] = 16

local wmSizeRow, wmSizeLabel = previewRow(watermarkCard, 1, "", true)
localize(wmSizeLabel, "settings.wmScale")

wmSliders.size = rowSlider(
    wmSizeRow,
    "WatermarkSize",
    50,
    200,
    function(value)
        return tostring(math.floor(value + 0.5)) .. "%"
    end,
    function(value)
        watermarkSizePercent = value
        applyWatermarkLayout()
    end
)

wmSliders.size.set(watermarkSizePercent, false)

-- position X
local wmXRow, wmXLabel = previewRow(watermarkCard, 2, "", true)
localize(wmXLabel, "settings.wmX")

wmSliders.x = rowSlider(
    wmXRow,
    "WatermarkX",
    -800,
    800,
    function(value)
        local rounded = math.floor(value + 0.5)

        if rounded > 0 then
            return "+" .. rounded .. " px"
        end

        return tostring(rounded) .. " px"
    end,
    function(value)
        setWatermarkOffset(value, watermarkOffset.Y)
    end
)

wmSliders.x.set(watermarkOffset.X, false)

-- position Y
local wmYRow, wmYLabel = previewRow(watermarkCard, 3, "", true)
localize(wmYLabel, "settings.wmY")

wmSliders.y = rowSlider(
    wmYRow,
    "WatermarkY",
    -500,
    500,
    function(value)
        return tostring(math.floor(value + 0.5)) .. " px"
    end,
    function(value)
        setWatermarkOffset(watermarkOffset.X, value)
    end
)

wmSliders.y.set(watermarkOffset.Y, false)

-- reset
local wmResetRow = previewRow(watermarkCard, 4, "", false)

local wmResetButton = make("TextButton", {
    Name = "WatermarkReset",
    AnchorPoint = Vector2.new(1, 0.5),
    Position = UDim2.new(1, -10, 0.5, 0),
    Size = UDim2.new(0.47, 0, 0, 24),
    BackgroundColor3 = Color3.new(1, 1, 1),
    BackgroundTransparency = 0.94,
    Text = "",
    ZIndex = 2,
}, wmResetRow)

corner(wmResetButton, UDim.new(0, 6))
stroke(wmResetButton, 0.9)

localize(make("TextLabel", {
    Text = "",
    TextSize = 11,
    TextColor3 = colors.sub,
    TextXAlignment = Enum.TextXAlignment.Center,
    Size = UDim2.fromScale(1, 1),
    ZIndex = 3,
}, wmResetButton), "settings.wmReset")

connect(wmResetButton.Activated, function()
    watermarkSizePercent = 100
    wmSliders.size.set(watermarkSizePercent, false)
    setWatermarkOffset(0, 0)
    applyWatermarkLayout()
end)

local hintRow, hintLabel = previewRow(settings, 3, "", false)
localize(hintLabel, "settings.hint")
hintLabel.TextSize = 11

applyWatermarkLayout()
applyWatermarkTheme()

-- UIScale scales all children together.

local function layoutPreview()
    local width = window.Size.X.Offset
    local columnWidth = (width - 36) / 3

    for parent, group in pairs(panelGroups) do
        -- The space the cards actually get: on the settings page the right
        -- docked colour panel already takes 370 px away, so "narrow" has to be
        -- judged against the free area, not against the window width.
        local available = panelWidths[parent] or (width - 20)
        local narrow = available < 620

        local y = 10

        for index, panel in ipairs(group) do
            -- The gap is the space this panel asks for *above itself*, so it
            -- has to be applied before the panel is placed.
            if narrow and index > 1 then
                y = y + (panelGapBefore[panel] or 12)
            end

            panel.Position = narrow
                and UDim2.fromOffset(10, y)
                or UDim2.fromOffset(
                    10 + (index - 1) * (columnWidth + 8),
                    10
                )

            panel.Size = UDim2.fromOffset(available, panel.Size.Y.Offset)

            if narrow then
                y = y + panel.Size.Y.Offset
            end
        end
    end
end

local function clampWindow()
    local size = window.AbsoluteSize
    local position = window.Position

    window.Position = UDim2.fromOffset(
        math.clamp(
            position.X.Offset,
            safeOrigin.X,
            safeOrigin.X + math.max(0, safeSize.X - size.X)
        ),
        math.clamp(
            position.Y.Offset,
            safeOrigin.Y,
            safeOrigin.Y + math.max(0, safeSize.Y - size.Y)
        )
    )
end

local function layoutNavigation()
    local width = window.Size.X.Offset
    local touch = false
    local narrow = width < 620
    local cellHeight = touch and 44 or 26

    local navHeight = narrow
        and (cellHeight * 2 + 8)
        or (cellHeight + 6)

    nav.Size = UDim2.fromOffset(
        narrow and (width - 20) or 0,
        navHeight
    )

    nav.AutomaticSize = narrow
        and Enum.AutomaticSize.None
        or Enum.AutomaticSize.X

    navCorner.CornerRadius = UDim.new(
        0,
        narrow and 12 or math.floor(navHeight / 2)
    )

    body.Size = UDim2.new(
        1, 0,
        1, -(41 + navHeight + 17)
    )

    tabRow.Size = UDim2.fromOffset(
        narrow and (width - 26) or 0,
        navHeight - 6
    )

    tabRow.AutomaticSize = narrow
        and Enum.AutomaticSize.None
        or Enum.AutomaticSize.X

    local useGrid = navigationLayout:IsA("UIGridLayout")

    if narrow ~= useGrid then
        navigationLayout:Destroy()

        if narrow then
            navigationLayout = make("UIGridLayout", {
                SortOrder = Enum.SortOrder.LayoutOrder,
                FillDirection = Enum.FillDirection.Horizontal,
                FillDirectionMaxCells = 3,
            }, tabRow)
        else
            navigationLayout = row(tabRow, 2)
        end
    end

    if narrow then
        navigationLayout.CellPadding = UDim2.fromOffset(2, 2)
        navigationLayout.CellSize = UDim2.new(
            1 / 3, -4 / 3,
            0, cellHeight
        )
    end

    for _, tab in ipairs(tabs) do
        tab.button.AutomaticSize = narrow
            and Enum.AutomaticSize.None
            or Enum.AutomaticSize.X

        tab.button.Size = UDim2.fromOffset(0, cellHeight)
    end

    highlight.Visible = not narrow

    for _, tab in ipairs(tabs) do
        tab.button.BackgroundColor3 = Color3.new(1, 1, 1)
        tab.button.BackgroundTransparency =
            narrow and tab == selected and 0.925 or 1
    end

    task.defer(updateHighlight)
    layoutPreview()
end

local function fitScreen()
    gesture = nil
    applyWatermarkLayout()

    local viewport = gui.AbsoluteSize
    safeOrigin = Vector2.zero

    safeSize = Vector2.new(
        math.max(1, viewport.X),
        math.max(1, viewport.Y)
    )

    -- Reference screenshot: 1568 x 724.
    -- Approximate window bounds: (224, 14) to (1300, 662).
    local referenceScale = math.min(
        safeSize.X / 1568,
        safeSize.Y / 724
    )

    menuScale.Scale = (1076 / 780) * referenceScale
    window.Size = UDim2.fromOffset(780, 470)

    window.Position = UDim2.fromOffset(
        (safeSize.X - 1568 * referenceScale) / 2
            + 224 * referenceScale,
        (safeSize.Y - 724 * referenceScale) / 2
            + 14 * referenceScale
    )

    layoutNavigation()
end

-- Translated labels change width, so the highlight/nav must be redrawn.
onLanguageChanged(function()
    task.defer(function()
        layoutNavigation()
        updateHighlight()
    end)
end)

connect(
    gui:GetPropertyChangedSignal("AbsoluteSize"),
    fitScreen
)

connect(
    window:GetPropertyChangedSignal("Size"),
    layoutNavigation
)

connect(
    UserInputService:GetPropertyChangedSignal("TouchEnabled"),
    layoutNavigation
)

for _, tab in ipairs(tabs) do
    connect(tab.button.Activated, function()
        closeLanguageMenu()
        task.defer(layoutNavigation)
    end)
end

-- Input

local function beginGesture(input, target, resize)
    if input.UserInputType ~= Enum.UserInputType.MouseButton1
        and input.UserInputType ~= Enum.UserInputType.Touch then
        return
    end

    gesture = {
        input = input,
        target = target,
        resize = resize,
        origin = input.Position,
        position = target.Position,
        size = target.Size,
        scale = menuScale.Scale,
    }
end

-- Use GUI hit-testing instead of comparing global and GUI coordinates.
dragHandle.ZIndex = 30
dragHandle.Active = true

connect(dragHandle.InputBegan, function(input)
    if not window.Visible then
        return
    end

    beginGesture(input, window, false)
end)

connect(grip.InputBegan, function(input)
    beginGesture(input, window, true)
end)

-- The watermark itself is the button; no full-screen input layer.
-- Visuals / ESP ------------------------------------------------------------
--
-- Rendering uses plain Frames in a separate ScreenGui, so it does not depend
-- on the executor's Drawing library. Everything lives in one closure: it adds
-- nothing to the main chunk's 200-local budget, and a failure here can never
-- break the menu (errors are only printed with warn).
--
-- Rig detection is structural (UpperTorso/LowerTorso = R15, Torso = R6,
-- anything else = generic Motor6D skeleton), not trusted from Humanoid.RigType,
-- because custom games often lie about it.

xpcall(function()
    local Workspace = game:GetService("Workspace")
    local floor, ceil, clamp = math.floor, math.ceil, math.clamp
    local huge = math.huge

    local FEATURES = {
        "box", "line", "name", "distance", "skeleton", "health",
    }

    local RED = Color3.fromRGB(255, 72, 72)
    local GREEN = Color3.fromRGB(72, 255, 112)
    local WHITE = Color3.new(1, 1, 1)
    local BLACK = Color3.new(0, 0, 0)
    local ORANGE = Color3.fromRGB(255, 150, 40)
    local BLUE = Color3.fromRGB(64, 140, 255)
    local BOT_NAME = "бот"

    -- where the line starts on the screen: "top" | "center" | "bottom"
    local LINE_ORIGIN = "top"

    -- Stale data: with streaming, a far player's parts can stop updating. A
    -- player further than STALE_MIN_DIST whose position did not change for
    -- STALE_AFTER seconds is "unverified" (also true for a player who really
    -- stands still). STALE_MODE: "mark" = draw with a "?" after name/distance,
    -- "hide" = do not draw.
    -- cover / skeleton cadence (see drawEntity)
    local COVER_INTERVAL = 0.1
    local COVER_FAR_INTERVAL = 0.25
    local COVER_FAR_DIST = 200
    local SKELETON_FAR_DIST = 80

    local STALE_AFTER = 3
    local STALE_MIN_DIST = 60
    local STALE_MODE = "hide"

    -- Roblox: 1 stud = 0.28 m. The game HUD shows metres, so the ESP distance
    -- label and the range slider (0-800) use metres as well.
    local STUDS_TO_M = 0.28

    local cfg = {
        enabled = {},
        palette = {},
        ignoreTeam = false,
        ignoreFriends = false,
        range = 500,
    }

    for _, key in ipairs(FEATURES) do
        cfg.enabled[key] = false
        -- visible = enemy is exposed (red), hidden = behind cover (green)
        cfg.palette[key] = { visible = RED, hidden = GREEN }
    end

    -- bots: orange = exposed, blue = behind cover
    cfg.enabled.bots = false
    cfg.palette.bots = { visible = ORANGE, hidden = BLUE }

    -- Overlay -----------------------------------------------------------------

    local stale = playerGui:FindFirstChild("ShitaroESP")

    if stale then
        stale:Destroy()
    end

    local overlay = make("ScreenGui", {
        Name = "ShitaroESP",
        IgnoreGuiInset = true,
        ResetOnSpawn = false,
        ScreenInsets = Enum.ScreenInsets.None,
        ClipToDeviceSafeArea = false,
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
        DisplayOrder = 9000,
    }, playerGui)

    -- Rig descriptions --------------------------------------------------------
    -- Each point is {part name, mode}: mode 1 = part centre, 2 = top centre,
    -- 3 = bottom centre. Using part extents instead of joint names keeps the
    -- skeleton correct for scaled characters.

    local RIGS = {
        R15 = {
            points = {
                { "Head", 1 },              -- 1
                { "UpperTorso", 2 },        -- 2 neck
                { "LowerTorso", 1 },        -- 3 pelvis
                { "LeftUpperArm", 2 },      -- 4 shoulder
                { "LeftUpperArm", 3 },      -- 5 elbow
                { "LeftLowerArm", 3 },      -- 6 wrist
                { "LeftHand", 3 },          -- 7 fingertip
                { "RightUpperArm", 2 },     -- 8
                { "RightUpperArm", 3 },     -- 9
                { "RightLowerArm", 3 },     -- 10
                { "RightHand", 3 },         -- 11
                { "LeftUpperLeg", 2 },      -- 12 hip
                { "LeftUpperLeg", 3 },      -- 13 knee
                { "LeftLowerLeg", 3 },      -- 14 ankle
                { "LeftFoot", 3 },          -- 15 sole
                { "RightUpperLeg", 2 },     -- 16
                { "RightUpperLeg", 3 },     -- 17
                { "RightLowerLeg", 3 },     -- 18
                { "RightFoot", 3 },         -- 19
            },
            bones = {
                { 1, 2 }, { 2, 3 },
                { 2, 4 }, { 4, 5 }, { 5, 6 }, { 6, 7 },
                { 2, 8 }, { 8, 9 }, { 9, 10 }, { 10, 11 },
                { 3, 12 }, { 12, 13 }, { 13, 14 }, { 14, 15 },
                { 3, 16 }, { 16, 17 }, { 17, 18 }, { 18, 19 },
            },
            body = "UpperTorso",
            feet = { "LeftFoot", "RightFoot" },
        },

        R6 = {
            points = {
                { "Head", 1 },              -- 1
                { "Torso", 2 },             -- 2 neck
                { "Torso", 3 },             -- 3 pelvis
                { "Left Arm", 2 },          -- 4 shoulder
                { "Left Arm", 3 },          -- 5 hand
                { "Right Arm", 2 },         -- 6
                { "Right Arm", 3 },         -- 7
                { "Left Leg", 2 },          -- 8 hip
                { "Left Leg", 3 },          -- 9 sole
                { "Right Leg", 2 },         -- 10
                { "Right Leg", 3 },         -- 11
            },
            bones = {
                { 1, 2 }, { 2, 3 },
                { 2, 4 }, { 4, 5 },
                { 2, 6 }, { 6, 7 },
                { 3, 8 }, { 8, 9 },
                { 3, 10 }, { 10, 11 },
            },
            body = "Torso",
            feet = { "Left Leg", "Right Leg" },
        },
    }

    local CORNERS = {}

    for _, sx in ipairs({ -1, 1 }) do
        for _, sy in ipairs({ -1, 1 }) do
            for _, sz in ipairs({ -1, 1 }) do
                table.insert(CORNERS, Vector3.new(sx, sy, sz))
            end
        end
    end

    local function buildRig(char, now)
        local rig = {
            char = char,
            parts = {},
            modes = {},
            bones = {},
            count = 0,
            feet = {},
            samples = {},
            retry = now + 1,
        }

        rig.head = char:FindFirstChild("Head")

        local def

        if char:FindFirstChild("UpperTorso")
            and char:FindFirstChild("LowerTorso") then
            def = RIGS.R15
            rig.kind = "R15"
        elseif char:FindFirstChild("Torso") then
            def = RIGS.R6
            rig.kind = "R6"
        else
            rig.kind = "generic"
        end

        rig.root = char:FindFirstChild("HumanoidRootPart")
            or char.PrimaryPart

        if def then
            rig.body = char:FindFirstChild(def.body)
            rig.root = rig.root or rig.body
            rig.bones = def.bones
            rig.count = #def.points

            local complete = rig.head ~= nil and rig.body ~= nil

            for index, entry in ipairs(def.points) do
                local part = char:FindFirstChild(entry[1])

                if part and part:IsA("BasePart") then
                    rig.parts[index] = part
                else
                    complete = false
                end

                rig.modes[index] = entry[2]
            end

            for _, name in ipairs(def.feet) do
                local foot = char:FindFirstChild(name)

                if foot and foot:IsA("BasePart") then
                    table.insert(rig.feet, foot)
                else
                    complete = false
                end
            end

            -- a rig that is still streaming in is re-scanned every second
            if complete then
                rig.retry = huge
            end
        else
            rig.root = rig.root or char:FindFirstChildWhichIsA("BasePart")

            local index = {}

            local function point(part)
                local found = index[part]

                if not found then
                    rig.count = rig.count + 1
                    found = rig.count
                    index[part] = found
                    rig.parts[found] = part
                    rig.modes[found] = 1
                end

                return found
            end

            for _, item in ipairs(char:GetDescendants()) do
                if #rig.bones >= 30 then
                    break
                end

                if item:IsA("Motor6D") then
                    local a, b = item.Part0, item.Part1

                    if a and b
                        and a:IsA("BasePart") and b:IsA("BasePart")
                        and a ~= rig.root and b ~= rig.root then
                        table.insert(rig.bones, { point(a), point(b) })
                    end
                end
            end
        end

        if rig.head then
            table.insert(rig.samples, rig.head)
        end

        if rig.root then
            table.insert(rig.samples, rig.root)
        end

        if rig.feet[1] then
            table.insert(rig.samples, rig.feet[1])
        end

        return rig
    end

    -- Coherence ----------------------------------------------------------------
    -- With streaming, the parts of ONE character can arrive at different times:
    -- the root may already be at the real position while head / feet / limbs
    -- still sit at an old one. Mixing them gives boxes floating in the sky or
    -- shifted sideways. Every part is compared with a reference part; parts
    -- further than SPAN studs from the best-agreeing group are ignored.
    local SPAN = 12
    local SPAN2 = SPAN * SPAN

    local function coherence(rig)
        local list = rig.list

        if not list then
            list = {}
            local seen = {}

            local function add(part)
                if part and not seen[part] then
                    seen[part] = true
                    list[#list + 1] = part
                end
            end

            add(rig.root)
            add(rig.head)
            add(rig.body)

            for index = 1, rig.count do
                add(rig.parts[index])
            end

            for _, foot in ipairs(rig.feet) do
                add(foot)
            end

            rig.list = list
            rig.valid = {}
        end

        -- Same rule as before (root, then body, then head; the first one with
        -- the largest agreeing group wins), but every part position is read
        -- once instead of three times, the distances are compared squared (no
        -- square root), and the freshness signature is summed in the same pass
        -- - this used to be the hottest loop of the renderer.
        local refs = rig.refs

        if not refs then
            refs = { {}, {}, {} }
            rig.refs = refs
        end

        for index = 1, 3 do
            local candidate

            if index == 1 then
                candidate = rig.root
            elseif index == 2 then
                candidate = rig.body
            else
                candidate = rig.head
            end

            local slot = refs[index]

            if candidate and candidate.Parent then
                slot.pos = candidate.Position
            else
                slot.pos = nil
            end

            slot.agree = 0
        end

        for j = 1, #list do
            local part = list[j]

            if part.Parent then
                local pos = part.Position

                for index = 1, 3 do
                    local slot = refs[index]
                    local ref = slot.pos

                    if ref then
                        local dx, dy, dz = pos.X - ref.X, pos.Y - ref.Y, pos.Z - ref.Z

                        if dx * dx + dy * dy + dz * dz <= SPAN2 then
                            slot.agree = slot.agree + 1
                        end
                    end
                end
            end
        end

        -- The root is a physics part and always carries the live position.
        -- Head / limbs are animated and can freeze while the player is off
        -- screen or behind a wall; that stale group used to outvote the root
        -- and the box stayed where the player had been. The vote below only
        -- decides when there is no root at all.
        local bestPos, bestCount = nil, 0

        if refs[1].pos then
            bestPos, bestCount = refs[1].pos, refs[1].agree
        else
            for index = 2, 3 do
                local slot = refs[index]

                if slot.pos and slot.agree > bestCount then
                    bestCount = slot.agree
                    bestPos = slot.pos
                end
            end
        end

        if not bestPos then
            return nil
        end

        local valid = rig.valid
        table.clear(valid)

        local signature = Vector3.zero
        local total = 0
        local bx, by, bz = bestPos.X, bestPos.Y, bestPos.Z

        for j = 1, #list do
            local part = list[j]

            if part.Parent then
                total = total + 1

                local pos = part.Position
                local dx, dy, dz = pos.X - bx, pos.Y - by, pos.Z - bz

                if dx * dx + dy * dy + dz * dz <= SPAN2 then
                    valid[part] = true
                    signature = signature + pos
                end
            end
        end

        valid.all = bestCount == total

        return bestPos, valid, signature
    end

    -- Returns an oriented box: CFrame, local centre offset, half extents.
    -- Built from the root part, so it is stable while limbs animate and it
    -- follows a rotated (ragdolled / lying) character. The proportions
    -- (height above / below the root, half width, half depth) are measured
    -- while head and feet agree with the root and reused when they freeze.
    local function boxSpec(rig, valid, anchor)
        local root = rig.root
        local head = rig.head
        local feet = rig.feet
        local rootOk = root and root.Parent and valid[root]

        if rootOk and head and head.Parent and valid[head] and #feet > 0 then
            -- The box is aligned to the WORLD (yaw only), not to the root part:
            -- when the root tilts (lean / crouch / custom animation) a box built
            -- in the root's local space is shoved sideways.
            local look = root.CFrame.LookVector

            if look.X * look.X + look.Z * look.Z < 0.09 then
                look = head.CFrame.LookVector
            end

            local yaw = math.atan2(-look.X, -look.Z)
            local body = rig.body
            local centre = body and valid[body] and body.Position
                or root.Position

            local top = head.Position.Y + head.Size.Y * 0.5
            local bottom = huge

            for _, foot in ipairs(feet) do
                if foot.Parent and valid[foot] then
                    local y = foot.Position.Y - foot.Size.Y * 0.5

                    if y < bottom then
                        bottom = y
                    end
                end
            end

            if bottom < top then
                local halfWidth = body and body.Size.X * 0.85 or 1.7
                local halfDepth = body and body.Size.Z * 0.5 or 0.5
                local rootY = root.Position.Y

                rig.topOff = top - rootY
                rig.botOff = bottom - rootY
                rig.halfW = halfWidth
                rig.halfD = halfDepth
                rig.yaw = yaw

                return CFrame.new(centre.X, 0, centre.Z)
                        * CFrame.Angles(0, yaw, 0),
                    Vector3.new(0, (top + bottom) * 0.5, 0),
                    Vector3.new(halfWidth, (top - bottom) * 0.5, halfDepth)
            end
        end

        -- head / feet froze (or are still streaming): a root-anchored box from
        -- the proportions measured earlier
        if rootOk and rig.topOff then
            local look = root.CFrame.LookVector
            local yaw = rig.yaw or 0

            if look.X * look.X + look.Z * look.Z >= 0.09 then
                yaw = math.atan2(-look.X, -look.Z)
                rig.yaw = yaw
            end

            local rootPos = root.Position
            local top = rootPos.Y + rig.topOff
            local bottom = rootPos.Y + rig.botOff

            return CFrame.new(rootPos.X, 0, rootPos.Z)
                    * CFrame.Angles(0, yaw, 0),
                Vector3.new(0, (top + bottom) * 0.5, 0),
                Vector3.new(rig.halfW, (top - bottom) * 0.5, rig.halfD)
        end

        -- unknown model shape: its bounding box is the only size there is.
        -- R6 / R15 never use it (weapons and accessories would fatten the box)
        if valid.all and rig.kind == "generic" then
            local cf, size = rig.char:GetBoundingBox()
            return cf, Vector3.zero, size * 0.5
        end

        return CFrame.new(anchor), Vector3.zero, Vector3.new(1.8, 3, 1)
    end

    -- Visibility ---------------------------------------------------------------

    local rayParams = RaycastParams.new()
    rayParams.FilterType = Enum.RaycastFilterType.Exclude
    rayParams.IgnoreWater = true

    -- Casts camera -> point. Invisible parts and other characters do not count
    -- as cover; walls, terrain and props do.
    local function isBlocked(from, to, filter)
        local direction = to - from

        for _ = 1, 4 do
            rayParams.FilterDescendantsInstances = filter

            local hit = Workspace:Raycast(from, direction, rayParams)

            if not hit then
                return false
            end

            local part = hit.Instance

            if part:IsA("Terrain") then
                return true
            end

            local model = part:FindFirstAncestorOfClass("Model")

            if model and model:FindFirstChildOfClass("Humanoid") then
                filter[#filter + 1] = model
            elseif part.Transparency >= 0.9 then
                filter[#filter + 1] = part
            else
                return true
            end
        end

        return true
    end

    local function isExposed(rig, camPos, localChar, valid)
        for index = 1, #rig.samples do
            local part = rig.samples[index]

            if part.Parent and valid[part] then
                local filter = { rig.char }

                if localChar then
                    filter[2] = localChar
                end

                if not isBlocked(camPos, part.Position, filter) then
                    return true
                end
            end
        end

        return false
    end

    -- Player filters -----------------------------------------------------------

    local friendCache = {}

    local function refreshFriend(target)
        task.spawn(function()
            local ok, result = pcall(
                player.IsFriendsWith,
                player,
                target.UserId
            )

            friendCache[target.UserId] = ok and result == true
        end)
    end

    -- Folder-based sides (Lost Front): no Roblox teams and no attributes, the
    -- side is the folder the character sits in:
    -- Workspace.<root>.<team folder>.<nick>. Folder names are obfuscated, so
    -- they are never hardcoded: a teammate is whoever shares MY folder.
    -- Dead / spectating characters sit directly in Workspace (no folder).
    local myTeamFolder
    local folderModeAt, folderMode = -huge, false

    local function teamFolderOf(char)
        local parent = char and char.Parent

        if parent and parent ~= Workspace then
            return parent
        end

        return nil
    end

    -- The folder rule is trusted only when at least two different folders
    -- hold characters. Modes where everybody shares one folder (Defusal:
    -- Workspace.Players) must not turn the whole lobby into "teammates".
    local function hasTeamFolders()
        local now = os.clock()

        if now - folderModeAt < 1 then
            return folderMode
        end

        folderModeAt = now
        folderMode = false

        local first

        for _, other in ipairs(Players:GetPlayers()) do
            local folder = teamFolderOf(other.Character)

            if folder then
                if not first then
                    first = folder
                elseif folder ~= first then
                    folderMode = true
                    break
                end
            end
        end

        return folderMode
    end

    -- Players:GetPlayers() builds a new table on every call, and that used to
    -- happen once per frame. One list is kept and refreshed only when the
    -- roster really changes.
    local roster = {}

    local function refreshRoster()
        local list = Players:GetPlayers()

        for index = 1, #list do
            roster[index] = list[index]
        end

        for index = #list + 1, #roster do
            roster[index] = nil
        end
    end

    refreshRoster()

    -- Sides ----------------------------------------------------------------------
    --
    -- Which side a player is on lives in a different place in every game, so it
    -- is read from every place games commonly keep it, in this order:
    --   1. the Roblox Team;
    --   2. attributes on the player, then the character, then its Humanoid;
    --   3. value objects (StringValue, IntValue, ...) directly on the player,
    --      inside its leaderstats / leaderboard folder, or on the character;
    --   4. the folder the character sits in (Lost Front).
    -- Only names from SIDE_ORDER count (case and punctuation are ignored), so
    -- unrelated values such as "TeamKills" or "device" are never mistaken for a
    -- side. "Spectator" / "neutral" / "none" style values are not a side.
    --
    -- Everything else (isTeammate, the aimbot, the dump) goes through sideOf,
    -- which is cached: GetAttributes builds a new table on every call and the
    -- filter is asked once per player per frame.

    local SIDE_ORDER = {
        "team", "teamname", "teamid", "teamnumber", "teamindex",
        "teamcolor", "teamcolour", "side", "sidename", "sideid",
        "faction", "factionname", "alliance",
    }

    local SIDE_NAMES = {}

    for _, id in ipairs(SIDE_ORDER) do
        SIDE_NAMES[id] = true
    end

    local STATS_NAMES = { leaderstats = true, leaderboard = true, stats = true }

    local NO_SIDE = {
        [""] = true, spectator = true, spectators = true, spectating = true,
        spec = true, neutral = true, none = true, ["nil"] = true,
        null = true, lobby = true, dead = true, unassigned = true,
        noteam = true, waiting = true,
    }

    local function normalizeName(name)
        return (string.gsub(string.lower(name), "[^%w]", ""))
    end

    -- value -> comparable text, or nil when it does not name a side
    local function sideText(value)
        local kind = typeof(value)

        if kind == "string" then
            local text = string.lower(string.match(value, "^%s*(.-)%s*$"))

            if NO_SIDE[text] then
                return nil
            end

            return text
        elseif kind == "number" or kind == "Color3" or kind == "BrickColor" then
            return tostring(value)
        elseif kind == "Instance" then
            local text = string.lower(value.Name)

            if NO_SIDE[text] then
                return nil
            end

            return text
        end

        return nil
    end

    -- scratch tables: one scan fills them, pickFound reads them
    local foundValue, foundName = {}, {}

    local function pickFound()
        for _, id in ipairs(SIDE_ORDER) do
            local value = foundValue[id]

            if value ~= nil then
                local text = sideText(value)

                if text then
                    return id, text, foundName[id]
                end
            end
        end

        return nil
    end

    local function attributeSide(inst, label)
        if not inst then
            return nil
        end

        table.clear(foundValue)
        table.clear(foundName)

        for name, value in pairs(inst:GetAttributes()) do
            local id = normalizeName(name)

            if SIDE_NAMES[id] then
                foundValue[id] = value
                foundName[id] = name
            end
        end

        local id, text, name = pickFound()

        if not id then
            return nil
        end

        return "attr:" .. id .. ":" .. text, "attr",
            label .. " attr " .. name .. "=" .. text
    end

    local function valueSide(inst, label)
        if not inst then
            return nil
        end

        table.clear(foundValue)
        table.clear(foundName)

        for _, child in ipairs(inst:GetChildren()) do
            if child:IsA("ValueBase") then
                local id = normalizeName(child.Name)

                if SIDE_NAMES[id] then
                    foundValue[id] = child.Value
                    foundName[id] = child.Name
                end
            end
        end

        local id, text, name = pickFound()

        if not id then
            return nil
        end

        return "value:" .. id .. ":" .. text, "value",
            label .. " value " .. name .. "=" .. text
    end

    local function statsOf(target)
        for _, child in ipairs(target:GetChildren()) do
            if STATS_NAMES[normalizeName(child.Name)] then
                return child
            end
        end

        return nil
    end

    -- Uncached lookup: returns key, kind, via (via is for the dump only).
    local function resolveSide(target)
        local team = target.Team

        if team ~= nil then
            return "team:" .. team.Name, "team", "Team " .. team.Name
        end

        local char = target.Character
        local human = char and char:FindFirstChildOfClass("Humanoid")
        local key, kind, via

        key, kind, via = attributeSide(target, "player")

        if key then
            return key, kind, via
        end

        key, kind, via = attributeSide(char, "character")

        if key then
            return key, kind, via
        end

        key, kind, via = attributeSide(human, "humanoid")

        if key then
            return key, kind, via
        end

        key, kind, via = valueSide(target, "player")

        if key then
            return key, kind, via
        end

        key, kind, via = valueSide(statsOf(target), "leaderstats")

        if key then
            return key, kind, via
        end

        key, kind, via = valueSide(char, "character")

        if key then
            return key, kind, via
        end

        if hasTeamFolders() then
            local folder = teamFolderOf(char)

            if folder then
                return "folder:" .. folder:GetFullName(), "folder",
                    "folder " .. folder.Name
            end
        end

        return nil
    end

    local SIDE_TTL = 0.5
    local sideCache = setmetatable({}, { __mode = "k" })

    local function sideOf(target, now)
        local cached = sideCache[target]

        if cached and now - cached.at < SIDE_TTL then
            return cached.key, cached.kind, cached.via
        end

        local key, kind, via = resolveSide(target)

        if not cached then
            cached = {}
            sideCache[target] = cached
        end

        cached.key, cached.kind, cached.via, cached.at = key, kind, via, now

        return key, kind, via
    end

    -- Teams are not always a real thing: some modes give everybody the same
    -- team (or the same team attribute), and filtering "teammates" there left
    -- no targets at all. The filter therefore only applies while the game
    -- really has a second side in play, measured on the same kind of source
    -- as my own. My last known side is remembered, because a dead or
    -- spectating local player has no side of his own to read.
    local sidesOn = false
    local sidesAt = -1
    local mySide, myKind

    local function refreshSides(now)
        if now - sidesAt < 1 then
            return
        end

        sidesAt = now
        sidesOn = false

        local key, kind = sideOf(player, now)

        if key then
            mySide, myKind = key, kind
        end

        if not mySide then
            return
        end

        for index = 1, #roster do
            local other = roster[index]

            if other ~= player then
                local otherKey, otherKind = sideOf(other, now)

                if otherKey and otherKind == myKind and otherKey ~= mySide then
                    sidesOn = true
                    return
                end
            end
        end
    end

    local function isTeammate(target)
        if not sidesOn or not mySide then
            return false
        end

        local key = sideOf(target, os.clock())

        return key ~= nil and key == mySide
    end

    -- shared with the aimbot (it lives in another closure) and the dump
    uiState.isTeammate = isTeammate
    uiState.refreshSides = refreshSides

    local function describeSide(target)
        local key, _, via = resolveSide(target)

        return key and (key .. " [" .. via .. "]") or "none"
    end

    -- Some games keep the real hp in player attributes and never touch
    -- Humanoid.Health. Attributes win when they are numeric.
    local function readHealth(owner, humanoid)
        if owner then
            local hp = owner:GetAttribute("Health")
            local maxHp = owner:GetAttribute("MaxHealth")

            if type(hp) == "number" and type(maxHp) == "number"
                and maxHp > 0 then
                return hp, maxHp
            end
        end

        if humanoid then
            return humanoid.Health, humanoid.MaxHealth
        end

        return nil
    end

    -- Games with custom health / death often leave Humanoid.Health untouched
    -- and flag death with attributes instead.
    local DEAD_FLAGS = {
        "Dead", "IsDead", "Died", "Eliminated", "Downed", "Knocked",
        "Spectating", "Respawning",
    }

    local ALIVE_FLAGS = { "Alive", "IsAlive" }

    local function flagged(inst)
        if not inst then
            return false
        end

        for _, key in ipairs(DEAD_FLAGS) do
            if inst:GetAttribute(key) == true then
                return true
            end
        end

        for _, key in ipairs(ALIVE_FLAGS) do
            if inst:GetAttribute(key) == false then
                return true
            end
        end

        local hp = inst:GetAttribute("Health")

        return type(hp) == "number" and hp <= 0
    end

    -- still in the game, has a character in the world and is not dead
    local function isAlive(target)
        if target.Parent ~= Players then
            return false
        end

        local char = target.Character

        if not char or not char.Parent then
            return false
        end

        if flagged(char) or flagged(target) then
            return false
        end

        local humanoid = char:FindFirstChildOfClass("Humanoid")

        if humanoid then
            if humanoid.Health <= 0
                or humanoid:GetState() == Enum.HumanoidStateType.Dead
                or flagged(humanoid) then
                return false
            end
        end

        return true
    end

    -- Per-player objects -------------------------------------------------------

    local entries = {}
    local botEntries = {}

    local HEALTH_COLORS = ColorSequence.new({
        ColorSequenceKeypoint.new(0.00, Color3.fromRGB(64, 230, 96)),
        ColorSequenceKeypoint.new(0.20, Color3.fromRGB(64, 230, 96)),
        ColorSequenceKeypoint.new(0.50, Color3.fromRGB(255, 214, 40)),
        ColorSequenceKeypoint.new(0.80, Color3.fromRGB(240, 56, 56)),
        ColorSequenceKeypoint.new(1.00, Color3.fromRGB(240, 56, 56)),
    })

    local function textLabel(parent, name, size, anchorY)
        return make("TextLabel", {
            Name = name,
            TextSize = size,
            TextXAlignment = Enum.TextXAlignment.Center,
            TextYAlignment = anchorY == 1
                and Enum.TextYAlignment.Bottom
                or Enum.TextYAlignment.Top,
            AnchorPoint = Vector2.new(0.5, anchorY),
            Size = UDim2.fromOffset(260, size + 3),
            TextStrokeColor3 = BLACK,
            TextStrokeTransparency = 0.35,
            Visible = false,
        }, parent)
    end

    local function createEntry(target, registry, key)
        local holder = make("Frame", {
            Name = target.Name,
            Size = UDim2.fromScale(1, 1),
            Visible = false,
        }, overlay)

        local entry = {
            holder = holder,
            vis = {},
            col = {},
            groups = {},
            bones = {},
            boneVis = {},
            visible = true,
            nameText = target.Name,
            nextVis = os.clock() + math.random() * 0.1,
        }

        -- box: coloured frame + black frames just outside and inside of it
        local function boxFrame(name, color, transparency)
            local frame = make("Frame", {
                Name = name,
                Visible = false,
            }, holder)

            local border = make("UIStroke", {
                Color = color,
                Transparency = transparency,
                Thickness = 1,
                ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
            }, frame)

            return frame, border
        end

        local main, mainStroke = boxFrame("Box", WHITE, 0)
        local outer = boxFrame("BoxOuter", BLACK, 0.35)
        local inner = boxFrame("BoxInner", BLACK, 0.35)

        entry.boxMain, entry.boxStroke = main, mainStroke
        entry.boxOuter, entry.boxInner = outer, inner
        entry.groups.box = { main, outer, inner }

        entry.line = make("Frame", {
            Name = "Line",
            AnchorPoint = Vector2.new(0.5, 0.5),
            Size = UDim2.fromOffset(0, 1),
            BackgroundColor3 = WHITE,
            BackgroundTransparency = 0,
            Visible = false,
        }, holder)

        entry.groups.line = { entry.line }

        entry.name = textLabel(holder, "Name", 8, 1)
        entry.name.Text = target.Name
        entry.groups.name = { entry.name }

        entry.dist = textLabel(holder, "Distance", 12, 0)
        entry.groups.distance = { entry.dist }

        -- health: black plate, bottom-anchored clip, full-height gradient
        local back = make("Frame", {
            Name = "HealthBack",
            BackgroundColor3 = BLACK,
            BackgroundTransparency = 0.35,
            Visible = false,
        }, holder)

        entry.hpStroke = make("UIStroke", {
            Color = WHITE,
            Transparency = 0.2,
            Thickness = 1,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
        }, back)

        entry.hpClip = make("Frame", {
            Name = "Clip",
            AnchorPoint = Vector2.new(0, 1),
            ClipsDescendants = true,
        }, back)

        entry.hpFill = make("Frame", {
            Name = "Fill",
            AnchorPoint = Vector2.new(0, 1),
            Position = UDim2.fromScale(0, 1),
            BackgroundColor3 = WHITE,
            BackgroundTransparency = 0,
        }, entry.hpClip)

        make("UIGradient", {
            Rotation = 90,
            Color = HEALTH_COLORS,
        }, entry.hpFill)

        entry.hpBack = back
        -- tiny number centred right under the dash
        entry.hpText = textLabel(holder, "HealthText", 6, 0)
        entry.hpText.TextColor3 = WHITE

        -- short dash across the middle of the bar; it rides the fill edge
        entry.hpMark = make("Frame", {
            Name = "HealthMark",
            Size = UDim2.fromOffset(5, 2),
            BackgroundColor3 = WHITE,
            BackgroundTransparency = 0,
            Visible = false,
        }, holder)

        entry.groups.health = { back, entry.hpText, entry.hpMark }

        registry = registry or entries
        registry[key or target] = entry
        return entry
    end

    local function ensureBones(entry, count)
        for index = #entry.bones + 1, count do
            entry.bones[index] = make("Frame", {
                Name = "Bone",
                AnchorPoint = Vector2.new(0.5, 0.5),
                Size = UDim2.fromOffset(0, 1),
                BackgroundColor3 = entry.col.skeleton or WHITE,
                BackgroundTransparency = 0,
                Visible = false,
            }, entry.holder)

            entry.boneVis[index] = false
        end
    end

    local function setGroup(entry, key, value)
        if entry.vis[key] == value then
            return
        end

        entry.vis[key] = value

        for _, object in ipairs(entry.groups[key]) do
            object.Visible = value
        end
    end

    local function hideEntry(entry)
        if entry and entry.holder.Visible then
            entry.holder.Visible = false
        end
    end

    -- A 1 px line between two screen points (rotated Frame).
    -- `cache` is an optional {x, y, length, rotation} table owned by the entry:
    -- a line that did not move costs nothing, which matters because the
    -- skeleton alone is up to 19 lines per target per frame.
    local function placeLine(frame, ax, ay, bx, by, cache)
        local dx, dy = bx - ax, by - ay
        local length = math.sqrt(dx * dx + dy * dy)

        if length < 0.5 then
            return false
        end

        local px, py = (ax + bx) * 0.5, (ay + by) * 0.5
        local rotation = math.deg(math.atan2(dy, dx))

        if cache
            and cache[1] == px
            and cache[2] == py
            and cache[3] == length
            and cache[4] == rotation then
            return true
        end

        if cache then
            cache[1], cache[2], cache[3], cache[4] = px, py, length, rotation
        end

        frame.Position = UDim2.fromOffset(px, py)
        frame.Size = UDim2.fromOffset(length, 1)
        frame.Rotation = rotation

        return true
    end

    -- Cheap cull: can this character possibly be on screen? Everything is
    -- assumed to sit inside a CULL_MARGIN sphere around the root, and the cone
    -- test is skipped for close targets, so the cull only fires when the box
    -- would have been hidden anyway (roughly half of the server sits behind
    -- the camera at any moment).
    local CULL_MARGIN = 12
    local CULL_NEAR = 40
    local CULL_ANGLE = 40

    local function cullTarget(rootPos, camPos, look, fov)
        local dx = rootPos.X - camPos.X
        local dy = rootPos.Y - camPos.Y
        local dz = rootPos.Z - camPos.Z
        local behind = dx * look.X + dy * look.Y + dz * look.Z

        if behind < -CULL_MARGIN then
            return true
        end

        local reach = math.sqrt(dx * dx + dy * dy + dz * dz)

        if reach <= CULL_NEAR or reach <= CULL_MARGIN then
            return false
        end

        local half = clamp(fov or 70, 1, 120) * 0.5 + CULL_ANGLE

        return behind / reach < math.cos(math.rad(half))
    end

    -- Per-frame drawing --------------------------------------------------------

    -- Shared by players and bots: the entry already exists, the caller has
    -- done its own alive / filter checks. `palette` maps a feature to its
    -- {visible, hidden} colours, `checkStale` enables the frozen-data hide.
    local function drawEntity(entry, char, humanoid, palette, checkStale, cam, camPos, viewport, origin, localChar, now, dt)
        local rig = entry.rig

        if not rig
            or rig.char ~= char
            or now >= rig.retry
            or (rig.root and not rig.root.Parent) then
            rig = buildRig(char, now)
            entry.rig = rig
        end

        local root = rig.root

        if not root then
            return hideEntry(entry)
        end

        -- cheapest test first: nothing behind the camera can be on screen
        if cullTarget(
            root.Position,
            camPos,
            cam.CFrame.LookVector,
            cam.FieldOfView
        ) then
            return hideEntry(entry)
        end

        -- "fresh" = ANY agreeing part of the rig moved: a living player who
        -- stands still still animates, a model that gets no data is frozen.
        -- coherence() sums that signature in the pass it already runs.
        local anchor, valid, signature = coherence(rig)

        if not anchor then
            return hideEntry(entry)
        end

        local distance = (anchor - origin).Magnitude
        local meters = distance * STUDS_TO_M

        if meters > cfg.range then
            return hideEntry(entry)
        end

        if not entry.lastSig
            or (signature - entry.lastSig).Magnitude > 0.02 then
            entry.lastSig = signature
            entry.lastMove = now
        end

        local isStale = checkStale
            and distance > STALE_MIN_DIST
            and now - entry.lastMove > STALE_AFTER

        if isStale and STALE_MODE == "hide" then
            return hideEntry(entry)
        end

        local mark = isStale and "?" or ""

        -- distance to the LAST KNOWN spot + how long ago it was updated
        local ageMark = isStale
            and (" ?" .. floor(now - entry.lastMove) .. "s")
            or ""

        -- screen-space bounds of the oriented box
        local cf, offset, half = boxSpec(rig, valid, anchor)
        local minX, minY, maxX, maxY = huge, huge, -huge, -huge

        for index = 1, 8 do
            local v = cam:WorldToViewportPoint(
                cf * (offset + CORNERS[index] * half)
            )

            if v.Z <= 0.05 then
                return hideEntry(entry)
            end

            if v.X < minX then minX = v.X end
            if v.X > maxX then maxX = v.X end
            if v.Y < minY then minY = v.Y end
            if v.Y > maxY then maxY = v.Y end
        end

        if maxX < 0 or minX > viewport.X or maxY < 0 or minY > viewport.Y then
            return hideEntry(entry)
        end

        minX, minY = floor(minX), floor(minY)
        maxX, maxY = ceil(maxX), ceil(maxY)

        local width = math.max(2, maxX - minX)
        local height = math.max(2, maxY - minY)
        local centerX = (minX + maxX) * 0.5

        -- cover check, throttled and staggered between players; the raycasts
        -- are the most expensive thing in this renderer, and a far target's
        -- exposed/behind-cover state does not change often
        if now >= entry.nextVis then
            entry.nextVis = now + (distance > COVER_FAR_DIST
                and COVER_FAR_INTERVAL
                or COVER_INTERVAL)

            entry.visible = isExposed(rig, camPos, localChar, valid)
        end

        local exposed = entry.visible
        local on = cfg.enabled

        if not entry.holder.Visible then
            entry.holder.Visible = true
        end

        -- box
        if on.box then
            local color = exposed and palette.box.visible
                or palette.box.hidden

            if entry.col.box ~= color then
                entry.col.box = color
                entry.boxStroke.Color = color
            end

            -- six property writes per target per frame: skip them wholesale
            -- when the box sits exactly where it did on the previous frame
            local box = entry.boxGeo

            if not box
                or box[1] ~= minX
                or box[2] ~= minY
                or box[3] ~= width
                or box[4] ~= height then
                if not box then
                    box = {}
                    entry.boxGeo = box
                end

                box[1], box[2], box[3], box[4] = minX, minY, width, height

                entry.boxMain.Position = UDim2.fromOffset(minX, minY)
                entry.boxMain.Size = UDim2.fromOffset(width, height)
                entry.boxOuter.Position = UDim2.fromOffset(minX - 1, minY - 1)
                entry.boxOuter.Size = UDim2.fromOffset(width + 2, height + 2)
                entry.boxInner.Position = UDim2.fromOffset(minX + 1, minY + 1)
                entry.boxInner.Size = UDim2.fromOffset(
                    math.max(0, width - 2),
                    math.max(0, height - 2)
                )
            end
        end

        setGroup(entry, "box", on.box)

        -- health bar + dash with the exact hp number
        local hpLevelY

        local hpNow, hpMax

        if on.health then
            hpNow, hpMax = readHealth(Players:GetPlayerFromCharacter(char), humanoid)
        end

        if hpNow then
            local fraction = hpMax > 0
                and clamp(hpNow / hpMax, 0, 1)
                or 1

            if not entry.hp then
                entry.hp = fraction
            end

            -- smooth fill: eases toward the real value
            entry.hp = entry.hp + (fraction - entry.hp) * math.min(1, dt * 14)

            if math.abs(entry.hp - fraction) < 0.002 then
                entry.hp = fraction
            end

            -- top edge of the (eased) fill, kept inside the bar
            hpLevelY = clamp(
                minY + height * (1 - entry.hp),
                minY,
                minY + height
            )

            -- same for the health stack: five writes, skipped when unchanged
            local hpGeo = entry.hpGeo

            if not hpGeo
                or hpGeo[1] ~= minX
                or hpGeo[2] ~= minY
                or hpGeo[3] ~= height
                or hpGeo[4] ~= entry.hp then
                if not hpGeo then
                    hpGeo = {}
                    entry.hpGeo = hpGeo
                end

                hpGeo[1], hpGeo[2] = minX, minY
                hpGeo[3], hpGeo[4] = height, entry.hp

                entry.hpBack.Position = UDim2.fromOffset(minX - 7, minY - 1)
                entry.hpBack.Size = UDim2.fromOffset(5, height + 2)
                entry.hpClip.Position = UDim2.fromOffset(1, height + 1)
                entry.hpClip.Size = UDim2.fromOffset(3, height * entry.hp)
                entry.hpFill.Size = UDim2.fromOffset(3, height)
            end

            -- the number jumps straight to the real value
            local hpNumber = tostring(math.max(0, floor(hpNow + 0.5)))

            if entry.hpText.Text ~= hpNumber then
                entry.hpText.Text = hpNumber
            end

            if entry.hpMarkY ~= hpLevelY or entry.hpMarkX ~= minX then
                entry.hpMarkX, entry.hpMarkY = minX, hpLevelY

                entry.hpMark.Position = UDim2.fromOffset(minX - 7, hpLevelY - 1)
                entry.hpText.Position = UDim2.fromOffset(minX - 4.5, hpLevelY + 1)
            end
        end

        setGroup(entry, "health", hpNow ~= nil)

        -- nickname
        local topY = minY

        if on.name then
            local bottom = minY - 3

            local color = exposed and palette.name.visible
                or palette.name.hidden

            if entry.col.name ~= color then
                entry.col.name = color
                entry.name.TextColor3 = color
            end

            local shownName = entry.nameText .. mark

            if entry.name.Text ~= shownName then
                entry.name.Text = shownName
            end

            if entry.nameX ~= centerX or entry.nameY ~= bottom then
                entry.nameX, entry.nameY = centerX, bottom
                entry.name.Position = UDim2.fromOffset(centerX, bottom)
            end

            topY = bottom - 10
        end

        setGroup(entry, "name", on.name)

        -- distance
        if on.distance then
            local color = exposed and palette.distance.visible
                or palette.distance.hidden

            if entry.col.distance ~= color then
                entry.col.distance = color
                entry.dist.TextColor3 = color
            end

            local text = floor(meters + 0.5) .. "m" .. ageMark

            if entry.distText ~= text then
                entry.distText = text
                entry.dist.Text = text
            end

            if entry.distX ~= centerX or entry.distY ~= maxY then
                entry.distX, entry.distY = centerX, maxY
                entry.dist.Position = UDim2.fromOffset(centerX, maxY + 2)
            end
        end

        setGroup(entry, "distance", on.distance)

        -- line: screen anchor -> top centre of the box
        if on.line then
            local color = exposed and palette.line.visible
                or palette.line.hidden

            if entry.col.line ~= color then
                entry.col.line = color
                entry.line.BackgroundColor3 = color
            end

            local startX = viewport.X * 0.5
            local startY = 0

            if LINE_ORIGIN == "bottom" then
                startY = viewport.Y
            elseif LINE_ORIGIN == "center" then
                startY = viewport.Y * 0.5
            end

            local lineCache = entry.lineCache

            if not lineCache then
                lineCache = {}
                entry.lineCache = lineCache
            end

            local drawn = placeLine(
                entry.line, startX, startY, centerX, topY, lineCache
            )
            setGroup(entry, "line", drawn)
        else
            setGroup(entry, "line", false)
        end

        -- skeleton
        local bones = rig.bones

        -- Show at 12 px, keep until 8 px. With one threshold the box height
        -- jitters by a pixel and the whole skeleton blinked on and off.
        local skeletonOn = on.skeleton
            and height >= (entry.skeletonShown and 8 or 12)
            and #bones > 0
        local skeletonTick = true

        if skeletonOn and distance > SKELETON_FAR_DIST then
            -- far targets: the bones are a few pixels, updating them every
            -- other frame is invisible and halves the bone work
            entry.skelFlip = not entry.skelFlip

            if entry.skelFlip then
                skeletonTick = false
            end
        end

        if skeletonOn and skeletonTick then
            ensureBones(entry, #bones)

            local projected = entry.projected

            if not projected then
                projected = {}
                entry.projected = projected
            end

            for index = 1, rig.count do
                local part = rig.parts[index]
                local point = false

                if part and part.Parent and valid[part] then
                    local mode = rig.modes[index]
                    local world

                    if mode == 1 then
                        world = part.Position
                    elseif mode == 2 then
                        world = part.CFrame
                            * Vector3.new(0, part.Size.Y * 0.5, 0)
                    else
                        world = part.CFrame
                            * Vector3.new(0, -part.Size.Y * 0.5, 0)
                    end

                    local v = cam:WorldToViewportPoint(world)

                    if v.Z > 0 then
                        point = v
                    end
                end

                projected[index] = point
            end

            local color = exposed and palette.skeleton.visible
                or palette.skeleton.hidden

            if entry.col.skeleton ~= color then
                entry.col.skeleton = color

                for _, frame in ipairs(entry.bones) do
                    frame.BackgroundColor3 = color
                end
            end

            local boneCache = entry.boneCache

            if not boneCache then
                boneCache = {}
                entry.boneCache = boneCache
            end

            for index, bone in ipairs(bones) do
                local a, b = projected[bone[1]], projected[bone[2]]
                local frame = entry.bones[index]
                local drawn = false

                if a and b then
                    local cache = boneCache[index]

                    if not cache then
                        cache = {}
                        boneCache[index] = cache
                    end

                    drawn = placeLine(frame, a.X, a.Y, b.X, b.Y, cache)
                end

                if entry.boneVis[index] ~= drawn then
                    entry.boneVis[index] = drawn
                    frame.Visible = drawn
                end
            end

            entry.skeletonShown = true
        elseif not skeletonOn and entry.skeletonShown then
            entry.skeletonShown = false

            for index, frame in ipairs(entry.bones) do
                entry.boneVis[index] = false
                frame.Visible = false
            end
        end
    end

    local function drawPlayer(target, cam, camPos, viewport, origin, localChar, now, dt)
        local entry = entries[target]
        local char = target.Character

        if not isAlive(target) then
            return hideEntry(entry)
        end

        local humanoid = char:FindFirstChildOfClass("Humanoid")

        if humanoid and humanoid.Health <= 0 then
            return hideEntry(entry)
        end

        if cfg.ignoreTeam and isTeammate(target) then
            return hideEntry(entry)
        end

        if cfg.ignoreFriends and friendCache[target.UserId] then
            return hideEntry(entry)
        end

        entry = entry or createEntry(target)

        return drawEntity(
            entry, char, humanoid, cfg.palette, true,
            cam, camPos, viewport, origin, localChar, now, dt
        )
    end

    local function anyPlayerEnabled()
        for _, key in ipairs(FEATURES) do
            if cfg.enabled[key] then
                return true
            end
        end

        return false
    end

    local function anyEnabled()
        return anyPlayerEnabled() or cfg.enabled.bots == true
    end

    -- Bots ---------------------------------------------------------------------
    -- A bot is a Model with a Humanoid in Workspace that is not a player's
    -- character. Discovery runs only while the bot ESP is switched on.

    -- Whether a model is our own avatar. Games with custom characters keep a
    -- visible copy that is not player.Character, and once the camera is pulled
    -- back (third person) that copy is no longer culled by the near plane, so
    -- it used to get a bot box on the player himself. Identity is therefore
    -- checked through every handle we have, not just one comparison.
    local function isOwnAvatar(model, humanoid)
        local char = player.Character

        if char then
            if model == char
                or model:IsDescendantOf(char)
                or char:IsDescendantOf(model) then
                return true
            end

            local ownHum = char:FindFirstChildOfClass("Humanoid")
            local ownRoot = char:FindFirstChild("HumanoidRootPart")
                or char.PrimaryPart

            if ownHum and humanoid == ownHum then
                return true
            end

            local root = humanoid.RootPart

            if root then
                if ownRoot and root == ownRoot then
                    return true
                end

                -- a copy of the avatar stands exactly where we stand
                if ownRoot and (root.Position - ownRoot.Position).Magnitude < 1.25 then
                    return true
                end
            end
        end

        local cam = Workspace.CurrentCamera

        if cam and cam.CameraSubject == humanoid then
            return true
        end

        if model.Name == player.Name
            or (char and model.Name == char.Name) then
            return true
        end

        return false
    end

    local botHumanoids = {}
    local botLinks = {}

    local function considerBot(item)
        if item:IsA("Humanoid") then
            local model = item.Parent

            if model and model:IsA("Model") then
                botHumanoids[model] = item
            end
        end
    end

    -- getgenv().shitaro_bots() in the executor while bot ESP is on: prints every
    -- model the scan considers a bot, with the reason it was NOT filtered out.
    local function dumpBots()
        for model, humanoid in pairs(botHumanoids) do
            local char = player.Character
            local ownRoot = char
                and (char:FindFirstChild("HumanoidRootPart") or char.PrimaryPart)
            local root = humanoid.RootPart
            local distance = root and ownRoot
                and (root.Position - ownRoot.Position).Magnitude
                or -1

            warn(string.format(
                "[shitaro/bots] %s | parent=%s | self=%s | player=%s | dist=%.1f | hp=%.0f",
                model.Name,
                model.Parent and model.Parent:GetFullName() or "-",
                tostring(isOwnAvatar(model, humanoid)),
                tostring(Players:GetPlayerFromCharacter(model) ~= nil),
                distance,
                humanoid.Health
            ))
        end
    end

    pcall(function()
        local env = getgenv and getgenv() or nil

        if env then
            env.shitaro_bots = dumpBots
        end
    end)

    local function stopBotScan()
        for _, link in ipairs(botLinks) do
            link:Disconnect()
        end

        table.clear(botLinks)
        table.clear(botHumanoids)
    end

    local function startBotScan()
        if #botLinks > 0 then
            return
        end

        table.insert(botLinks, Workspace.DescendantAdded:Connect(considerBot))

        table.insert(botLinks, Workspace.DescendantRemoving:Connect(function(item)
            if item:IsA("Humanoid") and botHumanoids[item.Parent] == item then
                botHumanoids[item.Parent] = nil
            end
        end))

        for _, item in ipairs(Workspace:GetDescendants()) do
            considerBot(item)
        end
    end

    -- every feature of a bot uses the one bot palette (orange / blue)
    local botPalette = {}

    for _, key in ipairs(FEATURES) do
        botPalette[key] = cfg.palette.bots
    end

    local function drawBot(model, humanoid, cam, camPos, viewport, origin, localChar, now, dt)
        local entry = botEntries[model]

        if not model.Parent
            or isOwnAvatar(model, humanoid)
            or humanoid.Health <= 0
            or humanoid:GetState() == Enum.HumanoidStateType.Dead
            or flagged(model)
            or flagged(humanoid)
            or Players:GetPlayerFromCharacter(model) then
            return hideEntry(entry)
        end

        entry = entry or createEntry({ Name = BOT_NAME }, botEntries, model)

        return drawEntity(
            entry, model, humanoid, botPalette, false,
            cam, camPos, viewport, origin, localChar, now, dt
        )
    end

    local warned = {}

    local function step(dt)
        if not anyEnabled() then
            for _, entry in pairs(entries) do
                hideEntry(entry)
            end

            for _, entry in pairs(botEntries) do
                hideEntry(entry)
            end

            return
        end

        local cam = Workspace.CurrentCamera

        if not cam then
            return
        end

        local camPos = cam.CFrame.Position
        local viewport = cam.ViewportSize
        local localChar = player.Character

        local localRoot = localChar
            and (localChar:FindFirstChild("HumanoidRootPart")
                or localChar.PrimaryPart)

        local origin = localRoot and localRoot.Position or camPos
        local now = os.clock()

        if cfg.ignoreTeam then
            refreshSides(now)
        end

        for target, entry in pairs(entries) do
            if target.Parent ~= Players then
                entry.holder:Destroy()
                entries[target] = nil
            end
        end

        if anyPlayerEnabled() then
            for index = 1, #roster do
                local target = roster[index]

                if target ~= player then
                    local ok, err = pcall(
                        drawPlayer,
                        target, cam, camPos, viewport, origin, localChar, now, dt
                    )

                    if not ok then
                        hideEntry(entries[target])

                        if not warned[tostring(err)] then
                            warned[tostring(err)] = true
                            warn("[shitaro/esp] " .. tostring(err))
                        end
                    end
                end
            end
        else
            for _, entry in pairs(entries) do
                hideEntry(entry)
            end
        end

        if cfg.enabled.bots then
            for model, entry in pairs(botEntries) do
                if not model.Parent or not botHumanoids[model] then
                    entry.holder:Destroy()
                    botEntries[model] = nil
                end
            end

            for model, humanoid in pairs(botHumanoids) do
                local ok, err = pcall(
                    drawBot,
                    model, humanoid, cam, camPos, viewport, origin, localChar, now, dt
                )

                if not ok then
                    hideEntry(botEntries[model])

                    if not warned[tostring(err)] then
                        warned[tostring(err)] = true
                        warn("[shitaro/esp] " .. tostring(err))
                    end
                end
            end
        else
            for _, entry in pairs(botEntries) do
                hideEntry(entry)
            end
        end
    end

    -- Stream assist ------------------------------------------------------------
    --
    -- With Workspace.StreamingEnabled the server only replicates parts that are
    -- inside the streaming radius around the local player. A far enemy model may
    -- still exist on the client (persistent / not yet streamed out) but its parts
    -- are frozen at the last position the client received, so the ESP draws a
    -- player "standing at spawn" until they come close.
    --
    -- Fix: keep asking the server to stream the area around each enemy's last
    -- known position. The enemy is inside that radius, so fresh data arrives,
    -- the position updates, and the next request is centred on the new position
    -- (the request follows the enemy). Matches start with everyone at spawn, so
    -- the very first known position is already correct.
    -- OFF by default: the requests load the map around every far enemy
    -- (lag) and did not make far positions update in testing.
    local STREAM_ASSIST = false
    local STREAM_INTERVAL = 0.25 -- seconds between sweeps
    local STREAM_TIMEOUT = 0.5   -- max yield per request
    -- skip players that normal streaming already covers (fraction of the radius)
    local STREAM_NEAR_FRACTION = 0.5

    local streamBusy = {}
    local lastKnown = {}

    local function streamAssist()
        if not STREAM_ASSIST or not Workspace.StreamingEnabled then
            return
        end

        if not anyEnabled() then
            return
        end

        local cam = Workspace.CurrentCamera

        if not cam then
            return
        end

        local camPos = cam.CFrame.Position
        local nearRadius = Workspace.StreamingTargetRadius * STREAM_NEAR_FRACTION

        for _, target in ipairs(Players:GetPlayers()) do
            if target ~= player
                and not streamBusy[target]
                and not (cfg.ignoreTeam and isTeammate(target))
                and isAlive(target) then
                local char = target.Character
                local root = char
                    and (char:FindFirstChild("HumanoidRootPart")
                        or char.PrimaryPart)

                if root then
                    lastKnown[target] = root.Position
                end

                -- the model can be streamed out entirely: use the last position
                local position = lastKnown[target]

                if position and (position - camPos).Magnitude > nearRadius then
                    streamBusy[target] = true

                    task.spawn(function()
                        pcall(
                            Workspace.RequestStreamAroundAsync,
                            Workspace,
                            position,
                            STREAM_TIMEOUT
                        )

                        streamBusy[target] = nil
                    end)
                end
            end
        end
    end

    task.spawn(function()
        while gui.Parent do
            pcall(streamAssist)
            task.wait(STREAM_INTERVAL)
        end
    end)

    -- Debug dump: run getgenv().shitaro_dump() in the executor while looking at
    -- a dead / odd player; output goes to the console (F9).
    local function attrText(inst)
        local parts = {}

        for key, value in pairs(inst:GetAttributes()) do
            parts[#parts + 1] = key .. "=" .. tostring(value)
        end

        return #parts > 0 and table.concat(parts, ", ") or "-"
    end

    local function dumpPlayers()
        refreshSides(os.clock())

        warn(string.format(
            "[shitaro/dump] sides: on=%s | mine=%s | me: %s",
            tostring(sidesOn),
            tostring(mySide),
            describeSide(player)
        ))

        for _, target in ipairs(Players:GetPlayers()) do
            if target ~= player then
                local char = target.Character
                local humanoid = char and char:FindFirstChildOfClass("Humanoid")
                local names = {}

                if char then
                    for _, child in ipairs(char:GetChildren()) do
                        names[#names + 1] = child.Name
                    end
                end

                warn(string.format(
                    "[shitaro/dump] %s | alive=%s team=%s | side=%s | teammate=%s | player attrs: %s | char attrs: %s | hum: %s | children: %s",
                    target.Name,
                    tostring(isAlive(target)),
                    tostring(target.Team),
                    describeSide(target),
                    tostring(isTeammate(target)),
                    attrText(target),
                    char and attrText(char) or "no char",
                    humanoid and (
                        "hp=" .. humanoid.Health
                        .. " state=" .. tostring(humanoid:GetState())
                        .. " attrs: " .. attrText(humanoid)
                    ) or "none",
                    table.concat(names, ",")
                ))
            end
        end
    end

    pcall(function()
        getgenv().shitaro_dump = dumpPlayers
    end)

    -- Lifecycle ----------------------------------------------------------------

    for _, target in ipairs(Players:GetPlayers()) do
        refreshFriend(target)
    end

    connect(Players.PlayerAdded, refreshRoster)
    connect(Players.PlayerAdded, refreshFriend)

    connect(Players.PlayerRemoving, function(target)
        refreshRoster()

        local entry = entries[target]

        if entry then
            entry.holder:Destroy()
            entries[target] = nil
        end

        friendCache[target.UserId] = nil
        lastKnown[target] = nil
        streamBusy[target] = nil
    end)

    -- runs after the FINAL camera of the frame: the camera block writes the
    -- field of view at RenderPriority.Last - 1 and the aimbot works at Last,
    -- so boxes are drawn one step later or they would lag behind (or sit
    -- beside) a zoomed / free camera
    local stepName = "ShitaroESP"
        .. tostring(floor(os.clock() * 1000))
        .. tostring(math.random(1000, 9999))

    local bound = pcall(function()
        RunService:BindToRenderStep(
            stepName,
            Enum.RenderPriority.Last.Value + 1,
            step
        )
    end)

    if not bound then
        connect(RunService.RenderStepped, step)
    end

    -- not registered through connect(): that list is disconnected first
    gui.Destroying:Connect(function()
        pcall(function()
            RunService:UnbindFromRenderStep(stepName)
        end)

        pcall(stopBotScan)
        overlay:Destroy()
    end)

    -- Menu: visuals tab --------------------------------------------------------

    local visualsScroll = pageScroll(tabs[3].page, "VisualsScroll")
    panelWidths[visualsScroll] = window.Size.X.Offset - PANEL_RESERVE

    local espCard = previewPanel(visualsScroll, "esp.panel", 1, #FEATURES + 1)

    local filterCard, filterHolder =
        previewPanel(visualsScroll, "esp.filters", 2, 3)

    panelGapBefore[filterHolder] = 16

    local function addToggle(frame, initial, onChange)
        local state = initial

        local track = make("Frame", {
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.new(1, -12, 0.5, 0),
            Size = UDim2.fromOffset(26, 14),
            BackgroundColor3 = state and colors.accent or WHITE,
            BackgroundTransparency = state and 0.35 or 0.86,
            ZIndex = 2,
        }, frame)

        corner(track, UDim.new(1, 0))

        local knob = make("Frame", {
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.new(0, state and 14 or 2, 0.5, 0),
            Size = UDim2.fromOffset(10, 10),
            BackgroundColor3 = state and colors.accent or colors.sub,
            BackgroundTransparency = 0.15,
            ZIndex = 3,
        }, track)

        corner(knob, UDim.new(1, 0))

        local hit = make("TextButton", {
            Size = UDim2.fromScale(1, 1),
            ZIndex = 5,
        }, frame)

        connect(hit.Activated, function()
            state = not state

            animate(track, {
                BackgroundColor3 = state and colors.accent or WHITE,
                BackgroundTransparency = state and 0.35 or 0.86,
            })

            animate(knob, {
                Position = UDim2.new(0, state and 14 or 2, 0.5, 0),
                BackgroundColor3 = state and colors.accent or colors.sub,
            })

            onChange(state)
        end)
    end

    -- colour squares ---------------------------------------------------------

    local swatches = {}
    local selection

    local function paintSelection()
        for key, swatch in pairs(swatches) do
            local active = selection ~= nil and selection == key

            swatch.outline.Color = active and colors.accent or WHITE
            swatch.outline.Transparency = active and 0 or 0.8
            swatch.outline.Thickness = active and 2 or 1
        end
    end

    local function closeEditor()
        picker.espOpen = false
        selection = nil
        picker.target = { kind = "menu" }
        picker.panel.Visible = false
        paintSelection()
    end

    picker.onLeave = closeEditor

    local function setColor(feature, state, color)
        cfg.palette[feature][state] = color
        swatches[feature .. "/" .. state].button.BackgroundColor3 = color

        -- force the entries to repaint with the new colour next frame
        for _, entry in pairs(entries) do
            entry.col[feature] = nil
        end

        if feature == "bots" then
            for _, entry in pairs(botEntries) do
                table.clear(entry.col)
            end
        end
    end

    local function openEditor(feature, state)
        local key = feature .. "/" .. state

        if picker.espOpen and selection == key then
            closeEditor()
            return
        end

        selection = key
        picker.espOpen = true

        picker.setTarget({
            kind = "esp",
            feature = feature,
            state = state,
            default = feature == "bots"
                and (state == "visible" and ORANGE or BLUE)
                or (state == "visible" and RED or GREEN),
            apply = function(color)
                setColor(feature, state, color)
            end,
        }, cfg.palette[feature][state])

        picker.panel.Visible = true
        paintSelection()
    end

    local function addSwatch(frame, feature, state, offset)
        local button = make("TextButton", {
            Name = feature .. state,
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.new(1, -offset, 0.5, 0),
            Size = UDim2.fromOffset(16, 16),
            BackgroundColor3 = cfg.palette[feature][state],
            BackgroundTransparency = 0,
            ZIndex = 6,
        }, frame)

        corner(button, UDim.new(0, 4))

        local outline = make("UIStroke", {
            Color = WHITE,
            Transparency = 0.8,
            Thickness = 1,
            ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
        }, button)

        swatches[feature .. "/" .. state] = {
            button = button,
            outline = outline,
        }

        connect(button.Activated, function()
            openEditor(feature, state)
        end)
    end

    -- rows ---------------------------------------------------------------------

    for index, feature in ipairs(FEATURES) do
        local frame, label = previewRow(espCard, index, "", true)

        localize(label, "esp." .. feature)

        addToggle(frame, false, function(value)
            cfg.enabled[feature] = value
        end)

        -- left: exposed (red), right: behind cover (green); health has none
        if feature ~= "health" then
            addSwatch(frame, feature, "visible", 70)
            addSwatch(frame, feature, "hidden", 48)
        end
    end

    local teamFrame, teamLabel = previewRow(filterCard, 1, "", true)
    localize(teamLabel, "esp.ignoreTeam")

    addToggle(teamFrame, false, function(value)
        cfg.ignoreTeam = value
    end)

    local friendsFrame, friendsLabel = previewRow(filterCard, 2, "", true)
    localize(friendsLabel, "esp.ignoreFriends")

    addToggle(friendsFrame, false, function(value)
        cfg.ignoreFriends = value

        if value then
            for _, target in ipairs(Players:GetPlayers()) do
                refreshFriend(target)
            end
        end
    end)

    local rangeFrame, rangeLabel = previewRow(filterCard, 3, "", true)
    localize(rangeLabel, "esp.range")

    local rangeSlider = rowSlider(
        rangeFrame,
        "EspRange",
        0,
        800,
        function(value)
            return floor(value + 0.5) .. "m"
        end,
        function(value)
            cfg.range = floor(value + 0.5)
        end
    )

    rangeSlider.set(cfg.range, false)

    -- bots: row right after "health"; left square = exposed (orange),
    -- right square = behind cover (blue)
    local botFrame, botLabel = previewRow(espCard, #FEATURES + 1, "", true)
    localize(botLabel, "esp.bots")

    addToggle(botFrame, false, function(value)
        cfg.enabled.bots = value

        if value then
            pcall(startBotScan)
        else
            pcall(stopBotScan)
        end
    end)

    addSwatch(botFrame, "bots", "visible", 70)
    addSwatch(botFrame, "bots", "hidden", 48)

    layoutPreview()
end, function(err)
    warn("[shitaro/esp] " .. debug.traceback(tostring(err), 2))
end)

-- Camera ---------------------------------------------------------------------
--
-- Three functions in one card, docked to the right of the ESP cards on the
-- visuals tab:
--   * field of view - slider, changes Camera.FieldOfView instead of pulling
--                    the camera back (first person stays first person): the
--                    middle is the game's own FOV, right widens up to the
--                    engine ceiling, left narrows (zoom) down to 1 degree.
--                    The row always shows the FOV that is really applied;
--   * third person - toggle, a preset on top of the slider (base distance +
--                    over-the-shoulder shift, own body made visible);
--   * free camera  - toggle + rebindable key (default F, same capture logic
--                    as the menu key). The character is frozen in place
--                    while the camera flies around.
--
-- Everything lives in its own xpcall closure: it adds nothing to the main
-- chunk's 200-local budget and an error here cannot break the menu or ESP.
-- The camera is written at RenderPriority.Last (ESP is bound one step later).

xpcall(function()
    local Workspace = game:GetService("Workspace")
    local ContextActionService = game:GetService("ContextActionService")
    local clamp = math.clamp
    local WHITE = Color3.new(1, 1, 1)

    local THIRD_DISTANCE = 8.3    -- default: studs behind the head
    local THIRD_SHOULDER = 0.2    -- default: studs to the right
    local THIRD_LIFT = 1.7        -- default: studs up
    local VISIBLE_AT = 1.5        -- body becomes visible past this distance
    local SMOOTH = 8              -- easing speed of zoom / shoulder
    local FREE_SPEED = 40         -- studs per second
    local FREE_BOOST = 3          -- LeftShift multiplier
    local LOOK_SENSITIVITY = 0.009  -- radians per pixel of mouse travel
    local PITCH_LIMIT = math.rad(89)

    -- locale keys live here so the main locale tables stay untouched
    local extra = {
        en = {
            ["cam.panel"] = "camera",
            ["cam.fov"] = "field of view",
            ["cam.fovReset"] = "reset",
            ["cam.third"] = "third person",
            ["cam.thirdX"] = "left / right",
            ["cam.thirdY"] = "up / down",
            ["cam.thirdDist"] = "distance",
            ["cam.free"] = "free camera",
            ["cam.freeKey"] = "camera key",
        },
        ru = {
            ["cam.panel"] = "камера",
            ["cam.fov"] = "поле зрения",
            ["cam.fovReset"] = "сброс",
            ["cam.third"] = "вид от 3 лица",
            ["cam.thirdX"] = "влево / вправо",
            ["cam.thirdY"] = "вверх / вниз",
            ["cam.thirdDist"] = "дистанция",
            ["cam.free"] = "свободная камера",
            ["cam.freeKey"] = "клавиша камеры",
        },
    }

    for language, pack in pairs(extra) do
        for key, text in pairs(pack) do
            locale[language][key] = text
        end
    end

    -- State --------------------------------------------------------------------

    local cfg = {
        fov = 70, fovOn = false, third = false,   -- fov = degrees
        thirdX = THIRD_SHOULDER,   -- studs to the right (negative = left)
        thirdY = THIRD_LIFT,       -- studs up (negative = down)
        thirdDist = THIRD_DISTANCE, -- studs behind the head
    }
    local current, shoulder, lift = 0, 0, 0   -- eased values
    local lastWritten, lastBase              -- guards against re-offsetting
    local freeState
    local paintFree
    local freeKey = Enum.KeyCode.F
    local capturingFree = false

    local bodyParts = {}      -- part -> original LocalTransparencyModifier
    local bodyChar, bodyScan = nil, 0
    local viewParts = {}      -- first person arms / gun parts -> original value
    local viewScan = 0

    local rayParams = RaycastParams.new()
    rayParams.FilterType = Enum.RaycastFilterType.Exclude
    rayParams.IgnoreWater = true

    -- Helpers ------------------------------------------------------------------

    local function liveCharacter()
        local char = player.Character
        local root = char and char:FindFirstChild("HumanoidRootPart")
        local hum = char and char:FindFirstChildOfClass("Humanoid")

        if char and char.Parent and root and root:IsA("BasePart") and hum
            and hum.Health > 0
            and hum:GetState() ~= Enum.HumanoidStateType.Dead then
            return char, root, hum
        end

        return nil
    end

    -- First person hides the body through LocalTransparencyModifier. While the
    -- camera is away from the head the modifier is forced to 0 and the original
    -- values are remembered, so going back to first person restores them.
    local function releaseBody()
        for part, original in pairs(bodyParts) do
            if part.Parent then
                part.LocalTransparencyModifier = original
            end
        end

        for part, original in pairs(viewParts) do
            if part.Parent then
                part.LocalTransparencyModifier = original
            end
        end

        table.clear(bodyParts)
        table.clear(viewParts)
        bodyChar = nil
    end

    -- The first person arms and gun are a model the game keeps under the
    -- camera and glues to it every frame, so they follow a camera that is
    -- pulled back and float in front of it. While the real body is shown they
    -- are made invisible (and restored together with the body).
    local function hideViewModel(now)
        local cam = Workspace.CurrentCamera

        if cam and now - viewScan > 0.25 then
            viewScan = now

            for _, child in ipairs(cam:GetChildren()) do
                if child:IsA("Model") then
                    for _, item in ipairs(child:GetDescendants()) do
                        if item:IsA("BasePart") and viewParts[item] == nil then
                            viewParts[item] = item.LocalTransparencyModifier
                        end
                    end
                end
            end
        end

        for part in pairs(viewParts) do
            if part.Parent then
                if part.LocalTransparencyModifier ~= 1 then
                    part.LocalTransparencyModifier = 1
                end
            else
                viewParts[part] = nil
            end
        end
    end

    -- Some games keep their own visible copy of our avatar next to the real
    -- (hidden, raw) player.Character. Forcing the REAL character visible then
    -- shows a body the game never poses for the camera - it stands in its raw
    -- orientation, sideways. When such a copy exists, it is the body that gets
    -- shown instead of player.Character.
    local copyHumanoids = {}
    local copyReady = false
    local ownCopy, ownCopyAt = nil, 0

    local function noteHumanoid(item)
        if item:IsA("Humanoid") then
            local model = item.Parent

            if model and model:IsA("Model") then
                copyHumanoids[model] = item
            end
        end
    end

    local function ensureCopyScan()
        if copyReady then
            return
        end

        copyReady = true

        connect(Workspace.DescendantAdded, noteHumanoid)

        connect(Workspace.DescendantRemoving, function(item)
            if item:IsA("Humanoid") and copyHumanoids[item.Parent] == item then
                copyHumanoids[item.Parent] = nil
            end
        end)

        for _, item in ipairs(Workspace:GetDescendants()) do
            noteHumanoid(item)
        end
    end

    local function findOwnCopy(char, rootPart)
        local now = os.clock()

        if now - ownCopyAt < 0.5 then
            return ownCopy and ownCopy.Parent and ownCopy or nil
        end

        ownCopyAt = now
        ownCopy = nil
        ensureCopyScan()

        local cam = Workspace.CurrentCamera

        for model, humanoid in pairs(copyHumanoids) do
            if model ~= char
                and model.Parent
                and not model:IsDescendantOf(char)
                and not char:IsDescendantOf(model)
                and not (cam and model:IsDescendantOf(cam))
                and not Players:GetPlayerFromCharacter(model) then
                local root = humanoid.RootPart
                    or model:FindFirstChild("HumanoidRootPart")
                    or model.PrimaryPart

                if model.Name == player.Name
                    or (root and rootPart
                        and (root.Position - rootPart.Position).Magnitude < 1.25) then
                    ownCopy = model
                    break
                end
            end
        end

        return ownCopy
    end

    local function showBody(char, show)
        if not show then
            if next(bodyParts) ~= nil or next(viewParts) ~= nil then
                releaseBody()
            end

            return
        end

        local now = os.clock()

        if bodyChar ~= char then
            -- another model is shown now (own copy <-> real character): give
            -- the previous one its original transparency back first
            for part, original in pairs(bodyParts) do
                if part.Parent then
                    part.LocalTransparencyModifier = original
                end
            end

            table.clear(bodyParts)
            bodyChar = char
            bodyScan = 0
        end

        if now - bodyScan > 1 then
            bodyScan = now

            for _, item in ipairs(char:GetDescendants()) do
                if item:IsA("BasePart") and bodyParts[item] == nil then
                    bodyParts[item] = item.LocalTransparencyModifier
                end
            end
        end

        for part in pairs(bodyParts) do
            if part.Parent and part.LocalTransparencyModifier ~= 0 then
                part.LocalTransparencyModifier = 0
            end
        end

        hideViewModel(now)
    end

    -- Walls are cover, invisible parts and other characters are not.
    local function clip(from, to, char)
        local direction = to - from

        if direction.Magnitude < 0.01 then
            return to
        end

        local filter = { char }

        for _ = 1, 4 do
            rayParams.FilterDescendantsInstances = filter

            local hit = Workspace:Raycast(from, direction, rayParams)

            if not hit then
                return to
            end

            local part = hit.Instance
            local model = part:FindFirstAncestorOfClass("Model")
            local human = model and model:FindFirstChildOfClass("Humanoid")
                and model

            if part:IsA("Terrain") then
                return from + direction.Unit * math.max(0, hit.Distance - 0.4)
            elseif human then
                filter[#filter + 1] = human
            elseif part.Transparency >= 0.9 then
                filter[#filter + 1] = part
            else
                return from + direction.Unit * math.max(0, hit.Distance - 0.4)
            end
        end

        return from
    end

    -- Field of view -------------------------------------------------------------
    --
    -- The slider is an ABSOLUTE field of view in degrees (1 - 120, the range the
    -- engine allows) and it applies at once. Nothing is derived from the game's
    -- own value any more: a game that eases the FOV from its current value used
    -- to feed our own write back as "the game's FOV" and the old relative
    -- slider drifted up to 120 and stopped responding.
    --
    -- Until the slider is touched nothing is written at all; "reset" hands the
    -- property back to the game. The write happens late (RenderPriority.Last - 1,
    -- before the aimbot and the ESP) and is repeated at once if the game
    -- overwrites it later in the same frame, so the picture, the aim and the
    -- boxes all use the same value.

    local FOV_MIN = 1
    local FOV_LIMIT = 120
    local FOV_STEP = "ShitaroFov"
    local FOV_FIXES = 3          -- re-asserts per frame, a fight guard

    local fovGame                -- the game's own FOV, tracked while we do not write
    local fovWritten             -- last value we wrote (nil: the game owns it)
    local fovBusy = false
    local fovFixes = 0
    local fovCam, fovLink

    local function writeFov(cam, value)
        fovBusy = true
        cam.FieldOfView = value
        fovBusy = false
        fovWritten = value
    end

    local function applyFov(cam)
        local value = cam.FieldOfView

        if not cfg.fovOn then
            if fovWritten then
                -- reset: give the game's value back once
                if fovGame then
                    writeFov(cam, fovGame)
                end

                fovWritten = nil
            else
                fovGame = value
            end

            return
        end

        if not fovGame then
            fovGame = value
        end

        local target = clamp(cfg.fov, FOV_MIN, FOV_LIMIT)

        if math.abs(value - target) > 0.001 then
            writeFov(cam, target)
        else
            fovWritten = target
        end
    end

    local function trackFovCam(cam)
        if cam == fovCam then
            return
        end

        if fovLink then
            fovLink:Disconnect()
            fovLink = nil
        end

        fovCam = cam

        fovLink = cam:GetPropertyChangedSignal("FieldOfView"):Connect(function()
            if fovBusy or not cfg.fovOn or uiState.closed then
                return
            end

            if fovFixes >= FOV_FIXES then
                return
            end

            local target = clamp(cfg.fov, FOV_MIN, FOV_LIMIT)

            if math.abs(cam.FieldOfView - target) > 0.001 then
                fovFixes = fovFixes + 1
                writeFov(cam, target)
            end
        end)
    end

    local function fovFrame()
        if uiState.closed then
            return
        end

        local cam = Workspace.CurrentCamera

        if not cam then
            return
        end

        fovFixes = 0
        trackFovCam(cam)
        applyFov(cam)
    end

    pcall(function()
        RunService:UnbindFromRenderStep(FOV_STEP)
    end)

    if not pcall(function()
        RunService:BindToRenderStep(
            FOV_STEP,
            Enum.RenderPriority.Last.Value - 1,
            fovFrame
        )
    end) then
        connect(RunService.RenderStepped, fovFrame)
    end

    -- hands the FOV back to the game when the cheat is shut down
    local function restoreFov()
        pcall(function()
            RunService:UnbindFromRenderStep(FOV_STEP)
        end)

        if fovLink then
            fovLink:Disconnect()
            fovLink = nil
        end

        local cam = Workspace.CurrentCamera

        if cam and fovWritten and fovGame then
            cam.FieldOfView = fovGame
        end

        fovWritten, fovCam = nil, nil
    end

    -- Third person --------------------------------------------------------------

    -- The third person camera is pinned to the CHARACTER, not to the camera's
    -- own previous position. Offsetting the previous camera made the offset and
    -- the aimbot feed each ther: the aim turned the camera, the turned camera
    -- moved the offset, the moved offset changed the aim, and the view ended up
    -- circling the player and looking straight back at him.
    local function thirdPersonPoint(anchor, look, right, distance, shoulder, up)
        return anchor - look * distance + right * shoulder
            + Vector3.new(0, up, 0)
    end

    local function applyOffset(cam, char, dt)
        local targetDistance = cfg.third and cfg.thirdDist or 0
        local targetShoulder = cfg.third and cfg.thirdX or 0
        local targetLift = cfg.third and cfg.thirdY or 0
        local k = math.min(1, dt * SMOOTH)

        current = current + (targetDistance - current) * k
        shoulder = shoulder + (targetShoulder - shoulder) * k
        lift = lift + (targetLift - lift) * k

        if math.abs(targetDistance - current) < 0.02 then
            current = targetDistance
        end

        if math.abs(targetShoulder - shoulder) < 0.02 then
            shoulder = targetShoulder
        end

        if math.abs(targetLift - lift) < 0.02 then
            lift = targetLift
        end

        if math.abs(current) < 0.001
            and math.abs(shoulder) < 0.001
            and math.abs(lift) < 0.001 then
            lastWritten, lastBase = nil, nil
            showBody(char, false)
            return
        end

        local cf = cam.CFrame
        local head = char:FindFirstChild("Head")
        local rootPart = char:FindFirstChild("HumanoidRootPart")
            or char.PrimaryPart
        local anchor = head and head.Position
            or (rootPart and rootPart.Position + Vector3.new(0, 1.5, 0))

        if not anchor then
            return
        end

        -- The offset is measured from the HEAD, along the camera's own view.
        -- The old code offset the camera's previous position instead, so every
        -- frame pushed it another six studs back and the view ran away. Anchor
        -- plus view means the camera is always exactly THIRD_DISTANCE behind
        -- the head, whichever way the view is turned.
        local desired = thirdPersonPoint(
            anchor,
            cf.LookVector,
            cf.RightVector,
            current,
            shoulder,
            lift
        )
        local final = clip(anchor, desired, char)

        lastBase = cf
        cam.CFrame = cf - cf.Position + final
        lastWritten = cam.CFrame

        showBody(
            findOwnCopy(char, rootPart) or char,
            current > VISIBLE_AT
        )
    end

    -- Body report ---------------------------------------------------------------
    -- getgenv().shitaro_body() in the executor, third person ON: copies to the
    -- clipboard how the body is oriented against the camera and whether the
    -- game keeps a copy of the avatar.

    local function yawOf(cf)
        local look = cf.LookVector

        return math.deg(math.atan2(-look.X, -look.Z))
    end

    local function yawDiff(a, b)
        return (a - b + 180) % 360 - 180
    end

    local function bodyReport()
        local cam = Workspace.CurrentCamera
        local char, root, hum = liveCharacter()
        local out = {}

        if not char or not cam then
            out[#out + 1] = "no live character"
        else
            local camYaw = yawOf(cam.CFrame)

            out[#out + 1] = string.format(
                "third=%s camYaw=%.0f autoRotate=%s",
                tostring(cfg.third), camYaw, tostring(hum.AutoRotate)
            )

            out[#out + 1] = string.format(
                "root yaw diff vs camera: %.0f", yawDiff(yawOf(root.CFrame), camYaw)
            )

            for _, name in ipairs({ "LowerTorso", "UpperTorso", "Torso", "Head" }) do
                local part = char:FindFirstChild(name)

                if part and part:IsA("BasePart") then
                    out[#out + 1] = string.format(
                        "%s yaw diff: %.0f  localTransparency=%.2f",
                        name, yawDiff(yawOf(part.CFrame), camYaw),
                        part.LocalTransparencyModifier
                    )
                end
            end

            local joint = char:FindFirstChild("RootJoint", true)

            if joint and joint:IsA("Motor6D") then
                local _, c0y = joint.C0:ToOrientation()
                local _, ty = joint.Transform:ToOrientation()

                out[#out + 1] = string.format(
                    "RootJoint C0 yaw=%.0f Transform yaw=%.0f",
                    math.deg(c0y), math.deg(ty)
                )
            end

            local copy = findOwnCopy(char, root)

            if copy then
                local copyRoot = copy:FindFirstChild("HumanoidRootPart")
                    or copy.PrimaryPart
                local sample = copy:FindFirstChildWhichIsA("BasePart", true)

                out[#out + 1] = "OWN COPY: " .. copy:GetFullName()

                if copyRoot then
                    out[#out + 1] = string.format(
                        "copy root yaw diff vs camera: %.0f",
                        yawDiff(yawOf(copyRoot.CFrame), camYaw)
                    )
                end

                if sample then
                    out[#out + 1] = string.format(
                        "copy part %s transparency=%.2f localTransparency=%.2f",
                        sample.Name, sample.Transparency,
                        sample.LocalTransparencyModifier
                    )
                end
            else
                out[#out + 1] = "no own copy found"
            end
        end

        local text = table.concat(out, "\n")

        warn("[shitaro/body]\n" .. text)
        pcall(function()
            setclipboard(text)
        end)
    end

    pcall(function()
        getgenv().shitaro_body = bodyReport
    end)

    -- Free camera --------------------------------------------------------------

    local SINK_NAME = "ShitaroFreecamSink"
    local SINK_PRIORITY = Enum.ContextActionPriority.High.Value + 500

    -- keeps the game from seeing these while the camera is free
    local SINK_INPUTS = {
        Enum.KeyCode.W, Enum.KeyCode.A, Enum.KeyCode.S, Enum.KeyCode.D,
        Enum.KeyCode.Q, Enum.KeyCode.E, Enum.KeyCode.Space,
        Enum.KeyCode.LeftShift, Enum.KeyCode.LeftControl,
        Enum.UserInputType.MouseButton1, Enum.UserInputType.MouseButton2,
        Enum.UserInputType.MouseWheel, Enum.UserInputType.MouseMovement,
    }

    local function sinkInput()
        return Enum.ContextActionResult.Sink
    end

    local function disableFree()
        local fs = freeState

        if not fs then
            return
        end

        freeState = nil

        pcall(function()
            ContextActionService:UnbindAction(SINK_NAME)
        end)

        if fs.beat then
            fs.beat:Disconnect()
        end

        local root = fs.root

        if root and root.Parent then
            root.CFrame = fs.rootCF
            root.Anchored = fs.anchored
        end

        if fs.hum and fs.hum.Parent and fs.hum.WalkSpeed == 0 then
            fs.hum.WalkSpeed = fs.walk
        end

        local cam = Workspace.CurrentCamera

        if cam then
            cam.CameraType = fs.camType
            cam.CameraSubject = fs.subject
            cam.CFrame = fs.camCF
        end

        if not window.Visible then
            pcall(function()
                UserInputService.MouseBehavior = fs.mouse
            end)
        end

        releaseBody()
        lastWritten, lastBase = nil, nil

        if paintFree then
            pcall(paintFree, false)
        end
    end

    local function enableFree()
        if freeState then
            return
        end

        local cam = Workspace.CurrentCamera
        local char, root, hum = liveCharacter()

        if not cam or not char then
            return
        end

        local cf = cam.CFrame
        local look = cf.LookVector

        local fs = {
            char = char,
            root = root,
            hum = hum,
            rootCF = root.CFrame,
            anchored = root.Anchored,
            walk = hum.WalkSpeed,
            camType = cam.CameraType,
            subject = cam.CameraSubject,
            camCF = cf,
            mouse = UserInputService.MouseBehavior,
            pos = cf.Position,
            yaw = math.atan2(-look.X, -look.Z),
            pitch = math.asin(clamp(look.Y, -1, 1)),
        }

        freeState = fs

        pcall(function()
            ContextActionService:UnbindAction(SINK_NAME)
        end)

        pcall(function()
            ContextActionService:BindActionAtPriority(
                SINK_NAME,
                sinkInput,
                false,
                SINK_PRIORITY,
                table.unpack(SINK_INPUTS)
            )
        end)

        -- the character stays exactly where it is: no physics, no writes
        root.Anchored = true
        hum.WalkSpeed = 0
        cam.CameraType = Enum.CameraType.Scriptable
        lastWritten, lastBase = nil, nil

        -- the game rotates the character itself (AutoRotate is off), so the
        -- pose is pinned again on every physics step as well
        fs.beat = RunService.Heartbeat:Connect(function()
            if freeState == fs and root.Parent
                and root.CFrame ~= fs.rootCF then
                root.CFrame = fs.rootCF
            end
        end)
    end

    local function setFree(on)
        if on then
            enableFree()
        else
            disableFree()
        end

        if paintFree then
            paintFree(freeState ~= nil)
        end
    end

    local function isDown(key)
        return UserInputService:IsKeyDown(key)
    end

    local function stepFree(cam, dt)
        local fs = freeState
        local root = fs.root

        if root.CFrame ~= fs.rootCF then
            root.CFrame = fs.rootCF
        end

        if not root.Anchored then
            root.Anchored = true
        end

        if cam.CameraType ~= Enum.CameraType.Scriptable then
            cam.CameraType = Enum.CameraType.Scriptable
        end

        -- menu open: the pointer belongs to the menu, the camera holds still
        if not window.Visible then
            if UserInputService.MouseBehavior ~= Enum.MouseBehavior.LockCenter then
                UserInputService.MouseBehavior = Enum.MouseBehavior.LockCenter
            end

            local delta = UserInputService:GetMouseDelta()
            local sensitivity = LOOK_SENSITIVITY
                * UserInputService.MouseDeltaSensitivity

            fs.yaw = fs.yaw - delta.X * sensitivity
            fs.pitch = clamp(
                fs.pitch - delta.Y * sensitivity,
                -PITCH_LIMIT,
                PITCH_LIMIT
            )

            local x, y, z = 0, 0, 0

            if isDown(Enum.KeyCode.W) then z = z - 1 end
            if isDown(Enum.KeyCode.S) then z = z + 1 end
            if isDown(Enum.KeyCode.A) then x = x - 1 end
            if isDown(Enum.KeyCode.D) then x = x + 1 end
            if isDown(Enum.KeyCode.Space) or isDown(Enum.KeyCode.E) then
                y = y + 1
            end
            if isDown(Enum.KeyCode.LeftControl) or isDown(Enum.KeyCode.Q) then
                y = y - 1
            end

            local rotation = CFrame.Angles(0, fs.yaw, 0)
                * CFrame.Angles(fs.pitch, 0, 0)

            local direction = rotation:VectorToWorldSpace(Vector3.new(x, 0, z))
                + Vector3.new(0, y, 0)

            if direction.Magnitude > 0 then
                local speed = FREE_SPEED
                    * (isDown(Enum.KeyCode.LeftShift) and FREE_BOOST or 1)

                fs.pos = fs.pos + direction.Unit * speed * dt
            end
        end

        cam.CFrame = CFrame.new(fs.pos)
            * CFrame.Angles(0, fs.yaw, 0)
            * CFrame.Angles(fs.pitch, 0, 0)

        showBody(fs.char, (fs.pos - root.Position).Magnitude > 3)
    end

    -- Frame step ---------------------------------------------------------------

    local function step(dt)
        if uiState.closed then
            return
        end

        local cam = Workspace.CurrentCamera

        if not cam then
            return
        end

        dt = math.min(dt, 0.1)

        local char = liveCharacter()

        if freeState then
            if char and char == freeState.char then
                stepFree(cam, dt)
                return
            end

            -- died, respawned or left: hand the camera back
            disableFree()
        end

        if not char then
            releaseBody()
            lastWritten, lastBase = nil, nil
            return
        end

        applyOffset(cam, char, dt)
    end

    local stepName = "ShitaroCamera"

    pcall(function()
        RunService:UnbindFromRenderStep(stepName)
    end)

    -- One tick after the game's camera script (200) and BEFORE the aim (Last).
    -- The third person offset therefore always works from the view the game
    -- produced, never from a view the aimbot just wrote - so the two can never
    -- move each other - and the aimbot aims from the camera position that is
    -- already offset, which is what keeps the crosshair on the target instead
    -- of a few degrees left of it (parallax of the shoulder offset).
    local bound = pcall(function()
        RunService:BindToRenderStep(
            stepName,
            Enum.RenderPriority.Camera.Value + 1,
            step
        )
    end)

    if not bound then
        connect(RunService.RenderStepped, step)
    end

    -- not registered through connect(): that list is disconnected first
    gui.Destroying:Connect(function()
        pcall(disableFree)
        pcall(releaseBody)
        pcall(restoreFov)

        pcall(function()
            getgenv().shitaro_body = nil
        end)

        pcall(function()
            RunService:UnbindFromRenderStep(stepName)
        end)

        pcall(function()
            ContextActionService:UnbindAction(SINK_NAME)
        end)
    end)

    -- Menu: card on the right of the visuals tab -------------------------------
    --
    -- A second scroll frame of its own: the ESP cards keep their layout, and
    -- layoutPreview places this card like any other (column width 330). It sits
    -- in the top right corner of the tab, where the colour-squares hint used to
    -- be, so the whole right column is the camera card.

    local camScroll = pageScroll(tabs[3].page, "CameraScroll")
    camScroll.Position = UDim2.fromOffset(430, 14)
    camScroll.Size = UDim2.new(0, 350, 1, -24)
    panelWidths[camScroll] = 330

    -- the colour editor is docked over this area: hide the card while it is open
    if picker.panel then
        camScroll.Visible = not picker.panel.Visible

        connect(picker.panel:GetPropertyChangedSignal("Visible"), function()
            camScroll.Visible = not picker.panel.Visible
        end)
    end

    local camCard = previewPanel(camScroll, "cam.panel", 1, 7)

    local function addToggle(frame, onClick)
        local track = make("Frame", {
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.new(1, -12, 0.5, 0),
            Size = UDim2.fromOffset(26, 14),
            BackgroundColor3 = WHITE,
            BackgroundTransparency = 0.86,
            ZIndex = 2,
        }, frame)

        corner(track, UDim.new(1, 0))

        local knob = make("Frame", {
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.new(0, 2, 0.5, 0),
            Size = UDim2.fromOffset(10, 10),
            BackgroundColor3 = colors.sub,
            BackgroundTransparency = 0.15,
            ZIndex = 3,
        }, track)

        corner(knob, UDim.new(1, 0))

        local hit = make("TextButton", {
            Size = UDim2.fromScale(1, 1),
            ZIndex = 5,
        }, frame)

        connect(hit.Activated, onClick)

        return function(state)
            animate(track, {
                BackgroundColor3 = state and colors.accent or WHITE,
                BackgroundTransparency = state and 0.35 or 0.86,
            })

            animate(knob, {
                Position = UDim2.new(0, state and 14 or 2, 0.5, 0),
                BackgroundColor3 = state and colors.accent or colors.sub,
            })
        end
    end

    -- 1: field of view, absolute degrees. The slider only starts writing once
    -- it is dragged; "reset" gives the property back to the game.
    local fovRow, fovLabel = previewRow(camCard, 1, "", true)
    localize(fovLabel, "cam.fov")

    local fovSlider = rowSlider(
        fovRow,
        "CameraFov",
        FOV_MIN,
        FOV_LIMIT,
        function(value)
            return tostring(math.floor(value + 0.5)) .. "°"
        end,
        function(value)
            cfg.fov = math.floor(value + 0.5)
            cfg.fovOn = true
        end
    )

    local function gameFov()
        local cam = Workspace.CurrentCamera

        return fovGame or (cam and cam.FieldOfView) or 70
    end

    fovSlider.set(gameFov(), false)

    local fovReset = make("TextButton", {
        AnchorPoint = Vector2.new(0, 0.5),
        Position = UDim2.new(0.48, -56, 0.5, 0),
        Size = UDim2.fromOffset(50, 18),
        BackgroundColor3 = WHITE,
        BackgroundTransparency = 0.93,
        TextSize = 11,
        TextColor3 = colors.sub,
        TextXAlignment = Enum.TextXAlignment.Center,
        ZIndex = 5,
    }, fovRow)

    corner(fovReset, UDim.new(0, 6))
    localize(fovReset, "cam.fovReset")

    connect(fovReset.Activated, function()
        cfg.fovOn = false
        fovSlider.set(gameFov(), false)
    end)

    -- 2: third person
    local thirdRow, thirdLabel = previewRow(camCard, 2, "", true)
    localize(thirdLabel, "cam.third")

    local paintThird

    paintThird = addToggle(thirdRow, function()
        cfg.third = not cfg.third
        paintThird(cfg.third)
    end)

    -- 3-5: where the third person camera sits (works while third person is on)
    local function thirdSlider(index, labelKey, name, minValue, maxValue, field)
        local sliderRow, sliderLabel = previewRow(camCard, index, "", true)
        localize(sliderLabel, labelKey)

        local slider = rowSlider(
            sliderRow,
            name,
            minValue,
            maxValue,
            function(value)
                return string.format("%.1f", value)
            end,
            function(value)
                cfg[field] = math.floor(value * 10 + 0.5) / 10
            end
        )

        slider.set(cfg[field], false)

        return slider
    end

    thirdSlider(3, "cam.thirdX", "ThirdX", -10, 10, "thirdX")
    thirdSlider(4, "cam.thirdY", "ThirdY", -6, 10, "thirdY")
    thirdSlider(5, "cam.thirdDist", "ThirdDist", 0, 25, "thirdDist")

    -- 6: free camera
    local freeRow, freeLabel = previewRow(camCard, 6, "", true)
    localize(freeLabel, "cam.free")

    paintFree = addToggle(freeRow, function()
        setFree(freeState == nil)
    end)

    -- 7: free camera key, same capture logic as the menu key
    local keyRow, keyLabel = previewRow(camCard, 7, "", true)
    localize(keyLabel, "cam.freeKey")

    local keyField, keyValue = settingField(keyRow)

    local function refreshKey()
        keyValue.Text = capturingFree and "..." or freeKey.Name
    end

    refreshKey()

    -- one capture at a time: starting this one cancels the menu key capture
    local function beginFreeCapture()
        closeLanguageMenu()
        capturingBind = false
        refreshBindValue()
        capturingFree = true
        refreshKey()
    end

    connect(keyField.Activated, function()
        if capturingFree then
            capturingFree = false
            refreshKey()
            return
        end

        beginFreeCapture()
    end)

    connect(keyField.InputBegan, function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton2 then
            beginFreeCapture()
        end
    end)

    -- ...and starting the menu key capture cancels this one
    local function cancelFreeCapture()
        if capturingFree then
            capturingFree = false
            refreshKey()
        end
    end

    connect(bindField.Activated, cancelFreeCapture)

    connect(bindField.InputBegan, function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton2 then
            cancelFreeCapture()
        end
    end)

    connect(UserInputService.InputBegan, function(input)
        if input.UserInputType ~= Enum.UserInputType.Keyboard then
            return
        end

        if capturingFree then
            if input.KeyCode == bindKey then
                -- the menu key is taken: abort (the menu handles the press)
                capturingFree = false
                refreshKey()
            elseif input.KeyCode ~= Enum.KeyCode.Unknown then
                freeKey = input.KeyCode
                capturingFree = false
                refreshKey()
            end

            return
        end

        if capturingBind
            or UserInputService:GetFocusedTextBox()
            or input.KeyCode == bindKey then
            return
        end

        if input.KeyCode == freeKey then
            setFree(freeState == nil)
        end
    end)

    layoutPreview()
end, function(err)
    warn("[shitaro/camera] " .. debug.traceback(tostring(err), 2))
end)

-- Aimbot ---------------------------------------------------------------------
--
-- Lives in its own xpcall closure like the ESP and camera sections: it adds
-- nothing to the chunk's 200-local budget and a failure here can never break the
-- menu. The third-person offset is applied first (RenderPriority.Camera + 1),
-- the aim is written last (RenderPriority.Last) and measures its direction from
-- the offset camera position. That order fixes both third-person problems at
-- once: the offset never sees the aim (so the view cannot circle the player)
-- and the aim never guesses where the camera will be (so the crosshair is on
-- the target instead of a few degrees to the left of it).
--
-- Target point is read from the live parts every frame (head / neck / body /
-- legs), so a crouching, jumping or animating target is tracked by its current
-- pose - no cached coordinates are ever reused.

xpcall(function()
    local Workspace = game:GetService("Workspace")
    local Players = game:GetService("Players")
    local UserInputService = game:GetService("UserInputService")
    local clamp = math.clamp

    -- the ESP range slider uses metres too (1 stud = 0.28 m)
    local STUDS_TO_M = 0.28

    -- the aimbot circle is measured in pixels at this screen height and scaled
    -- to the real viewport, so the setting means the same thing on any monitor
    local AIM_REFERENCE = 1080

    -- smoothing 1..10: how fast the camera swings, in "convergence per second"
    local SPEED_FAST = 42
    local SPEED_RATIO = 0.62
    local SPEED_FLOOR = 1.6

    local cfg = {
        enabled = false,
        visible = true,      -- needs line of sight
        ignoreBots = true,
        ignoreTeam = true,
        shootOnly = false,   -- false = aim all the time
        smooth = 5,
        fov = 120,           -- circle radius, pixels at AIM_REFERENCE
        range = 400,         -- metres
        part = "head",       -- head | neck | body | legs
    }

    local PARTS = {
        { "head", "aim.part.head" },
        { "neck", "aim.part.neck" },
        { "body", "aim.part.body" },
        { "legs", "aim.part.legs" },
    }

    -- locale keys live here so the main locale tables stay untouched
    local extra = {
        en = {
            ["aim.panel"] = "aimbot",
            ["aim.filters"] = "targets",
            ["aim.tuning"] = "tuning",
            ["aim.enabled"] = "aimbot",
            ["aim.visible"] = "visibility check",
            ["aim.shootOnly"] = "only while shooting",
            ["aim.part"] = "target part",
            ["aim.part.head"] = "head",
            ["aim.part.neck"] = "neck",
            ["aim.part.body"] = "body",
            ["aim.part.legs"] = "legs",
            ["aim.ignoreBots"] = "ignore bots",
            ["aim.ignoreTeam"] = "ignore teammates",
            ["aim.smooth"] = "smoothing",
            ["aim.fov"] = "aimbot circle",
            ["aim.range"] = "max distance",
        },
        ru = {
            ["aim.panel"] = "аимбот",
            ["aim.filters"] = "цели",
            ["aim.tuning"] = "настройки",
            ["aim.enabled"] = "аимбот",
            ["aim.visible"] = "проверка видимости",
            ["aim.shootOnly"] = "только при стрельбе",
            ["aim.part"] = "часть тела",
            ["aim.part.head"] = "голова",
            ["aim.part.neck"] = "шея",
            ["aim.part.body"] = "тело",
            ["aim.part.legs"] = "ноги",
            ["aim.ignoreBots"] = "игнорировать ботов",
            ["aim.ignoreTeam"] = "игнорировать тиммейтов",
            ["aim.smooth"] = "плавность",
            ["aim.fov"] = "круг аимбота",
            ["aim.range"] = "дальность",
        },
    }

    for language, pack in pairs(extra) do
        for key, text in pairs(pack) do
            locale[language][key] = text
        end
    end

    -- Overlay: the aimbot circle ---------------------------------------------

    local stale = playerGui:FindFirstChild("ShitaroAim")

    if stale then
        stale:Destroy()
    end

    local overlay = make("ScreenGui", {
        Name = "ShitaroAim",
        IgnoreGuiInset = true,
        ResetOnSpawn = false,
        ScreenInsets = Enum.ScreenInsets.None,
        ClipToDeviceSafeArea = false,
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
        DisplayOrder = 9100,
    }, playerGui)

    local ring = make("Frame", {
        Name = "FovCircle",
        AnchorPoint = Vector2.new(0.5, 0.5),
        Position = UDim2.fromScale(0.5, 0.5),
        Size = UDim2.fromOffset(240, 240),
        BackgroundTransparency = 1,
        Visible = false,
    }, overlay)

    corner(ring, UDim.new(1, 0))

    make("UIStroke", {
        Color = colors.accent,
        Transparency = 0.45,
        Thickness = 1,
        ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
    }, ring)

    local rayParams = RaycastParams.new()
    rayParams.FilterType = Enum.RaycastFilterType.Exclude
    rayParams.IgnoreWater = true

    -- Aimbot: targeting logic -------------------------------------------------

    local partCache = setmetatable({}, { __mode = "k" })
    local botModels = {}
    local botLinks = {}

    local current          -- the target we keep locked
    local candidates = {}  -- reused every frame

    -- Every state a living enemy is never in. Ragdolled bodies are physics
    -- bodies even when their health was never touched, which is exactly how
    -- some games leave a corpse behind.
    local DEAD_STATES = {}

    for _, name in ipairs({ "Dead", "Physics", "Ragdoll", "PlatformStanding" }) do
        local state = Enum.HumanoidStateType[name]

        if state ~= nil then
            DEAD_STATES[state] = true
        end
    end

    -- A body left on the ground after death is not a target. Health alone is
    -- not enough: several games keep the corpse's Humanoid at full health
    -- (ragdoll copies, custom death systems, revived models).
    local function isAlive(char)
        local humanoid = char and char:FindFirstChildOfClass("Humanoid")

        if not humanoid or not humanoid.Parent then
            return nil
        end

        if humanoid.Health <= 0 then
            return nil
        end

        if DEAD_STATES[humanoid:GetState()] then
            return nil
        end

        -- lying on the ground, the usual ragdoll-on-death setup
        if humanoid.PlatformStand then
            return nil
        end

        -- custom death flags some games leave on the model
        if char:GetAttribute("Dead") == true
            or char:GetAttribute("IsDead") == true
            or humanoid:GetAttribute("Dead") == true then
            return nil
        end

        return humanoid
    end

    local function part(char, name)
        local found = char:FindFirstChild(name)

        if found and found:IsA("BasePart") then
            return found
        end

        return nil
    end

    -- Part references are cached, positions never are: every frame reads the
    -- current CFrame / Position of these parts.
    local function parts(char)
        local cached = partCache[char]

        if cached
            and cached.root and cached.root.Parent
            and (cached.head or cached.upper or cached.torso) then
            -- re-resolve anything that is missing (streamed in late) or was
            -- removed from the model, so a stale reference is never aimed at
            if not (cached.head and cached.head.Parent) then
                cached.head = part(char, "Head")
            end

            if not (cached.upper and cached.upper.Parent) then
                cached.upper = part(char, "UpperTorso")
            end

            if not (cached.torso and cached.torso.Parent) then
                cached.torso = part(char, "Torso")
            end

            if not (cached.leftLeg and cached.leftLeg.Parent) then
                cached.leftLeg = part(char, "LeftUpperLeg") or part(char, "Left Leg")
            end

            if not (cached.rightLeg and cached.rightLeg.Parent) then
                cached.rightLeg = part(char, "RightUpperLeg") or part(char, "Right Leg")
            end

            return cached
        end

        cached = {
            head = part(char, "Head"),
            upper = part(char, "UpperTorso"),
            torso = part(char, "Torso"),
            root = part(char, "HumanoidRootPart") or char.PrimaryPart,
            leftLeg = part(char, "LeftUpperLeg") or part(char, "Left Leg"),
            rightLeg = part(char, "RightUpperLeg") or part(char, "Right Leg"),
            leftLower = part(char, "LeftLowerLeg"),
            rightLower = part(char, "RightLowerLeg"),
        }

        partCache[char] = cached
        return cached
    end

    -- The point we aim at, in world space, right now.
    local function aimPoint(p, which)
        if which == "head" then
            return p.head and p.head.Position
        end

        if which == "neck" then
            if p.upper then
                return p.upper.CFrame * Vector3.new(0, p.upper.Size.Y * 0.5, 0)
            end

            if p.torso then
                return p.torso.CFrame * Vector3.new(0, p.torso.Size.Y * 0.5, 0)
            end

            return p.head and p.head.Position
        end

        if which == "body" then
            if p.upper then
                return p.upper.Position
            end

            if p.torso then
                return p.torso.Position
            end

            return p.root and p.root.Position
        end

        -- legs: middle of the upper legs, whatever pose they are in
        if p.leftLeg and p.rightLeg then
            return (p.leftLeg.Position + p.rightLeg.Position) * 0.5
        end

        if p.leftLower and p.rightLower then
            return (p.leftLower.Position + p.rightLower.Position) * 0.5
        end

        if p.root then
            return p.root.Position - Vector3.new(0, p.root.Size.Y * 0.5 + 0.5, 0)
        end

        return nil
    end

    -- Raycasts are the most expensive check in the aimbot and a target that
    -- was visible 80 ms ago is visible now: the answer is reused briefly, so
    -- a locked target costs a few raycasts per second instead of 60.
    local SIGHT_TTL = 0.08
    local sightAt = setmetatable({}, { __mode = "k" })
    local sightOk = setmetatable({}, { __mode = "k" })

    -- Walls block, invisible parts and characters do not.
    local function hasSight(from, to, target, localChar)
        local direction = to - from

        if direction.Magnitude < 0.01 then
            return true
        end

        local filter = { target }

        if localChar then
            filter[#filter + 1] = localChar
        end

        for _ = 1, 4 do
            rayParams.FilterDescendantsInstances = filter

            local hit = Workspace:Raycast(from, direction, rayParams)

            if not hit then
                return true
            end

            local piece = hit.Instance

            if piece:IsA("Terrain") then
                return false
            end

            local model = piece:FindFirstAncestorOfClass("Model")

            if model and model:FindFirstChildOfClass("Humanoid") then
                filter[#filter + 1] = model
            elseif piece.Transparency >= 0.9 then
                filter[#filter + 1] = piece
            else
                return false
            end
        end

        return false
    end

    -- Players:GetPlayers() allocates a table per call: keep one list.
    local roster = {}
    local rosterNames = {}

    local function refreshRoster()
        local list = Players:GetPlayers()

        for index = 1, #list do
            roster[index] = list[index]
        end

        for index = #list + 1, #roster do
            roster[index] = nil
        end

        table.clear(rosterNames)

        for index = 1, #roster do
            local other = roster[index]

            rosterNames[other.Name] = other
        end
    end

    refreshRoster()

    -- Modes with a single team for everybody (or none at all) must not lose
    -- every target to the teammate filter, so it only applies while a second
    -- side really exists.
    --
    -- The sides themselves are read by the ESP block (Roblox Team, attributes,
    -- value objects, character folders - see sideOf there) and shared through
    -- uiState, so the aimbot and the ESP can never disagree about who is a
    -- teammate. The plain Roblox-Team check below is only the fallback for the
    -- case that the ESP block failed to load.
    local sidesOn = false
    local sidesAt = -1

    local function fallbackRefreshSides(now)
        if now - sidesAt < 1 then
            return
        end

        sidesAt = now
        sidesOn = false

        local mine = player.Team

        if mine == nil then
            return
        end

        for index = 1, #roster do
            local other = roster[index]

            if other ~= player and other.Team ~= nil and other.Team ~= mine then
                sidesOn = true
                return
            end
        end
    end

    local function fallbackIsTeammate(target)
        local mine = player.Team

        return mine ~= nil and sidesOn and target.Team == mine
    end

    local function refreshSides(now)
        local shared = uiState.refreshSides

        if shared then
            shared(now)
        else
            fallbackRefreshSides(now)
        end
    end

    local function isTeammate(target)
        local shared = uiState.isTeammate

        if shared then
            return shared(target)
        end

        return fallbackIsTeammate(target)
    end

    -- Bodies that outlive the player. Two shapes are covered:
    --   * a model that carries a player's name but is not his character any
    --     more - that is the body he left behind;
    --   * a model that has not moved its root for a while - a living character
    --     animates and drifts even when it stands still, a corpse does not.
    local FROZEN_AFTER = 1.5
    local frozenAt = setmetatable({}, { __mode = "k" })

    local function isFrozenBody(model)
        local root = model.PrimaryPart
            or model:FindFirstChild("HumanoidRootPart")

        if not root then
            return false
        end

        local now = os.clock()
        local state = frozenAt[model]
        local pos = root.Position

        if not state then
            frozenAt[model] = { pos = pos, since = now }
            return false
        end

        if (pos - state.pos).Magnitude > 0.05 then
            state.pos = pos
            state.since = now
            return false
        end

        return now - state.since > FROZEN_AFTER
    end

    local function isLeftoverBody(model)
        local owner = rosterNames[model.Name]

        return owner ~= nil and owner.Character ~= model
    end

    -- Bots are only collected while they can actually be targeted.
    local function noteBot(item)
        if not item:IsA("Humanoid") then
            return
        end

        local model = item.Parent

        if model and model:IsA("Model") then
            botModels[model] = item
        end
    end

    local function stopBotScan()
        for _, link in ipairs(botLinks) do
            link:Disconnect()
        end

        table.clear(botLinks)
        table.clear(botModels)
    end

    local function startBotScan()
        if #botLinks > 0 then
            return
        end

        table.insert(botLinks, Workspace.DescendantAdded:Connect(noteBot))

        table.insert(botLinks, Workspace.DescendantRemoving:Connect(function(item)
            if item:IsA("Humanoid") and botModels[item.Parent] == item then
                botModels[item.Parent] = nil
            end
        end))

        for _, item in ipairs(Workspace:GetDescendants()) do
            noteBot(item)
        end
    end

    -- our own avatar in any shape (custom characters keep a visible copy)
    -- Nothing inside our own body can be a target, whatever the model is
    -- called, however it was cloned and whoever owns it: an enemy cannot stand
    -- inside our hitbox, so anything that close IS us.
    local SELF_RADIUS = 3.5

    -- Same rule as the bot ESP: a copy of our own avatar is our avatar. The
    -- copy stands exactly where we stand, so aiming at it points the camera at
    -- ourselves: no effect in first person (the aim point sits on the camera)
    -- and a spinning view in third person.
    local function isOwnAvatar(model, humanoid)
        local char = player.Character

        if char then
            if model == char
                or model:IsDescendantOf(char)
                or char:IsDescendantOf(model) then
                return true
            end

            local ownHum = char:FindFirstChildOfClass("Humanoid")
            local ownRoot = char:FindFirstChild("HumanoidRootPart")
                or char.PrimaryPart

            if ownHum and humanoid == ownHum then
                return true
            end

            local root = humanoid and humanoid.RootPart

            if root then
                if ownRoot and root == ownRoot then
                    return true
                end

                if ownRoot
                    and (root.Position - ownRoot.Position).Magnitude < 1.25 then
                    return true
                end
            end
        end

        local cam = Workspace.CurrentCamera

        if cam and humanoid and cam.CameraSubject == humanoid then
            return true
        end

        if model.Name == player.Name
            or (char and model.Name == char.Name) then
            return true
        end

        return false
    end

    local function aimSpeed()
        local speed = SPEED_FAST * (SPEED_RATIO ^ (cfg.smooth - 1))

        if speed < SPEED_FLOOR then
            speed = SPEED_FLOOR
        end

        return speed
    end

    -- Our own aim, kept between frames. Some games rebuild the camera from the
    -- mouse every frame instead of continuing from where we left it; pulling
    -- only a fraction of the way from THAT view never accumulates, so the
    -- crosshair stopped short of the target (and the miss grew with range).
    -- heldCF is what we wrote last frame, gameCF is what the game gave us
    -- before that write.
    local heldCF, gameCF

    local function dropHold()
        heldCF, gameCF = nil, nil
    end

    local function lookAngle(a, b)
        return math.acos(clamp(a.LookVector:Dot(b.LookVector), -1, 1))
    end

    local function aimAt(cam, point, dt)
        local view = cam.CFrame
        local origin = view.Position

        if (point - origin).Magnitude < 0.1 then
            return
        end

        local base = view

        if heldCF and gameCF
            and lookAngle(view, gameCF) <= lookAngle(view, heldCF) then
            -- the game started over from its own view: keep our pull on top
            -- of it and add the mouse movement it made since last frame
            local rotHeld = heldCF - heldCF.Position
            local rotLast = gameCF - gameCF.Position
            local rotNow = view - origin

            base = CFrame.new(origin) * (rotHeld * rotLast:Inverse() * rotNow)
        end

        local desired = CFrame.lookAt(origin, point)
        local k = 1 - math.exp(-aimSpeed() * dt)

        if k > 1 then
            k = 1
        end

        local result = base:Lerp(desired, k)

        cam.CFrame = result
        heldCF, gameCF = result, view
    end

    local function step(dt)
        if uiState.closed then
            return
        end

        local cam = Workspace.CurrentCamera

        if not cam then
            return
        end

        dt = math.min(dt, 0.1)

        local viewport = cam.ViewportSize
        local radius = cfg.fov * (viewport.Y / AIM_REFERENCE)

        ring.Visible = cfg.enabled
        ring.Size = UDim2.fromOffset(radius * 2, radius * 2)

        if not cfg.enabled then
            current = nil
            dropHold()
            return
        end

        -- the free camera owns the camera while it is on
        if cam.CameraType == Enum.CameraType.Scriptable then
            dropHold()
            return
        end

        local camPos = cam.CFrame.Position
        local localChar = player.Character
        local localRoot = localChar
            and (localChar:FindFirstChild("HumanoidRootPart")
                or localChar.PrimaryPart)
        local origin = localRoot and localRoot.Position or camPos
        local localHead = localChar and localChar:FindFirstChild("Head")
        local selfPoint = localHead and localHead.Position or origin
        local centerX = viewport.X * 0.5
        local centerY = viewport.Y * 0.5
        local now = os.clock()
        local limit = radius * radius
        local lockedChar = current and current.char

        table.clear(candidates)

        local function consider(model, char, humanoid, owner)
            local point = aimPoint(parts(char), cfg.part)

            if not point then
                return
            end

            -- our own body, in any shape: never a target
            if (point - selfPoint).Magnitude < SELF_RADIUS then
                return
            end

            -- distance is measured from the character, not from the camera:
            -- pulling the camera back must not extend the aimbot range
            if (point - origin).Magnitude * STUDS_TO_M > cfg.range then
                return
            end

            local screen, onScreen = cam:WorldToViewportPoint(point)

            if not onScreen or screen.Z <= 0 then
                return
            end

            local dx = screen.X - centerX
            local dy = screen.Y - centerY
            local distance = dx * dx + dy * dy

            if distance > limit then
                return
            end

            candidates[#candidates + 1] = {
                char = char,
                humanoid = humanoid,
                model = model,
                owner = owner,
                point = point,
                score = char == lockedChar and distance * 0.5 or distance,
            }
        end

        if cfg.ignoreTeam then
            refreshSides(os.clock())
        end

        for index = 1, #roster do
            local target = roster[index]

            if target ~= player and not (cfg.ignoreTeam and isTeammate(target)) then
                local char = target.Character

                if char and char.Parent then
                    local humanoid = isAlive(char)

                    if humanoid then
                        consider(target, char, humanoid, target)
                    end
                end
            end
        end

        if not cfg.ignoreBots then
            for model, humanoid in pairs(botModels) do
                if model.Parent
                    and humanoid.Parent
                    and isAlive(model)
                    and not isOwnAvatar(model, humanoid)
                    and not Players:GetPlayerFromCharacter(model)
                    and not isFrozenBody(model)
                    and not isLeftoverBody(model) then
                    consider(model, model, humanoid, nil)
                end
            end
        end

        if #candidates == 0 then
            current = nil
            dropHold()
            return
        end

        table.sort(candidates, function(a, b)
            return a.score < b.score
        end)

        local chosen
        local attempts = math.min(#candidates, 4)

        for index = 1, attempts do
            local candidate = candidates[index]
            local seen

            if not cfg.visible then
                seen = true
            else
                local at = sightAt[candidate.char]

                if at and now - at < SIGHT_TTL then
                    seen = sightOk[candidate.char]
                else
                    seen = hasSight(
                        camPos,
                        candidate.point,
                        candidate.char,
                        localChar
                    )

                    sightAt[candidate.char] = now
                    sightOk[candidate.char] = seen
                end
            end

            if seen then
                chosen = candidate
                break
            end
        end

        if not chosen then
            current = nil
            dropHold()
            return
        end

        current = chosen

        if cfg.shootOnly
            and not UserInputService:IsMouseButtonPressed(
                Enum.UserInputType.MouseButton1
            ) then
            dropHold()
            return
        end

        aimAt(cam, chosen.point, dt)
    end

    -- getgenv().shitaro_aim() in the executor: prints every player with the
    -- numbers the aimbot decides on, so a body that still gets picked can be
    -- traced to the exact check that let it through.
    local function dumpAim()
        local cam = Workspace.CurrentCamera

        if not cam then
            return
        end

        local char = player.Character
        local root = char
            and (char:FindFirstChild("HumanoidRootPart") or char.PrimaryPart)
        local origin = root and root.Position or cam.CFrame.Position

        for index = 1, #roster do
            local target = roster[index]
            local body = target.Character
            local humanoid = body and body:FindFirstChildOfClass("Humanoid")

            if body and humanoid then
                local point = aimPoint(parts(body), cfg.part)
                local meters = point
                    and (point - origin).Magnitude * STUDS_TO_M
                    or -1

                local off = "-"

                if point then
                    local screen = cam:WorldToViewportPoint(point)

                    off = string.format(
                        "%.0fpx",
                        (Vector2.new(screen.X, screen.Y)
                            - cam.ViewportSize * 0.5).Magnitude
                    )
                end

                warn(string.format(
                    "[shitaro/aim] %s | hp=%.0f | state=%s | ragdoll=%s"
                        .. " | dead=%s | range=%.0fm | teammate=%s | me=%s"
                        .. " | off=%s",
                    target.Name,
                    humanoid.Health,
                    tostring(humanoid:GetState()),
                    tostring(humanoid.PlatformStand),
                    tostring(isAlive(body) == nil),
                    meters,
                    tostring(cfg.ignoreTeam and isTeammate(target)),
                    tostring(isOwnAvatar(body, humanoid)),
                    off
                ))
            end
        end
    end

    pcall(function()
        local env = getgenv and getgenv() or nil

        if env then
            env.shitaro_aim = dumpAim
        end
    end)

    connect(Players.PlayerAdded, refreshRoster)
    connect(Players.PlayerRemoving, refreshRoster)

    -- Aimbot: runtime ----------------------------------------------------------

    local stepName = "ShitaroAim"

    pcall(function()
        RunService:UnbindFromRenderStep(stepName)
    end)

    -- Last of all: the third person offset has already placed the camera
    -- (RenderPriority.Camera + 1), so the aim is computed from the real camera
    -- position and the crosshair lands exactly on the target. The offset never
    -- sees this write, so it cannot feed back into itself.
    local bound = pcall(function()
        RunService:BindToRenderStep(
            stepName,
            Enum.RenderPriority.Last.Value,
            step
        )
    end)

    if not bound then
        connect(RunService.RenderStepped, step)
    end

    -- not registered through connect(): that list is disconnected first
    gui.Destroying:Connect(function()
        pcall(stopBotScan)

        pcall(function()
            RunService:UnbindFromRenderStep(stepName)
        end)

        overlay:Destroy()
    end)

    -- Aimbot: menu -------------------------------------------------------------

    panelWidths[previewScroll] = window.Size.X.Offset - PANEL_RESERVE

    local mainCard = previewPanel(previewScroll, "aim.panel", 1, 4)

    local filterCard, filterHolder =
        previewPanel(previewScroll, "aim.filters", 2, 2)

    panelGapBefore[filterHolder] = 16

    local tuneCard, tuneHolder =
        previewPanel(previewScroll, "aim.tuning", 3, 3)

    panelGapBefore[tuneHolder] = 16

    -- same look as the toggles on the visuals tab
    local function addToggle(frame, state, onChange)
        local track = make("Frame", {
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.new(1, -12, 0.5, 0),
            Size = UDim2.fromOffset(26, 14),
            BackgroundColor3 = state and colors.accent or Color3.new(1, 1, 1),
            BackgroundTransparency = state and 0.35 or 0.86,
            ZIndex = 2,
        }, frame)

        corner(track, UDim.new(1, 0))

        local knob = make("Frame", {
            AnchorPoint = Vector2.new(0, 0.5),
            Position = UDim2.new(0, state and 14 or 2, 0.5, 0),
            Size = UDim2.fromOffset(10, 10),
            BackgroundColor3 = state and colors.accent or colors.sub,
            BackgroundTransparency = 0.15,
            ZIndex = 3,
        }, track)

        corner(knob, UDim.new(1, 0))

        local hit = make("TextButton", {
            Size = UDim2.fromScale(1, 1),
            BackgroundTransparency = 1,
            Text = "",
            ZIndex = 5,
        }, frame)

        connect(hit.Activated, function()
            state = not state

            animate(track, {
                BackgroundColor3 = state
                    and colors.accent
                    or Color3.new(1, 1, 1),
                BackgroundTransparency = state and 0.35 or 0.86,
            })

            animate(knob, {
                Position = UDim2.new(0, state and 14 or 2, 0.5, 0),
                BackgroundColor3 = state and colors.accent or colors.sub,
            })

            onChange(state)
        end)
    end

    -- 1: aimbot on/off
    local enableRow, enableLabel = previewRow(mainCard, 1, "", true)
    localize(enableLabel, "aim.enabled")

    addToggle(enableRow, cfg.enabled, function(value)
        cfg.enabled = value
        ring.Visible = value

        if value then
            if not cfg.ignoreBots then
                pcall(startBotScan)
            end
        else
            current = nil
            dropHold()
            pcall(stopBotScan)
        end
    end)

    -- 2: visibility check
    local sightRow, sightLabel = previewRow(mainCard, 2, "", true)
    localize(sightLabel, "aim.visible")

    addToggle(sightRow, cfg.visible, function(value)
        cfg.visible = value
    end)

    -- 3: aim only while shooting
    local shootRow, shootLabel = previewRow(mainCard, 3, "", true)
    localize(shootLabel, "aim.shootOnly")

    addToggle(shootRow, cfg.shootOnly, function(value)
        cfg.shootOnly = value
    end)

    -- 4: target part
    local partRow, partLabel = previewRow(mainCard, 4, "", true)
    localize(partLabel, "aim.part")

    local function addSegments(frame, options, initial, onChange)
        local holder = make("Frame", {
            AnchorPoint = Vector2.new(1, 0.5),
            Position = UDim2.new(1, -10, 0.5, 0),
            Size = UDim2.new(0.47, 0, 0, 22),
        }, frame)

        local buttons = {}
        local paint

        paint = function(selected)
            for id, entry in pairs(buttons) do
                local active = id == selected

                animate(entry.shell, {
                    BackgroundColor3 = active
                        and colors.accent
                        or Color3.new(1, 1, 1),
                    BackgroundTransparency = active and 0.78 or 0.97,
                })

                animate(entry.label, {
                    TextColor3 = active and colors.accent or colors.sub,
                })
            end
        end

        for index, option in ipairs(options) do
            local shell = make("Frame", {
                Position = UDim2.new((index - 1) / #options, 0, 0, 0),
                Size = UDim2.new(1 / #options, -3, 1, 0),
                BackgroundColor3 = Color3.new(1, 1, 1),
                BackgroundTransparency = 0.97,
            }, holder)

            corner(shell, UDim.new(0, 5))

            local label = make("TextLabel", {
                Text = "",
                TextSize = 11,
                TextColor3 = colors.sub,
                TextXAlignment = Enum.TextXAlignment.Center,
                Size = UDim2.fromScale(1, 1),
                ZIndex = 2,
            }, shell)

            localize(label, option[2])

            local hit = make("TextButton", {
                Size = UDim2.fromScale(1, 1),
                BackgroundTransparency = 1,
                Text = "",
                ZIndex = 5,
            }, shell)

            buttons[option[1]] = { shell = shell, label = label }

            connect(hit.Activated, function()
                onChange(option[1])
                paint(option[1])
            end)
        end

        paint(initial)
    end

    addSegments(partRow, PARTS, cfg.part, function(id)
        cfg.part = id
    end)

    -- targets: bots + teammates
    local botsRow, botsLabel = previewRow(filterCard, 1, "", true)
    localize(botsLabel, "aim.ignoreBots")

    addToggle(botsRow, cfg.ignoreBots, function(value)
        cfg.ignoreBots = value

        if value then
            pcall(stopBotScan)
        elseif cfg.enabled then
            pcall(startBotScan)
        end
    end)

    local teamRow, teamLabel = previewRow(filterCard, 2, "", true)
    localize(teamLabel, "aim.ignoreTeam")

    addToggle(teamRow, cfg.ignoreTeam, function(value)
        cfg.ignoreTeam = value
    end)

    -- tuning: smoothing, circle, range
    local smoothRow, smoothLabel = previewRow(tuneCard, 1, "", true)
    localize(smoothLabel, "aim.smooth")

    local smoothSlider = rowSlider(
        smoothRow,
        "AimSmooth",
        1,
        10,
        function(value)
            return tostring(math.floor(value + 0.5))
        end,
        function(value)
            cfg.smooth = math.floor(value + 0.5)
        end
    )

    smoothSlider.set(cfg.smooth, false)

    local circleRow, circleLabel = previewRow(tuneCard, 2, "", true)
    localize(circleLabel, "aim.fov")

    local circleSlider = rowSlider(
        circleRow,
        "AimCircle",
        1,
        150,
        function(value)
            return tostring(math.floor(value + 0.5))
        end,
        function(value)
            cfg.fov = math.floor(value + 0.5)
        end
    )

    circleSlider.set(cfg.fov, false)

    local rangeRow, rangeLabel = previewRow(tuneCard, 3, "", true)
    localize(rangeLabel, "aim.range")

    local rangeSlider = rowSlider(
        rangeRow,
        "AimRange",
        1,
        800,
        function(value)
            return math.floor(value + 0.5) .. "m"
        end,
        function(value)
            cfg.range = math.floor(value + 0.5)
        end
    )

    rangeSlider.set(cfg.range, false)

    layoutPreview()
end, function(err)
    warn("[shitaro/aim] " .. debug.traceback(tostring(err), 2))
end)

-- Shutdown confirmation ------------------------------------------------------
-- "x" in the header does not close the menu: it turns the cheat off, so it
-- always asks first. The sheet swallows clicks on everything underneath it.

-- Wrapped in a block: the chunk already sits near Lua's 200-local limit.
do
local sheet = make("TextButton", {
    Name = "ShutdownConfirm",
    Visible = false,
    Size = UDim2.fromScale(1, 1),
    BackgroundColor3 = Color3.new(),
    BackgroundTransparency = 0.45,
    AutoButtonColor = false,
    Text = "",
    ZIndex = 40,
}, window)

corner(sheet, UDim.new(0, 10))

local dialog = make("Frame", {
    Name = "ShutdownDialog",
    AnchorPoint = Vector2.new(0.5, 0.5),
    Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromOffset(330, 150),
    BackgroundColor3 = colors.bg,
    BackgroundTransparency = 0.02,
    ZIndex = 41,
}, sheet)

corner(dialog, UDim.new(0, 10))
stroke(dialog, 0.9)

onMenuStyleChanged(function(color)
    dialog.BackgroundColor3 = color
end)

localize(make("TextLabel", {
    Text = "",
    FontFace = fonts.bold,
    TextSize = 13,
    TextColor3 = colors.text,
    TextXAlignment = Enum.TextXAlignment.Left,
    TextYAlignment = Enum.TextYAlignment.Center,
    Position = UDim2.fromOffset(16, 12),
    Size = UDim2.new(1, -32, 0, 20),
    ZIndex = 41,
}, dialog), "close.title")

localize(make("TextLabel", {
    Text = "",
    TextSize = 11,
    TextColor3 = colors.dim,
    TextXAlignment = Enum.TextXAlignment.Left,
    TextYAlignment = Enum.TextYAlignment.Top,
    TextWrapped = true,
    Position = UDim2.fromOffset(16, 36),
    Size = UDim2.new(1, -32, 0, 56),
    ZIndex = 41,
}, dialog), "close.body")

local actions = make("Frame", {
    AnchorPoint = Vector2.new(1, 1),
    Position = UDim2.new(1, -16, 1, -14),
    Size = UDim2.fromOffset(0, 30),
    AutomaticSize = Enum.AutomaticSize.X,
    ZIndex = 41,
}, dialog)

row(actions, 8, Enum.HorizontalAlignment.Right)

local function dialogButton(parent, name, key, order, red)
    local button = make("TextButton", {
        Name = name,
        Size = UDim2.fromOffset(0, 30),
        AutomaticSize = Enum.AutomaticSize.X,
        BackgroundColor3 = red and Color3.fromRGB(198, 58, 58)
            or Color3.new(1, 1, 1),
        BackgroundTransparency = red and 0.05 or 0.952,
        AutoButtonColor = false,
        FontFace = fonts.bold,
        TextSize = 12,
        TextColor3 = red and Color3.new(1, 1, 1) or colors.dim,
        TextXAlignment = Enum.TextXAlignment.Center,
        TextYAlignment = Enum.TextYAlignment.Center,
        LayoutOrder = order,
        ZIndex = 41,
    }, parent)

    padding(button, 16, 16, 0, 0)
    corner(button, UDim.new(0, 8))

    if red then
        button.BackgroundTransparency = 0.05
    else
        stroke(button, 0.925)
    end

    connect(button.MouseEnter, function()
        animate(button, {
            BackgroundTransparency = red and 0 or 0.9,
        })
    end)

    connect(button.MouseLeave, function()
        animate(button, {
            BackgroundTransparency = red and 0.05 or 0.952,
        })
    end)

    return localize(button, key)
end

local cancelButton = dialogButton(actions, "ShutdownCancel", "close.cancel", 1, false)
local confirmButton = dialogButton(actions, "ShutdownConfirmOK", "close.confirm", 2, true)

openShutdownConfirm = function()
    closeLanguageMenu()
    gesture = nil
    sheet.Visible = true
end

connect(closeButton.Activated, function()
    openShutdownConfirm()
end)

connect(cancelButton.Activated, function()
    sheet.Visible = false
end)

-- A click on the dim area does nothing on purpose: the only ways out are
-- "cancel" or a full shutdown.

connect(confirmButton.Activated, function()
    local wasOpen = window.Visible

    sheet.Visible = false
    capturingBind = false
    window.Visible = false

    if uiState.shutdown then
        pcall(uiState.shutdown, wasOpen)
    end

    -- an older build of this script may have left its overlay behind
    local overlay = playerGui:FindFirstChild("ShitaroESP")

    if overlay then
        overlay:Destroy()
    end

    gui:Destroy()
end)
end

-- Games lock the mouse to the centre on every one of their frames, so undoing
-- it afterwards is not enough: while the menu is open the write from the game
-- is blocked at the metatable. If the executor has no hooking API the guard
-- flag is useless and the per-frame re-assert below does the job instead.
local cursorLocked = false
local cursorHookInstalled = false

local function wrapCallback(callback)
    if type(newcclosure) ~= "function" then
        return callback
    end

    local ok, wrapped = pcall(newcclosure, callback)

    return ok and wrapped or callback
end

local function installCursorHook()
    if cursorHookInstalled then
        return
    end

    cursorHookInstalled = true

    if type(getrawmetatable) ~= "function"
        or type(hookmetamethod) ~= "function" then
        return
    end

    local okMeta, meta = pcall(getrawmetatable, UserInputService)

    if not okMeta or type(meta) ~= "table" then
        return
    end

    local oldNewIndex = meta.__newindex

    if type(oldNewIndex) ~= "function" then
        return
    end

    pcall(hookmetamethod, UserInputService, "__newindex", wrapCallback(
        function(self, key, value)
            if cursorLocked
                and not uiState.closed
                and (key == "MouseBehavior" or key == "MouseIconEnabled") then
                return
            end

            return oldNewIndex(self, key, value)
        end
    ))
end

-- writes that have to go through even while the game is blocked
local function writeCursor(behavior, icon)
    local wasLocked = cursorLocked
    cursorLocked = false

    pcall(function()
        if UserInputService.MouseBehavior ~= behavior then
            UserInputService.MouseBehavior = behavior
        end

        if UserInputService.MouseIconEnabled ~= icon then
            UserInputService.MouseIconEnabled = icon
        end
    end)

    cursorLocked = wasLocked
end

local function forceCursor()
    uiState.mouseBehavior = UserInputService.MouseBehavior
    uiState.mouseIcon = UserInputService.MouseIconEnabled

    installCursorHook()
    writeCursor(Enum.MouseBehavior.Default, true)
    cursorLocked = true
end

local function releaseCursor()
    cursorLocked = false

    writeCursor(
        uiState.mouseBehavior or Enum.MouseBehavior.Default,
        uiState.mouseIcon ~= false
    )
end

local function toggleMenu()
    closeLanguageMenu()
    window.Visible = not window.Visible
    gesture = nil

    if window.Visible then
        clampWindow()
        forceCursor()
    else
        releaseCursor()
    end
end

-- Keep re-asserting it: games re-lock the mouse on every one of their frames.
-- Heartbeat is checked as well, because it runs after the game's own render
-- step, so the cursor wins even against a camera script that never gives up.
local function assertCursor()
    if not window.Visible then
        -- menu closed: the game gets its mouse back
        cursorLocked = false
        return
    end

    if UserInputService.MouseBehavior == Enum.MouseBehavior.Default
        and UserInputService.MouseIconEnabled then
        return
    end

    writeCursor(Enum.MouseBehavior.Default, true)
end

connect(RunService.RenderStepped, assertCursor)

if RunService.Heartbeat then
    connect(RunService.Heartbeat, assertCursor)
end

if RunService.Stepped then
    connect(RunService.Stepped, assertCursor)
end

-- last render priority: runs after the game's own render step
if RunService.BindToRenderStep then
    pcall(function()
        RunService:UnbindFromRenderStep("ShitaroCursor")
    end)

    pcall(function()
        RunService:BindToRenderStep(
            "ShitaroCursor",
            Enum.RenderPriority.Last.Value,
            assertCursor
        )
    end)
end

-- Full shutdown: called from the confirm dialog before the gui is destroyed.
uiState.shutdown = function(wasOpen)
    if uiState.closed then
        return
    end

    uiState.closed = true
    cursorLocked = false

    pcall(function()
        RunService:UnbindFromRenderStep("ShitaroCursor")
    end)

    if wasOpen then
        releaseCursor()
    end

    pcall(function()
        getgenv().shitaro_dump = nil
    end)
end

-- Watermark: drag it anywhere with a finger or the cursor; a plain click
-- (no movement past the threshold) keeps the old toggle behaviour.
local watermarkGesture

local function moveWatermark(x, y)
    if not watermarkGesture then
        return
    end

    -- closed menu: the watermark stays put, a tap just re-opens the menu
    if not window.Visible then
        return
    end

    local deltaX = x - watermarkGesture.start.X
    local deltaY = y - watermarkGesture.start.Y

    if math.abs(deltaX) > 4 or math.abs(deltaY) > 4 then
        watermarkGesture.moved = true
    end

    if watermarkGesture.moved then
        setWatermarkOffset(
            watermarkGesture.offset.X + deltaX,
            watermarkGesture.offset.Y + deltaY
        )
    end
end

local function releaseWatermark()
    local clicked = watermarkGesture ~= nil
        and watermarkGesture.moved == false

    watermarkGesture = nil

    if clicked then
        toggleMenu()
    end
end

connect(watermark.InputBegan, function(input)
    if not isPressInput(input) then
        return
    end

    watermarkGesture = {
        start = input.Position,
        offset = watermarkOffset,
        moved = false,
    }

    beginUIDrag(input, moveWatermark, releaseWatermark)
end)

connect(UserInputService.InputChanged, function(input)
    if activeSlider then
        if (
            input.UserInputType == Enum.UserInputType.MouseMovement
            and activeSlider.input.UserInputType
                == Enum.UserInputType.MouseButton1
        ) or input == activeSlider.input then
            activeSlider.update(input.Position.X)
        end

        return
    end

    if not gesture then
        return
    end

    if input.UserInputType ~= Enum.UserInputType.MouseMovement
        and input ~= gesture.input then
        return
    end

    local delta = input.Position - gesture.origin

    if gesture.resize then
        local maximum = math.max(
            0.01,
            math.min(
                safeSize.X / 780,
                safeSize.Y / 470
            )
        )

        menuScale.Scale = math.clamp(
            gesture.scale + delta.X / 780,
            math.min(0.2, maximum),
            maximum
        )

        task.defer(updateHighlight)
    else
        local p = gesture.position

        gesture.target.Position = UDim2.new(
            p.X.Scale,
            p.X.Offset + delta.X,
            p.Y.Scale,
            p.Y.Offset + delta.Y
        )
    end

    clampWindow()
end)

connect(UserInputService.InputEnded, function(input)
    if activeSlider and input == activeSlider.input then
        activeSlider = nil
        previewScroll.ScrollingEnabled = true
    end

    if gesture and input == gesture.input then
        gesture = nil
    end
end)

connect(UserInputService.WindowFocusReleased, function()
    gesture = nil
    activeSlider = nil
    previewScroll.ScrollingEnabled = true
end)

connect(UserInputService.InputBegan, function(input)
    -- Rebinding mode swallows the next keyboard press, whatever key it is.
    if capturingBind then
        if input.UserInputType == Enum.UserInputType.Keyboard then
            bindKey = input.KeyCode
            capturingBind = false
            refreshBindValue()
        end

        return
    end

    if UserInputService:GetFocusedTextBox() then
        return
    end

    if input.KeyCode == bindKey then
        toggleMenu()
    end
end)

-- Watermark metrics

local frames, elapsed = 0, 0

connect(RunService.Heartbeat, function(dt)
    frames = frames + 1
    elapsed = elapsed + dt

    if elapsed < 0.5 then
        return
    end

    values.FPS.Text = tostring(
        math.floor(frames / elapsed + 0.5)
    )

    frames, elapsed = 0, 0

    local pingOK, ping = pcall(player.GetNetworkPing, player)

    values.Ping.Text = pingOK
        and (math.floor(ping * 1000 + 0.5) .. "ms")
        or "-"

    local memoryOK, memory = pcall(
        Stats.GetTotalMemoryUsageMb,
        Stats
    )

    values.RAM.Text = memoryOK
        and (math.floor(memory + 0.5) .. "mb")
        or "-"

    values.Time.Text = os.date("%H:%M")
end)


task.defer(fitScreen)